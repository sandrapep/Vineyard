<?php
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: prijava.php");
    exit();
}

include 'db.php';  // Pretpostavljam da je db.php konekcija ka bazi

$db = new Database();
$conn = $db->getConnection();

// Povlačenje podataka iz baze
$queryFaze = "SELECT COUNT(*) AS broj_fenoloskih_faza FROM fenoloskefaze";
$queryTretmani = "SELECT COUNT(*) AS broj_tretmana FROM tretmani";
$querySorte = "SELECT COUNT(*) AS broj_sorti FROM sorte";
$queryParceleSorte = "SELECT COUNT(*) AS broj_parcela_sorti FROM parcelesorte";
$queryParcele = "SELECT COUNT(*) AS broj_parcela FROM parcele";
$queryPrinosi = "SELECT SUM(iznos) AS ukupno_prinos FROM prinosi";

// Izvršenje upita
$fenoloskeFaze = $conn->query($queryFaze)->fetchColumn();
$tretmani = $conn->query($queryTretmani)->fetchColumn();
$sorte = $conn->query($querySorte)->fetchColumn();
$parceleSorte = $conn->query($queryParceleSorte)->fetchColumn();
$parcele = $conn->query($queryParcele)->fetchColumn();
$prinosi = $conn->query($queryPrinosi)->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upravljanje vinogradom</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #ebe3dd;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #143A51;
            padding: 15px 0;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 4px 2px -2px gray;
        }
        nav ul {
            list-style: none;
            display: flex;
            justify-content: center;
            margin: 0;
            padding: 0;
        }
        nav ul li {
            margin: 0 20px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            font-weight: 600;
        }
        nav ul li a:hover {
            color: #cfcfcf;
        }
        /* Video sekcija */
        .video-background {
            position: relative;
            width: 100%;
            height: 300px; /* Prilagođena visina */
            overflow: hidden;
            background-color: black;
        }

        .video-background video {
            position: absolute;
            top: 20;
            left: 50%;
            transform: translateX(-50%);
            min-width: 100%;
            min-height: 200%;
            z-index: 0;
            object-fit: cover;
        }

        .video-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            z-index: 1;
            background: rgba(0.1, 0, 0, 0.3);
        }

        .video-overlay h1 {
            font-size: 50px; /* Prilagođena veličina teksta */
            text-align: center;
            font-family: font-family: 'Bebas Neue', sans-serif; /* Boldovani font */
            font-weight: bold; /* Podebljan tekst */
            color: #fff; /* Boja slova */
            text-shadow: -1px -1px 0 #143a51, 1px -1px 0 #143a51, -1px 1px 0 #143a51, 1px 1px 0 #143a51; /* okvir */
        }

        .hero h1 {
            position: relative;
            font-size: 48px;
            color: #ffffff;
            text-align: center;
            z-index: 1;
            margin: 0;
            padding: 150px 20px;
        }
        .content {
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            animation: fadeInContent 2s ease;
        }
        .card {
            background-color: #143a51 ;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin: 20px;
            flex: 1;
            min-width: 250px;
            max-width: 300px;
            text-align: center;
            padding: 20px;
            animation: slideIn 1.5s ease;
        }
        .card.left {
            animation: slideInLeft 1.5s ease;
        }
        .card.right {
            animation: slideInRight 1.5s ease;
        }
        .card h3 {
            font-size: 24px;
            margin: 15px 0;
            color: #FFFFFF;
        }
        .card p {
            font-size: 16px;
            color: #FFFFFF;
            padding: 0 15px;
            margin-bottom: 20px;
        }

        /* Slika između sekcija */
        .transition-image {
            width: 100%;
            height: auto;
            display: block;
            margin-top: 1px; /* Razmak između forme za tekst i slike */
            margin-bottom: 1px; /* Razmak između slike i statistike */
        }

        /* Sekcija za statistiku sa pozadinskom slikom */
        .statistics {
            background-color: #ebe3dd;
            background-size: cover;
            background-position: center;
            padding: 50px 0;
            color: #fff;
        }
        .stats-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            max-width: 1200px;
            margin: 0 auto;
        }
        .stats-card {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 30px 20px;
            border-radius: 10px;
            text-align: center;
            margin: 20px;
            flex: 1;
            min-width: 200px;
            max-width: 250px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .stats-card:hover {
            transform: scale(1.05);
        }
        .stats-card h3 {
            margin: 10px 0;
            font-size: 22px;
            color: #143A51;
        }
        .stats-card .number {
            font-size: 40px;
            font-weight: bold;
            color: #143A51;
        }
        .admin-link {
            position: absolute;
            left: 20px;
            top: 15px;
        }
        
        .admin-link a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        
        .admin-link a:hover {
            color: #cfcfcf;
        }


        /* Animacija za brojanje */
        @keyframes countUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Animacije za pojavljivanje */
        @keyframes slideInLeft {
            from { opacity: 0; transform: translateX(-100px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(100px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeInContent {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body>

<header>
    <nav>
        <ul>
            <!-- Link za povratak na admin panel, vidljiv samo administratorima -->
    <?php if ($_SESSION['user_type'] === 'admin'): ?>
        <div class="admin-link">
            <a href="admin/aindex.php">Admin panel</a>
        </div>
    <?php endif; ?>
            <li><a href="fenoloskefaze/ffindex.php">Fenološke faze</a></li>
            <li><a href="tretmani/tindex.php">Tretmani</a></li>
            <li><a href="sorte/sindex.php">Sorte</a></li>
            <li><a href="parcelesorte/psindex.php">Parcele i sorte</a></li>
            <li><a href="parcele/pindex.php">Parcele</a></li>
            <li><a href="prinosi/prindex.php">Prinosi</a></li>
            <li><a href="registarfenofaza/regindex.php">Registar feno faza</a></li>
            <li><a href="registartretmana/regtretindex.php">Registar tretmana</a></li>
            <li><a href="odjava.php">Odjava</a></li>
        </ul>
    </nav>
</header>

<div class="video-background">
    <video autoplay muted loop>
        <source src="https://montejewelry.shop/vineyard-app/video/v1.mp4" type="video/mp4">
    </video>
    <div class="video-overlay">
        <h1>Upravljanje vinogradom</h1>
    </div>
</div>

<!-- Postojeći sadržaj -->
<div class="content">
    <div class="card left">
        <h3>Fenološke faze</h3>
        <p>Fenološke faze vinove loze obuhvataju ključne trenutke u njenom godišnjem ciklusu rasta, od buđenja pupoljaka do sazrijevanja grožđa.</p>
    </div>
    <div class="card right">
        <h3>Tretmani</h3>
        <p>Tretmani vinove loze uključuju sve neophodne radnje za održavanje zdravlja i plodnosti, kao što su prskanje, orezivanje i zaštita.</p>
    </div>
    <div class="card left">
        <h3>Sorte</h3>
        <p>Sorte vinove loze su različite vrste grožđa koje se uzgajaju za proizvodnju vina, soka, grožđica i drugih proizvoda.</p>
    </div>
    <div class="card right">
        <h3>Parcele</h3>
        <p>Parcele vinograda su pojedinačne površine zemljišta na kojima se uzgajaju specifične sorte vinove loze.</p>
    </div>
    <div class="card left">
        <h3>Prinosi</h3>
        <p>Prinosi predstavljaju količinu grožđa dobijenu sa određenih parcela tokom berbe, ključni faktor za proizvodnju vina.</p>
    </div>
</div>

<!-- Transition image section -->
<img src="https://montejewelry.shop/vineyard-app/video/slika.png" alt="Transition Image" class="transition-image">

<!-- Sekcija sa statistikom -->
<div class="statistics">
    <div class="stats-container">
        <div class="stats-card">
            <h3>Ukupno fenoloških faza</h3>
            <div class="number" id="fenoloskeFaze"><?php echo $fenoloskeFaze; ?></div>
        </div>
        <div class="stats-card">
            <h3>Ukupno tretmana</h3>
            <div class="number" id="tretmani"><?php echo $tretmani; ?></div>
        </div>
        <div class="stats-card">
            <h3>Ukupno sorti</h3>
            <div class="number" id="sorte"><?php echo $sorte; ?></div>
        </div>
        <div class="stats-card">
            <h3>Ukupno parcela i sorti</h3>
            <div class="number" id="parceleSorte"><?php echo $parceleSorte; ?></div>
        </div>
        <div class="stats-card">
            <h3>Ukupno parcela</h3>
            <div class="number" id="parcele"><?php echo $parcele; ?></div>
        </div>
        <div class="stats-card">
            <h3>Ukupno prinosa (kg)</h3>
            <div class="number" id="prinosi"><?php echo $prinosi; ?></div>
        </div>
    </div>
</div>

<script>
    // Funkcija za animiranje brojanja
    function animateValue(id, start, end, duration) {
        let obj = document.getElementById(id);
        let range = end - start;
        let stepTime = Math.abs(Math.floor(duration / range));
        let startTime = new Date().getTime();
        let endTime = startTime + duration;
        let timer = setInterval(function() {
            let now = new Date().getTime();
            let remaining = Math.max((endTime - now) / duration, 0);
            let value = Math.round(end - (remaining * range));
            obj.innerHTML = value;
            if (value === end) {
                clearInterval(timer);
            }
        }, stepTime);
    }

    // Pozivanje animacija za sve brojeve
    window.onload = function() {
        animateValue("fenoloskeFaze", 0, <?php echo $fenoloskeFaze; ?>, 2000);
        animateValue("tretmani", 0, <?php echo $tretmani; ?>, 2000);
        animateValue("sorte", 0, <?php echo $sorte; ?>, 2000);
        animateValue("parceleSorte", 0, <?php echo $parceleSorte; ?>, 2000);
        animateValue("parcele", 0, <?php echo $parcele; ?>, 2000);
        animateValue("prinosi", 0, <?php echo $prinosi; ?>, 2000);
    }
</script>

</body>
</html>
