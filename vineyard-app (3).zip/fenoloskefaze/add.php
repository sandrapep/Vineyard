<?php
ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
include '../db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivFaze = $_POST['nazivFaze'];
    $fenoKod = $_POST['fenoKod'];
    $opis = $_POST['opis'];
    $jezik = $_POST['jezik']; // Dodajemo jezik

    $db = new Database();
    $conn = $db->getConnection();

    $query = "INSERT INTO fenoloskefaze (nazivFaze, fenoKod, opis, jezik) VALUES (:nazivFaze, :fenoKod, :opis, :jezik)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivFaze', $nazivFaze);
    $stmt->bindParam(':fenoKod', $fenoKod);
    $stmt->bindParam(':opis', $opis);
    $stmt->bindParam(':jezik', $jezik); // Bindujemo jezik

    if ($stmt->execute()) {
        header("Location: ffindex.php");
    } else {
        echo "Greška pri dodavanju.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj novu fenološku fazu</title>
    <style>
        body {
            font-family: 'Arial', sans-serif; /* Osigurava da cijeli tekst koristi Arial font */
            margin: 0;
            padding: 0;
            background-image: url('https://www.montefalcon.com.au/uploads/6/7/9/2/67924391/img-1489_orig.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 600px;
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            font-family: 'Arial', sans-serif; /* Primjena Arial fonta na naslov */
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }
        input, textarea, select {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            font-family: 'Arial', sans-serif; /* Arial font za inpute */
        }
        textarea {
            resize: none;
            height: 100px;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #143a51;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-family: 'Arial', sans-serif; /* Arial font za dugmad */
        }
        button:hover {
            background-color: #0f2e41;
        }
        @media (max-width: 768px) {
            .container {
                padding: 15px;
                width: 90%;
            }
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Dodaj novu fenološku fazu</h1>
    <!-- Dugme za povratak na prethodnu stranicu sa strelicom -->
    <button class="back-button" onclick="window.location.href='ffindex.php'">&#8592;</button>
    <form method="post" action="add.php">
        <input type="text" name="nazivFaze" placeholder="Naziv faze" required>
        <input type="text" name="fenoKod" placeholder="Feno kod" pattern="[0-9]+" required>
        <textarea name="opis" placeholder="Opis" required></textarea>
        
        <!-- Dodavanje select polja za izbor jezika -->
        <select name="jezik" required>
            <option value="" disabled selected>Izaberite jezik</option>
            <option value="mne">MNE</option>
            <option value="eng">ENG</option>
        </select>

        <button type="submit">Dodaj</button>
    </form>
</div>
</body>
</html>
