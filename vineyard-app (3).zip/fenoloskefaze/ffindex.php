<?php
include '../db.php';
session_start();
$db = new Database();
$conn = $db->getConnection();

// Povlačenje jedinstvenih fenoloških faza za sve jezike
$query = "SELECT DISTINCT ff.fenoloskaFazaID, ff.nazivFaze, ff.fenoKod, ff.opis, ff.jezik, rf.datumVrijeme, pr.nazivProizvodjaca 
          FROM fenoloskefaze ff
          LEFT JOIN registarfenofaza rf ON ff.fenoloskaFazaID = rf.fenoloskaFazaID
          LEFT JOIN parcelesorte ps ON rf.parcelaSortaID = ps.parcelaSortaID
          LEFT JOIN parcele p ON ps.parcelaID = p.parcelaID
          LEFT JOIN proizvodjaci pr ON p.proizvodjacID = pr.proizvodjacID
          GROUP BY ff.fenoloskaFazaID";

$stmt = $conn->prepare($query);
$stmt->execute();
$fenoloskeFaze = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fenološke faze</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://d11vyokdyewbcr.cloudfront.net/2132801_large_a11b4514.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 1000px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #0f2e41;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #aec7d6;
            color: #fff;
        }

        th, td {
            border: 1px solid #fff;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }

        th {
            background-color: #143a51;
        }

        td {
            background-color: #aec7d6;
            color: #000;
        }

        /* Definisanje visine za tbody i omogućavanje skrolovanja */
        tbody {
            max-height: 400px;
            overflow-y: auto;
            display: block;
        }

        thead, tbody tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }

        tbody tr {
            display: table;
            table-layout: fixed;
            width: 100%;
        }

        /* Postavljamo specifične širine za feno kod i opis kolone */
        th:nth-child(2), td:nth-child(2) {
            width: 10%; /* Užina kolona za feno kod */
        }
        th:nth-child(3), td:nth-child(3) {
            width: 50%; /* Šira kolona za opis */
        }

        .filter-container {
            margin-bottom: 20px;
        }

        .filter-input {
            font-family: Arial, sans-serif;
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px; /* Veća strelica */
            font-weight: bold; /* Deblja strelica */
            background-color: #143a51; /* Dodata boja pozadine */
            border: 2px solid #0f2e41; /* Dodan okvir */
            border-radius: 8px; /* Zaobljeni uglovi */
            color: #ffffff; /* Boja strelice */
            padding: 10px 15px; /* Razmak unutar dugmeta */
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease; /* Efekat prelaza */
        }

        .back-button:hover {
            background-color: #668846; /* Tamnija pozadina pri hover-u */
            border-color: #143a51; /* Promena boje okvira pri hover-u */
        }

        .add-button {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .add-button:hover {
            background-color: #0f2e41;
        }

    </style>
</head>
<body>
<div class="container">
    <h1>Fenološke faze</h1>
    <!-- Dugme za povratak na index.php sa strelicom -->
    <button class="back-button" onclick="window.location.href='../index.php'">&#8592;</button>
    <!-- Dugme za dodavanje nove fenološke faze -->
    <button class="add-button" onclick="window.location.href='add.php'">Dodaj novu fenološku fazu</button>

    <!-- Filter polja za pretragu po nazivu i feno kodu -->
    <div class="filter-container">
        <input type="text" id="nazivFilter" class="filter-input" placeholder="Pretraži po nazivu faze">
        <input type="text" id="fenoKodFilter" class="filter-input" placeholder="Pretraži po feno kodu">
        <button id="filterButton">Filtriraj</button>
    </div>

    <!-- Dugmad za filtriranje po jeziku -->
    <div class="filter-container">
        <label><input type="radio" name="language" value="mne" onclick="filterByLanguage('mne')" checked> MNE</label>
        <label><input type="radio" name="language" value="eng" onclick="filterByLanguage('eng')"> ENG</label>
    </div>

    <table id="fazeTable">
    <thead>
        <tr>
            <th>Naziv faze</th>
            <th>Feno kod</th>
            <th>Opis</th>
            <th>Jezik</th> <!-- Dodata nova kolona za jezik -->
        </tr>
    </thead>
    <tbody>
        <?php foreach ($fenoloskeFaze as $faza): ?>
            <tr>
                <td><?php echo htmlspecialchars($faza['nazivFaze']); ?></td>
                <td><?php echo htmlspecialchars($faza['fenoKod']); ?></td>
                <td><?php echo htmlspecialchars($faza['opis']); ?></td>
                <td><?php echo htmlspecialchars($faza['jezik']); ?></td> <!-- Prikaz jezika -->
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</div>

<script>
    // Filtriranje podataka u tabeli na osnovu unetih filtera
    document.getElementById('filterButton').addEventListener('click', function() {
        filterTable();
    });

    function filterTable() {
        var nazivValue = document.getElementById('nazivFilter').value.toLowerCase();
        var fenoKodValue = document.getElementById('fenoKodFilter').value.toLowerCase();
        var rows = document.querySelectorAll('#fazeTable tbody tr');

        rows.forEach(function(row) {
            var naziv = row.cells[0].textContent.toLowerCase();
            var fenoKod = row.cells[1].textContent.toLowerCase();

            var nazivMatch = naziv.includes(nazivValue);
            var fenoKodMatch = fenoKod.includes(fenoKodValue);

            if (nazivMatch && fenoKodMatch) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    // Filtriranje podataka u tabeli na osnovu jezika
    function filterByLanguage(language) {
        var rows = document.querySelectorAll('#fazeTable tbody tr');

        rows.forEach(function(row) {
            var rowLanguage = row.cells[3].textContent.trim().toLowerCase(); // Jezik je u četvrtoj koloni

            if (rowLanguage === language) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    // Prikaz samo mne jezika pri inicijalnom učitavanju stranice
    window.onload = function() {
        filterByLanguage('mne');
    };
</script>

</body>
</html>
