<?php
include '../db.php';
session_start();

$id = $_GET['id'];

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivFaze = $_POST['nazivFaze'];
    $fenoKod = $_POST['fenoKod'];
    $opis = $_POST['opis'];
    $jezik = $_POST['jezik'];

    $query = "UPDATE fenoloskefaze SET nazivFaze = :nazivFaze, fenoKod = :fenoKod, opis = :opis, jezik = :jezik WHERE fenoloskaFazaID = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivFaze', $nazivFaze);
    $stmt->bindParam(':fenoKod', $fenoKod);
    $stmt->bindParam(':opis', $opis);
    $stmt->bindParam(':jezik', $jezik);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        header("Location: ffindex.php");
    } else {
        echo "Greška pri uređivanju.";
    }
}

$query = "SELECT * FROM fenoloskefaze WHERE fenoloskaFazaID = :id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':id', $id);
$stmt->execute();
$faza = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi fenološku fazu</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://www.montefalcon.com.au/uploads/6/7/9/2/67924391/img-1489_orig.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 500px; /* Ograničava širinu */
            text-align: center;
            box-sizing: border-box;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }

        form {
            display: flex;
            flex-direction: column;
            width: 100%;
        }

        input, textarea {
            margin-bottom: 15px;
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
            font-family: 'Arial', sans-serif;
        }

        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-family: 'Arial', sans-serif;
        }

        button:hover {
            background-color: #0f2e41;
        }

        @media (max-width: 600px) {
            .container {
                width: 95%;
            }

            h1 {
                font-size: 20px;
            }

            input, textarea, button {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi fenološku fazu</h1>
    <form method="post" action="edit.php?id=<?php echo $id; ?>">
        <input type="text" name="nazivFaze" placeholder="Naziv faze" value="<?php echo htmlspecialchars($faza['nazivFaze']); ?>" required>
        <input type="text" name="fenoKod" placeholder="Feno kod" pattern="[0-9]+" value="<?php echo htmlspecialchars($faza['fenoKod']); ?>" required>
        <textarea name="opis" placeholder="Opis" required><?php echo htmlspecialchars($faza['opis']); ?></textarea>
        <input type="text" name="jezik" placeholder="Jezik" value="<?php echo htmlspecialchars($faza['jezik']); ?>" required>
        <button type="submit">Sačuvaj</button>
    </form>
</div>
</body>
</html>
