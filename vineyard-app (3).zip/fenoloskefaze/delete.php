<?php
include '../db.php';
session_start();

$id = $_GET['id'];

$db = new Database();
$conn = $db->getConnection();

$query = "DELETE FROM fenoloskefaze WHERE fenoloskaFazaID = :id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':id', $id);

if ($stmt->execute()) {
    header("Location: ffindex.php");
} else {
    echo "Greška pri brisanju.";
}
?>
