<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Povlačenje sorti
$query = "SELECT sortaID, nazivSorte FROM sorte";
$stmt = $conn->prepare($query);
$stmt->execute();
$sorte = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sorte</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://media.post.rvohealth.io/wp-content/uploads/2020/01/grapes-varieties-types-1200x628-facebook.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 1000px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #0f2e41;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #aec7d6;
            color: #fff;
        }
        th, td {
            border: 1px solid #fff;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }
        th {
            background-color: #143a51;
        }
        td {
            background-color: #aec7d6;
            color: #000;
        }
        tbody {
            max-height: 400px;
            overflow-y: auto;
            display: block;
        }
        thead, tbody tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }
        tbody tr {
            display: table;
            table-layout: fixed;
            width: 100%;
        }
        .filter-container {
            margin-bottom: 20px;
        }
        .filter-input {
            font-family: Arial, sans-serif;
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
        .add-button {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .add-button:hover {
            background-color: #0f2e41;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Sorte</h1>
    <!-- Dugme za povratak na index.php sa strelicom -->
    <button class="back-button" onclick="window.location.href='../index.php'">&#8592;</button>
    <!-- Dugme za dodavanje nove sorte -->
    <button class="add-button" onclick="window.location.href='add_sorte.php'">Dodaj novu sortu</button>

    <!-- Filter polje za pretragu po nazivu sorte -->
    <div class="filter-container">
        <input type="text" id="nazivSorteFilter" class="filter-input" placeholder="Pretraži po nazivu sorte">
        <button id="filterButton">Filtriraj</button>
    </div>

    <table id="sorteTable">
        <thead>
            <tr>
                <th>Naziv sorte</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($sorte as $sorta): ?>
                <tr>
                    <td><?php echo htmlspecialchars($sorta['nazivSorte']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</div>

<script>
    // Filtriranje podataka u tabeli na osnovu unetih filtera
    document.getElementById('filterButton').addEventListener('click', function() {
        filterTable();
    });

    function filterTable() {
        var nazivValue = document.getElementById('nazivSorteFilter').value.toLowerCase();
        var rows = document.querySelectorAll('#sorteTable tbody tr');

        rows.forEach(function(row) {
            var naziv = row.cells[0].textContent.toLowerCase();
            var nazivMatch = naziv.includes(nazivValue);

            if (nazivMatch) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
</script>

</body>
</html>
