<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Obrada forme za dodavanje sorte
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivSorte = $_POST['nazivSorte'];

    // Provjera da li je polje nazivSorte prazno
    if (!empty($nazivSorte)) {
        // Provjera da li sorta već postoji
        $checkQuery = "SELECT COUNT(*) as count FROM sorte WHERE nazivSorte = :nazivSorte";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bindParam(':nazivSorte', $nazivSorte);
        $checkStmt->execute();
        $row = $checkStmt->fetch(PDO::FETCH_ASSOC);

        if ($row['count'] == 0) {
            // Unos nove sorte
            $query = "INSERT INTO sorte (nazivSorte) VALUES (:nazivSorte)";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':nazivSorte', $nazivSorte);

            if ($stmt->execute()) {
                $message = "Sorta uspješno dodata!";
            } else {
                $message = "Došlo je do greške prilikom dodavanja sorte.";
            }
        } else {
            $message = "Sorta sa ovim nazivom već postoji.";
        }
    } else {
        $message = "Molimo unesite naziv sorte.";
    }
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj sortu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://agronoblog.com/wp-content/uploads/2024/05/DALL%C2%B7E-2024-05-24-18.12.31-A-highly-realistic-image-showcasing-different-types-of-grapes-against-a-contrasting-background.-The-image-includes-bunches-of-dark-purple-grapes-gree-1024x585.webp');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        input {
            padding: 10px;
            font-size: 16px;
            width: 100%;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #0f2e41;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
        .message {
            font-size: 16px;
            margin-top: 15px;
            color: #143a51 ;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Dodaj novu sortu</h1>
    
    <!-- Dugme za povratak na sindex.php -->
    <button class="back-button" onclick="window.location.href='sindex.php'">&#8592;</button>
    
    <!-- Forma za unos nove sorte -->
    <form method="post" action="add_sorte.php">
        <input type="text" name="nazivSorte" placeholder="Unesite naziv sorte" required>
        <button type="submit">Dodaj</button>
    </form>

    <!-- Poruka o uspjehu ili grešci -->
    <?php if (isset($message)): ?>
        <div class="message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
</div>
</body>
</html>
