<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Preuzimanje prinosa i povezanih podataka za uređivanje, uključujući proizvođača
if (isset($_GET['id'])) {
    $prinosID = $_GET['id'];

    $query = "SELECT P.*, PS.parcelaSortaID, parcele.proizvodjacID
              FROM prinosi P
              JOIN parcelesorte PS ON P.parcelaSortaID = PS.parcelaSortaID
              JOIN parcele ON PS.parcelaID = parcele.parcelaID
              WHERE P.prinosID = :prinosID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':prinosID', $prinosID, PDO::PARAM_INT);
    $stmt->execute();
    $prinos = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$prinos) {
        echo "Prinos nije pronađen.";
        exit();
    }
} else {
    echo "Neispravan zahtev.";
    exit();
}

// Povlačenje proizvođača za padajući meni
$queryProizvodjaci = "SELECT proizvodjacID, nazivProizvodjaca FROM proizvodjaci";
$stmtProizvodjaci = $conn->prepare($queryProizvodjaci);
$stmtProizvodjaci->execute();
$proizvodjaci = $stmtProizvodjaci->fetchAll(PDO::FETCH_ASSOC);

// Ažuriranje prinosa
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $godina = $_POST['godina'];
    $parcelaSortaID = $_POST['parcelaSortaID'];
    $iznos = $_POST['iznos'];

    $query = "UPDATE prinosi SET godina = :godina, parcelaSortaID = :parcelaSortaID, iznos = :iznos WHERE prinosID = :prinosID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':godina', $godina, PDO::PARAM_INT);
    $stmt->bindParam(':parcelaSortaID', $parcelaSortaID, PDO::PARAM_INT);
    $stmt->bindParam(':iznos', $iznos, PDO::PARAM_STR);
    $stmt->bindParam(':prinosID', $prinosID, PDO::PARAM_INT);

    if ($stmt->execute()) {
        header("Location: prinosi.php");
        exit();
    } else {
        echo "Došlo je do greške pri ažuriranju prinosa.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi Prinos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 100%;
        }
        h1 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            font-family: Arial, sans-serif;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            max-width: 400px;
        }
        button {
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi Prinos</h1>
    <form method="post" action="urediPr.php?id=<?php echo $prinosID; ?>">
        <input type="text" name="godina" value="<?php echo htmlspecialchars($prinos['godina']); ?>" required>

        <!-- Povlačenje parcele i sorte -->
        <label for="parcelaSortaID">Parcela i Sorta:</label>
        <select name="parcelaSortaID" required>
            <?php
            $queryParceleSorte = "SELECT PS.parcelaSortaID, P.nazivParcele, S.nazivSorte
                                  FROM parcelesorte PS
                                  JOIN parcele P ON PS.parcelaID = P.parcelaID
                                  JOIN sorte S ON PS.sortaID = S.sortaID";
            $stmtParceleSorte = $conn->prepare($queryParceleSorte);
            $stmtParceleSorte->execute();
            $parceleSorte = $stmtParceleSorte->fetchAll(PDO::FETCH_ASSOC);
            foreach ($parceleSorte as $ps) {
                $selected = $ps['parcelaSortaID'] == $prinos['parcelaSortaID'] ? 'selected' : '';
                echo "<option value='{$ps['parcelaSortaID']}' $selected>{$ps['nazivParcele']} - {$ps['nazivSorte']}</option>";
            }
            ?>
        </select>

        <!-- Povlačenje proizvođača -->
        <label for="proizvodjacID">Proizvođač:</label>
        <select name="proizvodjacID" required>
            <?php foreach ($proizvodjaci as $proizvodjac): ?>
                <option value="<?= $proizvodjac['proizvodjacID'] ?>" <?= ($proizvodjac['proizvodjacID'] == $prinos['proizvodjacID']) ? 'selected' : '' ?>>
                    <?= $proizvodjac['nazivProizvodjaca'] ?>
                </option>
            <?php endforeach; ?>
        </select>

        <input type="text" name="iznos" value="<?php echo htmlspecialchars($prinos['iznos']); ?> " pattern="[0-9]+" required>
        <button type="submit">Sačuvaj</button>
    </form>
</div>
</body>
</html>
