<?php
ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

if (isset($_GET['id'])) {
    $tipTretmanaID = $_GET['id'];

    $db = new Database();
    $conn = $db->getConnection();

    // Pripremi upit za brisanje
    $query = "DELETE FROM tiptretmana WHERE tipTretmanaID = :tipTretmanaID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':tipTretmanaID', $tipTretmanaID, PDO::PARAM_INT);

    if ($stmt->execute()) {
        // Uspešno obrisano, preusmeravanje nazad na tindex.php
        header("Location: tretmani.php?status=success&message=Tretman uspješno obrisan.");
        exit();
    } else {
        // Greška pri brisanju, preusmeravanje nazad sa porukom o grešci
        header("Location: tretmani.php?status=error&message=Došlo je do greške pri brisanju tretmana.");
        exit();
    }
} else {
    header("Location: tretmani.php?status=error&message=Nevalidan ID tretmana.");
    exit();
}
