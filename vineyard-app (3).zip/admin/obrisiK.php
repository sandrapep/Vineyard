<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $db = new Database();
    $conn = $db->getConnection();

    // Priprema upita za brisanje korisnika
    $query = "DELETE FROM korisnici WHERE korisnikID = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        // Ako je uspešno obrisano, preusmerava na stranicu sa korisnicima
        header("Location: korisnici.php");
        exit();
    } else {
        // Ako je došlo do greške, prikazuje poruku
        echo "Greška pri brisanju korisnika.";
    }
} else {
    // Ako nije prosleđen ID, vraća na stranicu sa korisnicima
    header("Location: korisnici.php");
    exit();
}
?>
