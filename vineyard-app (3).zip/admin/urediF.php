<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Preuzimanje fenološke faze za uređivanje
if (isset($_GET['id'])) {
    $fazaID = $_GET['id'];

    $query = "SELECT * FROM fenoloskefaze WHERE fenoloskaFazaID = :fazaID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':fazaID', $fazaID);
    $stmt->execute();

    $faza = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$faza) {
        echo "Fenološka faza nije pronađena.";
        exit();
    }
} else {
    echo "Neispravan zahtjev.";
    exit();
}

// Ažuriranje fenološke faze
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivFaze = $_POST['nazivFaze'];
    $fenoKod = $_POST['fenoKod'];
    $opis = $_POST['opis'];
    $slika = $_POST['slika'];  // Polje za sliku
    $jezik = $_POST['jezik'];  // Polje za jezik

    $query = "UPDATE fenoloskefaze SET nazivFaze = :nazivFaze, fenoKod = :fenoKod, opis = :opis, slika = :slika, jezik = :jezik WHERE fenoloskaFazaID = :fazaID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivFaze', $nazivFaze);
    $stmt->bindParam(':fenoKod', $fenoKod);
    $stmt->bindParam(':opis', $opis);
    $stmt->bindParam(':slika', $slika);  // Binds slika to the query
    $stmt->bindParam(':jezik', $jezik);  // Binds jezik to the query
    $stmt->bindParam(':fazaID', $fazaID);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Fenološka faza uspješno ažurirana."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Došlo je do greške pri ažuriranju faze."]);
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi fenološku fazu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 100%;
        }
        h1 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        input, textarea, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            width: 100%;
            max-width: 400px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: Arial, sans-serif;
        }
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
        #poruka {
            margin-top: 10px;
            text-align: center;
            font-size: 16px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Uredi fenološku fazu</h1>
    <form id="urediFazuForm">
        <label for="nazivFaze">Naziv faze:</label>
        <input type="text" name="nazivFaze" id="nazivFaze" value="<?php echo htmlspecialchars($faza['nazivFaze']); ?>" required>

        <label for="fenoKod">Feno kod:</label>
        <input type="text" name="fenoKod" id="fenoKod" value="<?php echo htmlspecialchars($faza['fenoKod']); ?> " pattern="[0-9]+" required>

        <label for="opis">Opis:</label>
        <textarea name="opis" id="opis" required><?php echo htmlspecialchars($faza['opis']); ?></textarea>

        <label for="slika">Link slike:</label>
        <input type="text" name="slika" id="slika" value="<?php echo htmlspecialchars($faza['slika']); ?>" placeholder="Unesi link slike" optional>

        <label for="jezik">Jezik:</label>
        <select name="jezik" id="jezik" required>
            <option value="mne" <?php if ($faza['jezik'] === 'mne') echo 'selected'; ?>>MNE</option>
            <option value="eng" <?php if ($faza['jezik'] === 'eng') echo 'selected'; ?>>ENG</option>
        </select>

        <button type="submit">Ažuriraj</button>
    </form>
    <div id="poruka"></div>
</div>

<script>
    document.getElementById('urediFazuForm').addEventListener('submit', function(e) {
        e.preventDefault(); // Sprečava osvežavanje stranice

        // Formiranje podataka iz forme
        let formData = new FormData(this);

        // Slanje AJAX zahteva
        fetch('urediF.php?id=<?php echo $fazaID; ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json()) // Parsiraj odgovor kao JSON
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('poruka').textContent = data.message;
                document.getElementById('poruka').style.color = 'green';
            } else {
                document.getElementById('poruka').textContent = data.message;
                document.getElementById('poruka').style.color = 'red';
            }
        })
        .catch(error => {
            console.error('Došlo je do greške:', error);
            document.getElementById('poruka').textContent = 'Došlo je do greške pri ažuriranju faze.';
            document.getElementById('poruka').style.color = 'red';
        });
    });
</script>

</body>
</html>
