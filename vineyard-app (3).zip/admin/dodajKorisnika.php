<?php
include '../db.php';

$response = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $email = $_POST['email'];
    $telefon = $_POST['telefon'];
    $tipNaloga = $_POST['tipNaloga'];
    $lozinka = $_POST['lozinka'];

    $db = new Database();
    $conn = $db->getConnection();

    // Upit za unos novog korisnika
    $query = "INSERT INTO korisnici (ime, prezime, eMail, telefon, tipNaloga, lozinka) VALUES (:ime, :prezime, :email, :telefon, :tipNaloga, :lozinka)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':ime', $ime);
    $stmt->bindParam(':prezime', $prezime);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':telefon', $telefon);
    $stmt->bindParam(':tipNaloga', $tipNaloga);
    $stmt->bindParam(':lozinka', password_hash($lozinka, PASSWORD_DEFAULT)); // Šifriranje lozinke

    if ($stmt->execute()) {
        // Vraćanje podataka o novom korisniku
        $noviKorisnikID = $conn->lastInsertId();
        $response = [
            'status' => 'success',
            'message' => 'Korisnik je uspješno dodat!',
            'korisnik' => [
                'korisnikID' => $noviKorisnikID,
                'ime' => $ime,
                'prezime' => $prezime,
                'email' => $email,
                'telefon' => $telefon,
                'tipNaloga' => $tipNaloga,
            ]
        ];
    } else {
        $response = ['status' => 'error', 'message' => 'Greška pri dodavanju korisnika.'];
    }
} else {
    $response = ['status' => 'error', 'message' => 'Neispravan zahtev.'];
}

echo json_encode($response);
