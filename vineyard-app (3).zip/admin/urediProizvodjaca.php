<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Proveravamo da li je prosleđen ID proizvođača
if (isset($_GET['id'])) {
    $proizvodjacID = $_GET['id'];

    // Povlačenje podataka o proizvođaču
    $query = "SELECT * FROM proizvodjaci WHERE proizvodjacID = :proizvodjacID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':proizvodjacID', $proizvodjacID, PDO::PARAM_INT);
    $stmt->execute();
    $proizvodjac = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$proizvodjac) {
        echo "Proizvođač nije pronađen.";
        exit();
    }
} else {
    echo "Neispravan zahtev.";
    exit();
}

// Povlačenje svih gradova iz baze
$queryGradovi = "SELECT * FROM gradovi";
$stmtGradovi = $conn->prepare($queryGradovi);
$stmtGradovi->execute();
$gradovi = $stmtGradovi->fetchAll(PDO::FETCH_ASSOC);

// Ažuriranje proizvođača
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivProizvodjaca = $_POST['nazivProizvodjaca'];
    $registarskiBroj = $_POST['registarskiBroj'];
    $adresa = $_POST['adresa'];
    $gradID = $_POST['gradID'];
    $eMail = $_POST['eMail'];
    $telefon = $_POST['telefon'];
    $slika = $_POST['slika'];
    $linkZaPodatkeNaslovna = $_POST['linkZaPodatkeNaslovna'];

    // SQL upit za ažuriranje podataka proizvođača
    $query = "UPDATE proizvodjaci 
              SET nazivProizvodjaca = :nazivProizvodjaca, registarskiBroj = :registarskiBroj, adresa = :adresa, gradID = :gradID, 
                  eMail = :eMail, telefon = :telefon, slika = :slika, linkZaPodatkeNaslovna = :linkZaPodatkeNaslovna
              WHERE proizvodjacID = :proizvodjacID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivProizvodjaca', $nazivProizvodjaca);
    $stmt->bindParam(':registarskiBroj', $registarskiBroj);
    $stmt->bindParam(':adresa', $adresa);
    $stmt->bindParam(':gradID', $gradID, PDO::PARAM_INT);
    $stmt->bindParam(':eMail', $eMail);
    $stmt->bindParam(':telefon', $telefon);
    $stmt->bindParam(':slika', $slika);
    $stmt->bindParam(':linkZaPodatkeNaslovna', $linkZaPodatkeNaslovna);
    $stmt->bindParam(':proizvodjacID', $proizvodjacID, PDO::PARAM_INT);

    if ($stmt->execute()) {
        $successMessage = "Proizvođač je uspešno ažuriran.";
    } else {
        $successMessage = "Došlo je do greške pri ažuriranju proizvođača.";
    }
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi proizvođača</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            text-align: center;
            margin-bottom: 20px;
        }
        .form-control {
            margin-bottom: 15px;
        }
        .form-control label {
            display: block;
            margin-bottom: 5px;
        }
        .form-control input, .form-control select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
        .success-message {
            color: green;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Uredi proizvođača</h1>
        <form method="POST">
            <div class="form-control">
                <label for="nazivProizvodjaca">Naziv proizvođača:</label>
                <input type="text" name="nazivProizvodjaca" value="<?php echo htmlspecialchars($proizvodjac['nazivProizvodjaca']); ?>" required>
            </div>
            <div class="form-control">
                <label for="registarskiBroj">Registarski broj:</label>
                <input type="text" name="registarskiBroj" value="<?php echo htmlspecialchars($proizvodjac['registarskiBroj']); ?>" required>
            </div>
            <div class="form-control">
                <label for="adresa">Adresa:</label>
                <input type="text" name="adresa" value="<?php echo htmlspecialchars($proizvodjac['adresa']); ?>" required>
            </div>
            <div class="form-control">
                <label for="gradID">Grad:</label>
                <select name="gradID" required>
                    <?php foreach ($gradovi as $grad): ?>
                        <option value="<?php echo htmlspecialchars($grad['gradID']); ?>" <?php if ($grad['gradID'] == $proizvodjac['gradID']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($grad['nazivGrada']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-control">
                <label for="eMail">E-mail:</label>
                <input type="email" name="eMail" value="<?php echo htmlspecialchars($proizvodjac['eMail']); ?>" required>
            </div>
            <div class="form-control">
                <label for="telefon">Telefon:</label>
                <input type="text" name="telefon" value="<?php echo htmlspecialchars($proizvodjac['telefon']); ?>" required>
            </div>
            <div class="form-control">
                <label for="slika">Slika (URL):</label>
                <input type="text" name="slika" value="<?php echo htmlspecialchars($proizvodjac['slika']); ?>" optional>
            </div>
            <div class="form-control">
                <label for="linkZaPodatkeNaslovna"></label>
                <input type="text" name="linkZaPodatkeNaslovna" value="<?php echo htmlspecialchars($proizvodjac['linkZaPodatkeNaslovna']); ?>" optional>
            </div>
            <button type="submit">Ažuriraj</button>
        </form>

        <!-- Prikaz poruke o uspešnom ažuriranju -->
        <?php if (isset($successMessage)): ?>
            <p class="success-message"><?php echo $successMessage; ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
