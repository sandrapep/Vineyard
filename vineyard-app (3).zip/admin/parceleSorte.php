<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Povlačenje jedinstvenih sorti sa povezanim podacima o parceli i razmacima
$query = "SELECT PS.parcelasortaID, S.nazivSorte, P.nazivParcele, PS.razmakSadnje, PS.razmakRedovi, PS.godinaSadnje
          FROM sorte S
          LEFT JOIN parcelesorte PS ON S.sortaID = PS.sortaID
          LEFT JOIN parcele P ON PS.parcelaID = P.parcelaID";
$stmt = $conn->prepare($query);
$stmt->execute();
$parceleSorte = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Brojanje parcela i sorti (Za grafikon)
$queryCount = "SELECT COUNT(DISTINCT PS.parcelasortaID) as brojParcelaSorti FROM parcelesorte PS";
$stmtCount = $conn->prepare($queryCount);
$stmtCount->execute();
$brojParcelaSorti = $stmtCount->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parcele i sorte</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 1000px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            max-width: 800px;
            margin: 20px auto;
            border-collapse: collapse;
            display: none;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #143a51;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        button {
            padding: 10px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        button:hover {
            background-color: #556b35;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        .action-buttons button {
            background: none;
            border: none;
            color: #668846;
            cursor: pointer;
            text-decoration: underline;
        }
        .action-buttons button:hover {
            color: #556b35;
        }
        .search-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            align-items: center;
        }
        .search-container input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 80%;
        }
        .chart-container {
            width: 80%;
            margin: 0 auto 20px auto;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            font-family: Arial, sans-serif;
        }
        .form-container button {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .form-container button:hover {
            background-color: #556b35;
        }
        #poruka {
            margin-top: 10px;
            text-align: center;
            font-size: 16px;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Parcele i sorte</h1>
    <button class="back-button" onclick="window.location.href='aindex.php'">&#8592;</button>

    <div class="chart-container">
        <canvas id="parceleSorteChart"></canvas>
    </div>

    <div class="search-container">
        <input type="text" id="search" placeholder="Pretraži po nazivu sorte ili parcele">
        <button id="toggleBtn">Prikaži sve parcele i sorte</button>
    </div>

    <table id="parceleSorteTable">
        <thead>
            <tr>
                <th>Naziv sorte</th>
                <th>Naziv parcele</th>
                <th>Razmak sadnje</th>
                <th>Razmak redova</th>
                <th>Godina sadnje</th>
                <th>Akcije</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($parceleSorte as $parcelesorta): ?>
            <tr>
                <td><?php echo htmlspecialchars($parcelesorta['nazivSorte']); ?></td>
                <td><?php echo htmlspecialchars($parcelesorta['nazivParcele']); ?></td>
                <td><?php echo htmlspecialchars($parcelesorta['razmakSadnje']); ?></td>
                <td><?php echo htmlspecialchars($parcelesorta['razmakRedovi']); ?></td>
                <td><?php echo htmlspecialchars($parcelesorta['godinaSadnje']); ?></td>
                <td class="action-buttons">
                    <button onclick="window.location.href='urediPS.php?parcelasortaID=<?php echo $parcelesorta['parcelasortaID']; ?>'">Uredi</button>
                    <button onclick="deleteParcelaSorta(<?php echo $parcelesorta['parcelasortaID']; ?>)">Obriši</button>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div class="form-container">
        <h2>Dodaj novu parcelu i sortu</h2>
        <form id="dodajParceluSortuForm">
            <div class="form-group">
                <label for="sortaID">Sorte:</label>
                <select name="sortaID" id="sortaID" required>
                    <?php
                    $querySorte = "SELECT sortaID, nazivSorte FROM sorte";
                    $stmtSorte = $conn->prepare($querySorte);
                    $stmtSorte->execute();
                    $sorte = $stmtSorte->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($sorte as $sorta) {
                        echo "<option value='{$sorta['sortaID']}'>{$sorta['nazivSorte']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="parcelaID">Parcela:</label>
                <select name="parcelaID" id="parcelaID" required>
                    <?php
                    $queryParcele = "SELECT parcelaID, nazivParcele FROM parcele";
                    $stmtParcele = $conn->prepare($queryParcele);
                    $stmtParcele->execute();
                    $parcele = $stmtParcele->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($parcele as $parcela) {
                        echo "<option value='{$parcela['parcelaID']}'>{$parcela['nazivParcele']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="razmakSadnje">Razmak sadnje (cm):</label>
                <input type="text" name="razmakSadnje" id="razmakSadnje" pattern="[0-9]+" title="Unesite samo brojeve" required>
            </div>

            <div class="form-group">
                <label for="razmakRedova">Razmak redova (cm):</label>
                <input type="text" name="razmakRedovi" id="razmakRedovi" pattern="[0-9]+" title="Unesite samo brojeve" required>
            </div>

            <div class="form-group">
                <label for="godinaSadnje">Godina sadnje:</label>
                <input type="text" name="godinaSadnje" id="godinaSadnje" pattern="[0-9]{4}" title="Unesite validnu četvorocifrenu godinu" required>
            </div>

            <button type="submit">Dodaj</button>
        </form>

        <div id="poruka"></div>
    </div>

<script>
 document.getElementById('dodajParceluSortuForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let formData = new FormData(this);

    fetch('dodajPS.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            document.getElementById('poruka').textContent = data.message;
            document.getElementById('poruka').style.color = 'green';
            location.reload();
        } else {
            document.getElementById('poruka').textContent = data.message;
            document.getElementById('poruka').style.color = 'red';
        }
    })
    .catch(error => {
        console.error('Došlo je do greške:', error);
        document.getElementById('poruka').textContent = 'Došlo je do greške pri dodavanju sorte.';
        document.getElementById('poruka').style.color = 'red';
    });
});

function deleteParcelaSorta(parcelasortaID) {
    if (confirm('Da li ste sigurni da želite obrisati ovu sortu?')) {
        fetch('obrisiPS.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ parcelasortaID: parcelasortaID })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert(data.message);
                location.reload();
            } else {
                alert(data.message);
            }
        })
        .catch(error => console.error('Došlo je do greške:', error));
    }
}

// Funkcija za prikazivanje grafikona
const ctx = document.getElementById('parceleSorteChart').getContext('2d');
const parceleSorteChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Parcele i sorte'],
        datasets: [{
            label: 'Ukupno parcela i sorti',
            data: [<?php echo $brojParcelaSorti['brojParcelaSorti']; ?>],
            backgroundColor: '#668846',
            borderColor: '#556b35',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Pretraga po nazivu sorte ili parceli
$('#search').on('keyup', function() {
    var value = $(this).val().toLowerCase();
    $('#parceleSorteTable tbody tr').filter(function() {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Funkcija za prikazivanje/sakrivanje tabele
$('#toggleBtn').on('click', function() {
    var table = $('#parceleSorteTable');
    if (table.is(':visible')) {
        table.hide();
        $(this).text('Prikaži sve parcele i sorte');
    } else {
        table.show();
        $(this).text('Sakrij sve parcele i sorte');
    }
});
</script>
</div>
</body>
</html>
