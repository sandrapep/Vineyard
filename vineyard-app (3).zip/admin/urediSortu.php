<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Provera da li je prosleđen ID sorte preko GET metode
if (isset($_GET['id'])) {
    $sortaID = intval($_GET['id']);

    // Dohvati podatke o sorti iz baze na osnovu sortaID
    $query = "SELECT sortaID, nazivSorte FROM sorte WHERE sortaID = :sortaID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':sortaID', $sortaID, PDO::PARAM_INT);
    $stmt->execute();

    $sorta = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sorta) {
        echo "Greška: Sorta nije pronađena!";
        exit();
    }
} else {
    echo "Greška: Sorta ID nije proslijeđen!";
    exit();
}

// Ažuriranje sorte nakon slanja forme
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['nazivSorte']) && !empty($_POST['nazivSorte'])) {
        $noviNazivSorte = $_POST['nazivSorte'];

        // Update query
        $updateQuery = "UPDATE sorte SET nazivSorte = :nazivSorte WHERE sortaID = :sortaID";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bindParam(':nazivSorte', $noviNazivSorte, PDO::PARAM_STR);
        $updateStmt->bindParam(':sortaID', $sortaID, PDO::PARAM_INT);

        if ($updateStmt->execute()) {
            // Vraćamo JSON odgovor
            echo json_encode(['status' => 'success', 'message' => 'Sorta uspješno ažurirana!']);
            exit();
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Greška pri ažuriranju sorte!']);
            exit();
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Naziv sorte ne može biti prazan!']);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi sortu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #668846;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        h1 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input {
            width: 80%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        button {
            padding: 10px 15px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0f2e41;
        }
        #poruka {
            margin-top: 10px;
            font-size: 16px;
            color: green;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi sortu</h1>
    <form id="urediSortuForm">
        <input type="text" name="nazivSorte" value="<?php echo htmlspecialchars($sorta['nazivSorte']); ?>" required>
        <button type="submit">Ažuriraj</button>
    </form>
    
    <!-- Div gde će se prikazivati poruka o uspehu ili grešci -->
    <div id="poruka"></div>
</div>

<script>
    document.getElementById('urediSortuForm').addEventListener('submit', function(e) {
        e.preventDefault();

        // Prikupljanje podataka iz forme
        let formData = new FormData(this);
        formData.append('id', '<?php echo $sortaID; ?>');

        // Slanje AJAX zahteva
        fetch('urediSortu.php?id=<?php echo $sortaID; ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json()) // Očekujemo JSON odgovor
        .then(data => {
            const porukaDiv = document.getElementById('poruka');

            if (data.status === 'success') {
                porukaDiv.textContent = data.message;
                porukaDiv.style.color = 'green';
            } else {
                porukaDiv.textContent = data.message;
                porukaDiv.style.color = 'red';
            }
        })
        .catch(error => {
            console.error('Došlo je do greške:', error);
            document.getElementById('poruka').textContent = 'Došlo je do greške pri ažuriranju sorte.';
            document.getElementById('poruka').style.color = 'red';
        });
    });
</script>

</body>
</html>
