<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nazivFaze = $_POST['nazivFaze'];
    $fenoKod = $_POST['fenoKod'];
    $opis = $_POST['opis'];
    $slika = $_POST['slika'];  // Novi unos za sliku
    $jezik = $_POST['jezik'];  // Novi unos za jezik

    // Povezivanje sa bazom podataka
    $db = new Database();
    $conn = $db->getConnection();

    // Upit za unos nove fenološke faze sa slikom i jezikom
    $query = "INSERT INTO fenoloskefaze (nazivFaze, fenoKod, opis, slika, jezik) VALUES (:nazivFaze, :fenoKod, :opis, :slika, :jezik)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivFaze', $nazivFaze);
    $stmt->bindParam(':fenoKod', $fenoKod);
    $stmt->bindParam(':opis', $opis);
    $stmt->bindParam(':slika', $slika);  // Nova slika
    $stmt->bindParam(':jezik', $jezik);  // Novi jezik

    if ($stmt->execute()) {
        // Uspešno dodavanje
        echo json_encode(['status' => 'success', 'message' => 'Fenološka faza uspješno dodata!']);
    } else {
        // Greška pri unosu
        echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške pri dodavanju fenološke faze.']);
    }
}

?>
