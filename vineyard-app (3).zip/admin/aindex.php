<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Fetch counts for dashboard
$queryKorisnici = "SELECT COUNT(*) as total FROM korisnici";
$stmtKorisnici = $conn->prepare($queryKorisnici);
$stmtKorisnici->execute();
$totalKorisnici = $stmtKorisnici->fetch(PDO::FETCH_ASSOC)['total'];

$queryFaze = "SELECT COUNT(*) as total FROM fenoloskefaze";
$stmtFaze = $conn->prepare($queryFaze);
$stmtFaze->execute();
$totalFaze = $stmtFaze->fetch(PDO::FETCH_ASSOC)['total'];

$queryTipTretmana = "SELECT COUNT(*) as total FROM tiptretmana";
$stmtTipTretmana = $conn->prepare($queryTipTretmana);
$stmtTipTretmana->execute();
$totalTipTretmana = $stmtTipTretmana->fetch(PDO::FETCH_ASSOC)['total'];

$querySorte = "SELECT COUNT(*) as total FROM sorte";
$stmtSorte = $conn->prepare($querySorte);
$stmtSorte->execute();
$totalSorte = $stmtSorte->fetch(PDO::FETCH_ASSOC)['total'];

$queryParceleSorte = "SELECT COUNT(*) as total FROM parcelesorte";
$stmtParceleSorte = $conn->prepare($queryParceleSorte);
$stmtParceleSorte->execute();
$totalParceleSorte = $stmtParceleSorte->fetch(PDO::FETCH_ASSOC)['total'];

$queryParcele = "SELECT COUNT(*) as total FROM parcele";
$stmtParcele = $conn->prepare($queryParcele);
$stmtParcele->execute();
$totalParcele = $stmtParcele->fetch(PDO::FETCH_ASSOC)['total'];

$queryPrinosi = "SELECT SUM(iznos) as total FROM prinosi";
$stmtPrinosi = $conn->prepare($queryPrinosi);
$stmtPrinosi->execute();
$totalPrinosi = $stmtPrinosi->fetch(PDO::FETCH_ASSOC)['total'];

// Fetch counts for Registar feno faza
$queryRegistarFenoFaza = "SELECT COUNT(*) as total FROM registarfenofaza";
$stmtRegistarFenoFaza = $conn->prepare($queryRegistarFenoFaza);
$stmtRegistarFenoFaza->execute();
$totalRegistarFenoFaza = $stmtRegistarFenoFaza->fetch(PDO::FETCH_ASSOC)['total'];

// Fetch counts for tretmani
$queryTretmani = "SELECT COUNT(*) as total FROM tretmani";
$stmtTretmani = $conn->prepare($queryTretmani);
$stmtTretmani->execute();
$totalTretmani = $stmtTretmani->fetch(PDO::FETCH_ASSOC)['total'];

// Example data for the charts
$queryMonthlyPrinosi = "SELECT godina, SUM(iznos) AS total FROM prinosi GROUP BY godina";
$stmtMonthlyPrinosi = $conn->prepare($queryMonthlyPrinosi);
$stmtMonthlyPrinosi->execute();
$monthlyPrinosi = $stmtMonthlyPrinosi->fetchAll(PDO::FETCH_ASSOC);

$years = [];
$prinosiData = [];
foreach ($monthlyPrinosi as $row) {
    $years[] = $row['godina'];
    $prinosiData[] = $row['total'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #143a51; /* Plava Elephant za zaglavlje */
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav {
            width: 200px;
            background-color: #143a51; /* Plava Elephant */
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }

        nav ul {
            list-style-type: none;
            padding: 0;
        }

        nav ul li {
            padding: 10px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            display: block;
        }

        nav ul li a:hover {
            background-color: #556b35; /* Tamnija zelena */
        }

        .container {
            margin-left: 200px;
            padding: 20px;
            width: calc(100% - 200px);
        }

        .dashboard-cards {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .card {
            background-color: white;
            padding: 20px;
            text-align: center;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .card h2 {
            margin: 0;
        }

        .card p {
            font-size: 24px;
            font-weight: bold;
            color: #143a51; /* Plava Elephant */
        }

        canvas {
            max-width: 100%;
            margin-top: 20px;
        }

        .btn {
            background-color: #668846; /* Zelena dugmad */
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            margin-bottom: 20px;
            display: inline-block;
        }

        .btn:hover {
            background-color: #556b35;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Include Chart.js -->
</head>
<body>
    <header>
        <h1>Admin panel</h1>
    </header>
    
    <nav>
        <ul>
            <li><a href="../index.php" class="btn">Idi na sajt</a></li>
            <li><a href="korisnici.php">Korisnici</a></li>
            <li><a href="fenoloskefaze.php">Fenološke faze</a></li>
            <li><a href="tretmani.php">Tretmani</a></li>
            <li><a href="sorte.php">Sorte</a></li>
            <li><a href="parceleSorte.php">Parcele i sorte</a></li>
            <li><a href="parcele.php">Parcele</a></li>
            <li><a href="prinosi.php">Prinosi</a></li>
            <li><a href="proizvodjaci.php">Proizvođači</a></li>
            <li><a href="registar.php">Registar feno faza</a></li>
            <li><a href="registarTretmani.php">Registar tretmana</a></li>
            <li><a href="../odjava.php">Odjava</a></li>
        </ul>
    </nav>
    
    <div class="container">
        <div class="dashboard-cards">
            <div class="card">
                <h2>Korisnici</h2>
                <p><?php echo $totalKorisnici; ?></p>
                <canvas id="korisniciChart"></canvas>
            </div>
            <div class="card">
                <h2>Fenološke faze</h2>
                <p><?php echo $totalFaze; ?></p>
                <canvas id="fazeChart"></canvas>
            </div>
            <div class="card">
                <h2>Tretmani</h2>
                <p><?php echo $totalTipTretmana; ?></p>
                <canvas id="tipTretmanaChart"></canvas>
            </div>
            <div class="card">
                <h2>Sorte</h2>
                <p><?php echo $totalSorte; ?></p>
                <canvas id="sorteChart"></canvas>
            </div>
            <div class="card">
                <h2>Parcele i sorte</h2>
                <p><?php echo $totalParceleSorte; ?></p>
                <canvas id="parceleSorteChart"></canvas>
            </div>
            <div class="card">
                <h2>Parcele</h2>
                <p><?php echo $totalParcele; ?></p>
                <canvas id="parceleChart"></canvas>
            </div>
            <div class="card">
                <h2>Ukupni prinosi</h2>
                <p><?php echo $totalPrinosi; ?> kg</p>
                <canvas id="prinosiChart"></canvas>
            </div>
            <div class="card">
                <h2>Registar feno faza</h2>
                <p><?php echo $totalRegistarFenoFaza; ?></p>
                <canvas id="registarFenoFazaChart"></canvas>
            </div>
            <div class="card">
                <h2>Registar tretmana</h2>
                <p><?php echo $totalTretmani; ?></p>
                <canvas id="tretmaniChart"></canvas>
            </div>
        </div>
    </div>

    <script>
        function createChart(context, label, data) {
            return new Chart(context, {
                type: 'bar',
                data: {
                    labels: ['Total'],
                    datasets: [{
                        label: label,
                        data: [data],
                        backgroundColor: 'rgba(102, 136, 70, 0.8)', // Green Dingley color
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        createChart(document.getElementById('korisniciChart').getContext('2d'), 'Korisnici', <?php echo $totalKorisnici; ?>);
        createChart(document.getElementById('fazeChart').getContext('2d'), 'Fenološke faze', <?php echo $totalFaze; ?>);
        createChart(document.getElementById('tipTretmanaChart').getContext('2d'), 'Tip tretmana', <?php echo $totalTipTretmana; ?>);
        createChart(document.getElementById('sorteChart').getContext('2d'), 'Sorte', <?php echo $totalSorte; ?>);
        createChart(document.getElementById('parceleSorteChart').getContext('2d'), 'Parcele i sorte', <?php echo $totalParceleSorte; ?>);
        createChart(document.getElementById('parceleChart').getContext('2d'), 'Parcele', <?php echo $totalParcele; ?>);
        createChart(document.getElementById('prinosiChart').getContext('2d'), 'Ukupni prinosi (kg)', <?php echo $totalPrinosi; ?>);
        createChart(document.getElementById('registarFenoFazaChart').getContext('2d'), 'Registar feno faza', <?php echo $totalRegistarFenoFaza; ?>);
        createChart(document.getElementById('tretmaniChart').getContext('2d'), 'Registar feno faza', <?php echo $totalRegistarFenoFaza; ?>);
    </script>
</body>
</html>