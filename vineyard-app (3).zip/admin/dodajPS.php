<?php
// Error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

header('Content-Type: application/json'); // Osiguraj da odgovaraš u JSON formatu

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sortaID = $_POST['sortaID'];
    $parcelaID = $_POST['parcelaID'];
    $razmakSadnje = $_POST['razmakSadnje'];
    $razmakRedovi = $_POST['razmakRedovi'];
    $godinaSadnje = $_POST['godinaSadnje'];

    // Provjera da li su svi podaci poslati ispravno
    if (!empty($sortaID) && !empty($parcelaID) && !empty($razmakSadnje) && !empty($razmakRedovi) && !empty($godinaSadnje)) {

        // Provjeri da li sorta već postoji na toj parceli
        $checkQuery = "SELECT * FROM parcelesorte WHERE sortaID = :sortaID AND parcelaID = :parcelaID";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bindParam(':sortaID', $sortaID);
        $checkStmt->bindParam(':parcelaID', $parcelaID);
        $checkStmt->execute();

        if ($checkStmt->rowCount() > 0) {
            // Ako postoji, vrati poruku o grešci
            echo json_encode(['status' => 'error', 'message' => 'Sorta već postoji na odabranoj parceli.']);
        } else {
            // Unos novih podataka ako sorta ne postoji
            $query = "INSERT INTO parcelesorte (sortaID, parcelaID, razmakSadnje, razmakRedovi, godinaSadnje) 
                      VALUES (:sortaID, :parcelaID, :razmakSadnje, :razmakRedovi, :godinaSadnje)";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':sortaID', $sortaID);
            $stmt->bindParam(':parcelaID', $parcelaID);
            $stmt->bindParam(':razmakSadnje', $razmakSadnje);
            $stmt->bindParam(':razmakRedovi', $razmakRedovi);
            $stmt->bindParam(':godinaSadnje', $godinaSadnje);

            // Execute query and check for errors
            if ($stmt->execute()) {
                // Ako je uspješno dodano, vrati JSON odgovor
                echo json_encode(['status' => 'success', 'message' => 'Sorta na parceli uspješno dodata.']);
            } else {
                // Ako postoji greška, vrati detalje greške
                $errorInfo = $stmt->errorInfo();
                echo json_encode(['status' => 'error', 'message' => 'Greška pri dodavanju sorte na parcelu.', 'errorInfo' => $errorInfo]);
            }
        }
    } else {
        // Ako polja nisu ispravno popunjena, vrati grešku
        echo json_encode(['status' => 'error', 'message' => 'Molimo popunite sva polja.']);
    }
}
?>
