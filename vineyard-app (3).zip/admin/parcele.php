<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Povlačenje svih parcela zajedno sa proizvođačem
$query = "SELECT p.parcelaID, p.nazivParcele, p.karastarskaOpstina, p.brojKatastarskeParcele, p.povrsinaParceleHa, pr.nazivProizvodjaca
          FROM parcele p
          LEFT JOIN proizvodjaci pr ON p.proizvodjacID = pr.proizvodjacID";

$stmt = $conn->prepare($query);
$stmt->execute();
$parcele = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Povlačenje svih proizvođača za padajuću listu
$query = "SELECT proizvodjacID, nazivProizvodjaca FROM proizvodjaci";
$stmt = $conn->prepare($query);
$stmt->execute();
$proizvodjaci = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Brojanje parcela (Za grafikon)
$queryCount = "SELECT COUNT(*) as brojParcela FROM parcele";
$stmtCount = $conn->prepare($queryCount);
$stmtCount->execute();
$brojParcela = $stmtCount->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parcele</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 1000px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #143a51;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        button {
            padding: 10px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
        .action-buttons button {
            background: none;
            border: none;
            color: #668846;
            cursor: pointer;
            font-size: 16px;
            transition: color 0.3s ease;
        }
        .action-buttons button:hover {
            color: #556b35;
        }
        .search-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            align-items: center;
        }
        .search-container input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 80%;
        }
        .chart-container {
            width: 80%;
            margin: 0 auto 20px auto;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            font-family: Arial, sans-serif;
        }
        .form-container button {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .form-container button:hover {
            background-color: #556b35;
        }
        #poruka {
            margin-top: 10px;
            text-align: center;
            font-size: 16px;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Parcele</h1>
<!-- Dugme za povratak na index.php sa strelicom -->
    <button class="back-button" onclick="window.location.href='aindex.php'">&#8592;</button>
    <!-- Grafikon koji prikazuje ukupan broj parcela -->
    <div class="chart-container">
        <canvas id="parceleChart"></canvas>
    </div>

    <!-- Polje za pretragu i dugme za prikaz i sakrivanje parcela -->
    <div class="search-container">
        <input type="text" id="search" placeholder="Pretraži po nazivu parcele ili proizvođaču">
        <button id="toggleBtn">Prikaži sve parcele</button>
    </div>

    <table id="parceleTable">
        <thead>
            <tr>
                <th>Naziv Parcele</th>
                <th>Katastarska opština</th>
                <th>Broj katastarske parcele</th>
                <th>Površina (ha)</th>
                <th>Proizvođač</th>
                <th>Akcije</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($parcele as $parcela): ?>
            <tr>
                <td><?php echo htmlspecialchars($parcela['nazivParcele']); ?></td>
                <td><?php echo htmlspecialchars($parcela['karastarskaOpstina']); ?></td>
                <td><?php echo htmlspecialchars($parcela['brojKatastarskeParcele']); ?></td>
                <td><?php echo htmlspecialchars($parcela['povrsinaParceleHa']); ?></td>
                <td><?php echo htmlspecialchars($parcela['nazivProizvodjaca'] ?: 'Nepoznat'); ?></td>
                <td class="action-buttons">
                    <button onclick="window.location.href='urediP.php?id=<?php echo $parcela['parcelaID']; ?>'">Uredi</button>
                    <button onclick="deleteParcela(<?php echo $parcela['parcelaID']; ?>)">Obriši</button>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div class="form-container">
        <h2>Dodaj novu parcelu</h2>
        <form id="dodajParceluForm">
            <div class="form-group">
                <label for="nazivParcele">Naziv parcele:</label>
                <input type="text" name="nazivParcele" id="nazivParcele" placeholder="Naziv parcele" required>
            </div>
            <div class="form-group">
                <label for="karastarskaOpstina">Katastarska opština:</label>
                <input type="text" name="karastarskaOpstina" id="karastarskaOpstina" placeholder="Katastarska Opština" required>
            </div>
            <div class="form-group">
                <label for="brojKatastarskeParcele">Broj katastarske parcele:</label>
                <input type="text" name="brojKatastarskeParcele" id="brojKatastarskeParcele" placeholder="Broj Katastarske Parcele" pattern="\[\d+(,\s?\d+)*\]" title="Unesite brojeve u formatu: [broj1, broj2, broj3]" required>
            </div>
            <div class="form-group">
                <label for="povrsinaParceleHa">Površina parcele (ha):</label>
                <input type="text" name="povrsinaParceleHa" id="povrsinaParceleHa" placeholder="Površina parcele u hektarima" pattern="[0-9]+" required>
            </div>
            <div class="form-group">
                <label for="proizvodjacID">Izaberi proizvođača:</label>
                <select name="proizvodjacID" id="proizvodjacID" required>
                    <option value="" disabled selected hidden>Izaberi proizvođača</option>
                    <?php foreach ($proizvodjaci as $proizvodjac): ?>
                        <option value="<?= $proizvodjac['proizvodjacID'] ?>"><?= $proizvodjac['nazivProizvodjaca'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit">Dodaj</button>
        </form>
        
        <div id="poruka"></div>
    </div>

    <script>
        document.getElementById('dodajParceluForm').addEventListener('submit', function(e) {
            e.preventDefault(); // Sprečava osvežavanje stranice

            // Formiranje podataka iz forme
            let formData = new FormData(this);

            // Slanje AJAX zahteva
            fetch('dodajParcelu.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json()) // Parsiraj odgovor kao JSON
            .then(data => {
                if (data.status === 'success') {
                    document.getElementById('poruka').textContent = data.message;
                    document.getElementById('poruka').style.color = 'green';
                    location.reload();
                } else {
                    document.getElementById('poruka').textContent = data.message;
                    document.getElementById('poruka').style.color = 'red';
                }
                // Očisti formu nakon uspešnog dodavanja
                if (data.status === 'success') {
                    document.getElementById('dodajParceluForm').reset();
                }
            })
            .catch(error => {
                console.error('Došlo je do greške:', error);
                document.getElementById('poruka').textContent = 'Došlo je do greške pri dodavanju parcele.';
                document.getElementById('poruka').style.color = 'red';
            });
        });

       function deleteParcela(id) {
            if (confirm('Da li ste sigurni da želite obrisati ovu parcelu?')) {
                fetch('obrisiP.php?id=' + id, {
                    method: 'GET', 
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        const row = document.querySelector(`button[onclick="deleteParcela(${id})"]`).closest('tr');
                        row.remove();
                        alert(data.message);
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Došlo je do greške:', error));
            }
        }

        const ctx = document.getElementById('parceleChart').getContext('2d');
        const parceleChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Parcele'],
                datasets: [{
                    label: 'Ukupno Parcela',
                    data: [<?php echo $brojParcela['brojParcela']; ?>],
                    backgroundColor: '#668846',
                    borderColor: '#556b35',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        $('#search').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $('#parceleTable tbody tr').filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        $('#toggleBtn').on('click', function() {
            var table = $('#parceleTable');
            if (table.is(':visible')) {
                table.hide();
                $(this).text('Prikaži sve parcele');
            } else {
                table.show();
                $(this).text('Sakrij sve parcele');
            }
        });
    </script>
</div>
</body>
</html>
