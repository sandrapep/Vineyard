<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Dekodiraj JSON podatke
    $data = json_decode(file_get_contents('php://input'), true);

    // Provjeri da li je parcelasortaID postavljen i da li je validan broj
    if (!isset($data['parcelasortaID']) || !is_numeric($data['parcelasortaID'])) {
        echo json_encode(['status' => 'error', 'message' => 'Nije proslijeđen ispravan parcelasortaID.']);
        exit;
    }

    $parcelasortaID = intval($data['parcelasortaID']); // Osiguraj da parcelasortaID bude cijeli broj

    $db = new Database();
    $conn = $db->getConnection();

    // Brisanje veze između sorte i parcele na osnovu parcelasortaID
    $queryParcelaSorta = "DELETE FROM parcelesorte WHERE parcelasortaID = :parcelasortaID";
    $stmtParcelaSorta = $conn->prepare($queryParcelaSorta);
    $stmtParcelaSorta->bindParam(':parcelasortaID', $parcelasortaID, PDO::PARAM_INT);
    
    if ($stmtParcelaSorta->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Uspješno obrisana sorta na parceli.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške pri brisanju sorte na parceli.']);
    }
}
?>
