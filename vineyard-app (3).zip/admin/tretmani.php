<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Provera koji je jezik izabran, podrazumevano je 'mne'
$jezik = isset($_POST['jezik']) ? $_POST['jezik'] : 'mne';

// Povlačenje tretmana na osnovu odabranog jezika
$query = "SELECT TT.tipTretmanaID, TT.nazivTretmana, TT.opisTretmana, TT.jezik
          FROM tiptretmana TT
          WHERE TT.jezik = :jezik";
$stmt = $conn->prepare($query);
$stmt->bindParam(':jezik', $jezik);
$stmt->execute();
$tretmani = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Brojanje tretmana (za grafikon)
$queryCount = "SELECT COUNT(*) as brojTretmana FROM tiptretmana WHERE jezik = :jezik";
$stmtCount = $conn->prepare($queryCount);
$stmtCount->bindParam(':jezik', $jezik);
$stmtCount->execute();
$brojTretmana = $stmtCount->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tretmani</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 1000px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #143a51;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        button {
            padding: 10px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
        .action-buttons button {
            background: none;
            border: none;
            color: #668846;
            cursor: pointer;
            font-size: 16px;
            transition: color 0.3s ease;
        }
        .action-buttons button:hover {
            color: #556b35;
        }
        .search-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            align-items: center;
        }
        .search-container input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 80%;
        }
        .chart-container {
            width: 80%;
            margin: 0 auto 20px auto;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            font-family: Arial, sans-serif;
        }
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        .form-container button {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .form-container button:hover {
            background-color: #556b35;
        }
        #poruka {
            margin-top: 10px;
            text-align: center;
            font-size: 16px;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
        .radio-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .radio-container label {
            margin-right: 15px;
            font-size: 16px;
            cursor: pointer;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px; /* Veća strelica */
            font-weight: bold; /* Deblja strelica */
            background-color: #143a51; /* Dodata boja pozadine */
            border: 2px solid #0f2e41; /* Dodan okvir */
            border-radius: 8px; /* Zaobljeni uglovi */
            color: #ffffff; /* Boja strelice */
            padding: 10px 15px; /* Razmak unutar dugmeta */
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease; /* Efekat prelaza */
            }
        
        .back-button:hover {
            background-color: #668846; /* Tamnija pozadina pri hover-u */
            border-color: #143a51; /* Promena boje okvira pri hover-u */
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Tretmani</h1>
    
    <button class="back-button" onclick="window.location.href='aindex.php'">&#8592;</button>
    <!-- Grafikon koji prikazuje ukupan broj tretmana -->
    <div class="chart-container">
        <canvas id="tretmaniChart"></canvas>
    </div>
    <div class="search-container">
        <input type="text" id="search" placeholder="Pretraži po tretmanu">
        <button id="toggleBtn" >Prikaži/Sakrij tabelu</button>
        
    </div>

    <!-- Radio dugmad za izbor jezika -->
    <div class="radio-container" id="radioLang">
        <label>
            <input type="radio" name="jezik" value="mne" <?php if ($jezik === 'mne') echo 'checked'; ?>> MNE
        </label>
        <label>
            <input type="radio" name="jezik" value="eng" <?php if ($jezik === 'eng') echo 'checked'; ?>> ENG
        </label>
    </div>

    <table id="tretmaniTable">
    <thead>
        <tr>
            <th>Naziv tretmana</th>
            <th>Opis</th>
            <th>Jezik</th>
            <th>Akcije</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($tretmani as $tretman): ?>
        <tr>
            <td><?php echo htmlspecialchars($tretman['nazivTretmana']); ?></td>
            <td><?php echo htmlspecialchars($tretman['opisTretmana']); ?></td>
            <td><?php echo htmlspecialchars($tretman['jezik']); ?></td>
            <td class="action-buttons">
                <button onclick="window.location.href='urediT.php?id=<?php echo $tretman['tipTretmanaID']; ?>'">Uredi</button>
                <button onclick="window.location.href='obrisiT.php?id=<?php echo $tretman['tipTretmanaID']; ?>'">Obriši</button>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    </table>

    <!-- Dodavanje tretmana -->
    <div class="form-container">
        <h2>Dodaj novi tretman</h2>
        <form id="dodajTretmanForm">
            <div class="form-group">
                <label for="nazivTretmana">Naziv tretmana:</label>
                <input type="text" name="nazivTretmana" id="nazivTretmana" required>
            </div>
            <div class="form-group">
                <label for="opisTretmana">Opis:</label>
                <textarea name="opisTretmana" id="opisTretmana" placeholder="Opis tretmana" required></textarea>
            </div>
            <div class="form-group">
                <label for="jezik">Jezik:</label>
                <select name="jezik" id="jezik" required>
                    <option value="mne">MNE</option>
                    <option value="eng">ENG</option>
                </select>
            </div>
            <button type="submit">Dodaj</button>
        </form>
        <div id="poruka"></div>
    </div>

    <script>
        $(document).ready(function() {
    // Promena jezika
    $('input[name="jezik"]').change(function() {
        var selectedLang = $(this).val();
        $.post('tretmani.php', { jezik: selectedLang }, function(data) {
            $('body').html(data);  // Osvježava stranicu sa novim podacima
        });
    });

    // Prikazivanje/sakrivanje tabele
    $('#toggleBtn').click(function() {
        $('#tretmaniTable').toggle();
    });

    // Prikazivanje grafikona
    const ctx = document.getElementById('tretmaniChart').getContext('2d');
    const tretmaniChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Tretmani'],
            datasets: [{
                label: 'Ukupno tretmana',
                data: [<?php echo $brojTretmana['brojTretmana']; ?>],
                backgroundColor: '#668846',
                borderColor: '#556b35',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Pretraga po nazivu tretmana
    $('#search').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        $('#tretmaniTable tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });

   // Dodavanje novog tretmana putem AJAX-a
    $('#dodajTretmanForm').on('submit', function(e) {
        e.preventDefault();  // Sprečava osvežavanje stranice

        // Preuzimanje podataka iz forme
        var formData = $(this).serialize();  // Serijalizuje sve podatke iz forme

        // Slanje AJAX zahteva
        $.ajax({
            url: 'dodajTretman.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    // Prikaz poruke o uspehu
                    $('#poruka').html('<span style="color:green;">' + response.message + '</span>');

                    // Osvežavanje stranice nakon 2 sekunde
                    setTimeout(function() {
                        location.reload();  // Osvežava stranicu
                    }, 2000);
                } else {
                    // Prikaz poruke o grešci
                    $('#poruka').html('<span style="color:red;">' + response.message + '</span>');
                }
            },
            error: function() {
                $('#poruka').html('<span style="color:red;">Došlo je do greške pri obradi zahteva.</span>');
            }
        });
    });
        });
    </script>
</div>
</body>
</html>
