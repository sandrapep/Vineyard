<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Dekodiraj JSON podatke iz POST zahteva
    $data = json_decode(file_get_contents('php://input'), true);

    // Proveri da li je sortaID poslat i validan
    if (empty($data['sortaID']) || !is_numeric($data['sortaID'])) {
        echo json_encode(['status' => 'error', 'message' => 'Neispravan ID sorte.']);
        exit();
    }

    $sortaID = intval($data['sortaID']);

    // Provera da li sorta postoji u bazi
    $query = "SELECT sortaID FROM sorte WHERE sortaID = :sortaID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':sortaID', $sortaID);
    if (!$stmt->execute()) {
        echo json_encode(['status' => 'error', 'message' => 'Greška prilikom pretrage sorte.', 'errorInfo' => $stmt->errorInfo()]);
        exit();
    }

    if ($stmt->rowCount() === 0) {
        echo json_encode(['status' => 'error', 'message' => 'Sorta nije pronađena.']);
        exit();
    }

    // Brisanje sorte
    $query = "DELETE FROM sorte WHERE sortaID = :sortaID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':sortaID', $sortaID);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Sorta uspješno obrisana.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške pri brisanju sorte.', 'errorInfo' => $stmt->errorInfo()]);
    }
}
