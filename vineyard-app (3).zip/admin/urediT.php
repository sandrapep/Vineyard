<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

$tipTretmanaID = $_GET['id']; // Preuzmi tipTretmanaID iz URL-a

// Preuzimanje podataka o tretmanu, uključujući jezik
$query = "SELECT TT.nazivTretmana, TT.opisTretmana, TT.jezik
          FROM tiptretmana TT
          WHERE TT.tipTretmanaID = :tipTretmanaID";
$stmt = $conn->prepare($query);
$stmt->bindParam(':tipTretmanaID', $tipTretmanaID, PDO::PARAM_INT);
$stmt->execute();
$tretman = $stmt->fetch(PDO::FETCH_ASSOC);

// Preuzimanje svih tipova tretmana za padajući meni
$queryTretmani = "SELECT tipTretmanaID, nazivTretmana FROM tiptretmana";
$stmtTretmani = $conn->prepare($queryTretmani);
$stmtTretmani->execute();
$tretmani = $stmtTretmani->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivTretmana = $_POST['nazivTretmana'];
    $opisTretmana = $_POST['opisTretmana'];
    $jezik = $_POST['jezik']; // Preuzimanje jezika iz forme

    // Ažuriranje tipa tretmana sa jezikom
    $query = "UPDATE tiptretmana 
              SET nazivTretmana = :nazivTretmana, opisTretmana = :opisTretmana, jezik = :jezik 
              WHERE tipTretmanaID = :tipTretmanaID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivTretmana', $nazivTretmana);
    $stmt->bindParam(':opisTretmana', $opisTretmana);
    $stmt->bindParam(':jezik', $jezik); // Ažuriranje jezika
    $stmt->bindParam(':tipTretmanaID', $tipTretmanaID, PDO::PARAM_INT);
    $stmt->execute();

    header("Location: tretmani.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi Tretman</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846;
            padding: 20px;
            justify-content: center;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            margin-bottom: 20px;
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
            align-items: center;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
            justify-content: center;
            max-width: 300px;
        }
        input, textarea, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            font-family: Arial, sans-serif;
        }
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        button {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi tretman</h1>
    <form method="post" action="urediT.php?id=<?php echo $tipTretmanaID; ?>">
        <!-- Polje za naziv tretmana -->
        <div class="form-group">
            <label for="nazivTretmana">Naziv tretmana:</label>
            <input type="text" name="nazivTretmana" id="nazivTretmana" value="<?php echo htmlspecialchars($tretman['nazivTretmana']); ?>" required>
        </div>

        <!-- Polje za opis tretmana -->
        <div class="form-group">
            <label for="opisTretmana">Opis tretmana:</label>
            <textarea name="opisTretmana" id="opisTretmana" required><?php echo htmlspecialchars($tretman['opisTretmana']); ?></textarea>
        </div>

        <!-- Polje za izbor jezika -->
        <div class="form-group">
            <label for="jezik">Jezik:</label>
            <select name="jezik" id="jezik" required>
                <option value="mne" <?php if ($tretman['jezik'] === 'mne') echo 'selected'; ?>>MNE</option>
                <option value="eng" <?php if ($tretman['jezik'] === 'eng') echo 'selected'; ?>>ENG</option>
            </select>
        </div>

        <!-- Dugme za čuvanje -->
        <button type="submit">Sačuvaj</button>
    </form>
</div>
</body>
</html>
