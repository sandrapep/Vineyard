<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivProizvodjaca = $_POST['nazivProizvodjaca'];
    $registarskiBroj = $_POST['registarskiBroj'];
    $adresa = $_POST['adresa'];
    $gradID = $_POST['gradID'];
    $eMail = $_POST['eMail'];
    $telefon = $_POST['telefon'];
    $slika = $_POST['slika'];
    $linkZaPodatkeNaslovna = $_POST['linkZaPodatkeNaslovna'];

    $db = new Database();
    $conn = $db->getConnection();

    $query = "
        INSERT INTO proizvodjaci (nazivProizvodjaca, registarskiBroj, adresa, gradID, eMail, telefon, slika, linkZaPodatkeNaslovna)
        VALUES (:nazivProizvodjaca, :registarskiBroj, :adresa, :gradID, :eMail, :telefon, :slika, :linkZaPodatkeNaslovna)
    ";

    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivProizvodjaca', $nazivProizvodjaca);
    $stmt->bindParam(':registarskiBroj', $registarskiBroj);
    $stmt->bindParam(':adresa', $adresa);
    $stmt->bindParam(':gradID', $gradID);
    $stmt->bindParam(':eMail', $eMail);
    $stmt->bindParam(':telefon', $telefon);
    $stmt->bindParam(':slika', $slika);
    $stmt->bindParam(':linkZaPodatkeNaslovna', $linkZaPodatkeNaslovna);

    if ($stmt->execute()) {
        header("Location: proizvodjaci.php?status=success");
    } else {
        echo "Greška prilikom dodavanja proizvođača.";
    }
}
?>

