<?php
include '../db.php';

$db = new Database();
$conn = $db->getConnection();

$proizvodjacID = $_GET['proizvodjacID'];

$query = "SELECT PS.parcelaSortaID, parcele.nazivParcele, sorte.nazivSorte 
          FROM parcelesorte PS
          JOIN parcele ON PS.parcelaID = parcele.parcelaID
          JOIN sorte ON PS.sortaID = sorte.sortaID
          WHERE parcele.proizvodjacID = :proizvodjacID";

$stmt = $conn->prepare($query);
$stmt->bindParam(':proizvodjacID', $proizvodjacID);
$stmt->execute();
$parceleSorte = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($parceleSorte);
?>
