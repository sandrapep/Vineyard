<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Povlačenje svih proizvođača zajedno sa nazivom grada
$queryProizvodjaci = "
    SELECT DISTINCT p.*, g.nazivGrada 
    FROM proizvodjaci p 
    JOIN gradovi g ON p.gradID = g.gradID
";
$stmtProizvodjaci = $conn->prepare($queryProizvodjaci);
$stmtProizvodjaci->execute();
$proizvodjaci = $stmtProizvodjaci->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pregled proizvođača</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 1050px; /* Smanjena širina */
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            margin-bottom: 20px;
            text-align: center;
        }
        .form-container {
            margin-top: 20px;
        }
        .form-container h2 {
            color: #143a51;
            margin-bottom: 10px;
        }
        .form-control {
            margin-bottom: 10px;
        }
        .form-control label {
            display: block;
            margin-bottom: 5px;
        }
        .form-control input, .form-control select {
            width: 100%;
            padding: 8px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 10px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
        .search-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .search-container input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 80%;
        }
        table {
            width: 20%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            white-space: nowrap; /* Izbegava prelamanje */
        }
        th {
            background-color: #143a51;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .action-buttons a {
            color: #668846;
            font-weight: bold;
            cursor: pointer;
            margin-right: 10px;
        }
        .action-buttons a:hover {
            color: #556b35;
        }
        .chart-container {
            width: 80%;
            margin: 0 auto 20px auto;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px; /* Veća strelica */
            font-weight: bold; /* Deblja strelica */
            background-color: #143a51; /* Dodata boja pozadine */
            border: 2px solid #0f2e41; /* Dodan okvir */
            border-radius: 8px; /* Zaobljeni uglovi */
            color: #ffffff; /* Boja strelice */
            padding: 10px 15px; /* Razmak unutar dugmeta */
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease; /* Efekat prelaza */
            }
        
        .back-button:hover {
            background-color: #668846; /* Tamnija pozadina pri hover-u */
            border-color: #143a51; /* Promena boje okvira pri hover-u */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Proizvođači</h1>
<!-- Dugme za povratak na index.php sa strelicom -->
    <button class="back-button" onclick="window.location.href='aindex.php'">&#8592;</button>
        <!-- Grafikon sa ukupnim brojem proizvođača -->
        <div class="chart-container">
            <canvas id="chartProizvodjaci"></canvas>
        </div>

        <!-- Pretraga i dugme za prikaz/sakrij tabelu -->
        <div class="search-container">
            <input type="text" id="search" placeholder="Pretraži po nazivu proizvođača">
            <button id="toggleTable">Prikaži/Sakrij tabelu</button>
        </div>

        <!-- Tabela sa proizvođačima -->
        <table id="proizvodjaciTable">
            <thead>
                <tr>
                    <th>Naziv proizvođača</th>
                    <th>Registarski broj</th>
                    <th>Adresa</th>
                    <th>Grad</th>
                    <th>E-mail</th>
                    <th>Telefon</th>
                    <th>Akcije</th>
                </tr>
            </thead>
            <tbody>
    <?php foreach ($proizvodjaci as $proizvodjac): ?>
    <tr id="row-<?php echo $proizvodjac['proizvodjacID']; ?>">  <!-- Dodaj jedinstveni ID -->
        <td><?php echo htmlspecialchars($proizvodjac['nazivProizvodjaca']); ?></td>
        <td><?php echo htmlspecialchars($proizvodjac['registarskiBroj']); ?></td>
        <td><?php echo htmlspecialchars($proizvodjac['adresa']); ?></td>
        <td><?php echo htmlspecialchars($proizvodjac['nazivGrada']); ?></td>
        <td><?php echo htmlspecialchars($proizvodjac['eMail']); ?></td>
        <td><?php echo htmlspecialchars($proizvodjac['telefon']); ?></td>
        <td class="action-buttons">
            <a href="urediProizvodjaca.php?id=<?php echo $proizvodjac['proizvodjacID']; ?>">Uredi</a>
            <a href="#" onclick="obrisiProizvodjaca(<?php echo $proizvodjac['proizvodjacID']; ?>)">Obriši</a>
        </td>
    </tr>
    <?php endforeach; ?>
</tbody>

        </table>

        <!-- Forma za dodavanje novog proizvođača -->
        <div class="form-container" id="addForm">
            <h2>Dodaj novog proizvođača</h2>
            <form action="dodajProizvodjaca.php" method="POST">
                <div class="form-control">
                    <label for="nazivProizvodjaca">Naziv proizvođača</label>
                    <input type="text" name="nazivProizvodjaca" required>
                </div>
                <div class="form-control">
                    <label for="registarskiBroj">Registarski broj</label>
                    <input type="text" name="registarskiBroj" pattern="[0-9]+[A-Za-z]{2}"  required>
                </div>
                <div class="form-control">
                    <label for="adresa">Adresa</label>
                    <input type="text" name="adresa" required>
                </div>
                <div class="form-control">
                    <label for="gradID">Grad</label>
                    <select name="gradID">
                        <option value="1">Podgorica</option>
                        <option value="2">Nikšić</option>
                        <option value="3">Pljevlja</option>
                        <option value="4">Bijelo Polje</option>
                        <option value="5">Cetinje</option>
                        <option value="6">Bar</option>
                        <option value="7">Herceg Novi</option>
                        <option value="8">Berane</option>
                        <option value="9">Budva</option>
                        <option value="10">Ulcinj</option>
                        <option value="11">Tivat</option>
                        <option value="12">Rožaje</option>
                        <option value="13">Kotor</option>
                        <option value="14">Danilovgrad</option>
                        <option value="15">Mojkovac</option>
                        <option value="16">Plav</option>
                        <option value="17">Kolašin</option>
                        <option value="18">Žabljak</option>
                        <option value="19">Plužine</option>
                        <option value="20">Andrijevica</option>
                    </select>
                </div>
                <div class="form-control">
                    <label for="eMail">E-mail</label>
                    <input type="email" name="eMail" required>
                </div>
                <div class="form-control">
                    <label for="telefon">Telefon</label>
                    <input type="text" name="telefon" pattern="[0-9]+"  required>
                </div>
                <div class="form-control">
                    <label for="slika">Slika (URL)</label>
                    <input type="text" name="slika" optional>
                </div>
                <div class="form-control">
                    <label for="linkZaPodatkeNaslovna"></label>
                    <input type="text" name="linkZaPodatkeNaslovna" optional>
                </div>
                <button type="submit">Dodaj proizvođača</button>
            </form>
        </div>
    </div>

    <script>
        // Prikaz grafika
        const ctx = document.getElementById('chartProizvodjaci').getContext('2d');
        const chartData = {
            labels: ['Ukupni proizvođači'],
            datasets: [{
                label: 'Broj proizvođača',
                data: [<?php echo count($proizvodjaci); ?>],
                backgroundColor: '#668846',
                borderColor: '#556b35',
                borderWidth: 1
            }]
        };

        const chartProizvodjaci = new Chart(ctx, {
            type: 'bar',
            data: chartData,
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Filter pretrage
        document.getElementById('search').addEventListener('keyup', function() {
            var value = this.value.toLowerCase();
            var rows = document.querySelectorAll('#proizvodjaciTable tbody tr');
            rows.forEach(function(row) {
                var rowText = row.textContent.toLowerCase();
                row.style.display = rowText.includes(value) ? '' : 'none';
            });
        });

        // Prikaži/sakrij tabelu
        document.getElementById('toggleTable').addEventListener('click', function() {
            const tableContainer = document.getElementById('proizvodjaciTable');
            tableContainer.style.display = tableContainer.style.display === 'none' ? 'table' : 'none';
        });

       // Brisanje proizvođača
    function obrisiProizvodjaca(id) {
    if (confirm('Da li ste sigurni da želite obrisati ovog proizvođača?')) {
        fetch('obrisiProizvodjaca.php?id=' + id, {
            method: 'GET',
        })
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error('Greška prilikom komunikacije sa serverom.');
            }
        })
        .then(data => {
            if (data.status === 'Podaci uspjesno obrisani') {
                // Uspješno brisanje - uklanjanje reda iz tabele
                document.querySelector(`#row-${id}`).remove();
            } else {
                alert('Greška prilikom brisanja.');
            }
        })
        .catch(error => {
            console.error('Došlo je do greške:', error);
        });
    }
}

    </script>
</body>
</html>
