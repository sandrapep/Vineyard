<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

if (isset($_GET['id'])) {
    $proizvodjacID = $_GET['id'];

    $db = new Database();
    $conn = $db->getConnection();

    $query = "DELETE FROM proizvodjaci WHERE proizvodjacID = :proizvodjacID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':proizvodjacID', $proizvodjacID);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'Podaci uspjesno obrisani']);
    } else {
        echo json_encode(['status' => 'Greska']);
    }
}
?>
