<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nazivTretmana = $_POST['nazivTretmana'];
    $opisTretmana = $_POST['opisTretmana'];
    $jezik = $_POST['jezik']; // Preuzimanje jezika iz forme

    // Povezivanje sa bazom podataka
    $db = new Database();
    $conn = $db->getConnection();

    // Upit za unos novog tretmana sa jezikom
    $query = "INSERT INTO tiptretmana (nazivTretmana, opisTretmana, jezik) 
              VALUES (:nazivTretmana, :opisTretmana, :jezik)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivTretmana', $nazivTretmana);
    $stmt->bindParam(':opisTretmana', $opisTretmana);
    $stmt->bindParam(':jezik', $jezik); // Povezivanje jezika

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Tretman je uspešno dodat!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške pri dodavanju tretmana.']);
    }
}
?>
