<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $godina = $_POST['godina'];
    $parcelaSortaID = $_POST['parcelaSortaID'];
    $iznos = $_POST['iznos'];

    $db = new Database();
    $conn = $db->getConnection();

    $query = "INSERT INTO prinosi (godina, parcelaSortaID, iznos) VALUES (:godina, :parcelaSortaID, :iznos)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':godina', $godina);
    $stmt->bindParam(':parcelaSortaID', $parcelaSortaID);
    $stmt->bindParam(':iznos', $iznos);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Prinos uspješno dodat!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške pri dodavanju prinosa.']);
    }
}
?>
