<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $parcelaID = $_GET['id'];

        $query = "DELETE FROM parcele WHERE parcelaID = :parcelaID";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':parcelaID', $parcelaID, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Parcela uspješno obrisana.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške pri brisanju parcele.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Nije proslijeđen validan ID parcele.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Neispravan zahtjev.']);
}
?>
