<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);
    if (isset($input['prinosID']) && is_numeric($input['prinosID'])) {
        $prinosID = $input['prinosID'];

        $db = new Database();
        $conn = $db->getConnection();

        $query = "DELETE FROM prinosi WHERE prinosID = :prinosID";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':prinosID', $prinosID, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Prinos uspješno obrisan.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške pri brisanju prinosa.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Nije proslijeđen validan ID prinosa.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Neispravan zahtjev.']);
}
?>
