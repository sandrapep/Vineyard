<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Povlačenje svih korisnika
$query = "SELECT * FROM korisnici";
$stmt = $conn->prepare($query);
$stmt->execute();
$korisnici = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administracija korisnika</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 1000px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #143a51;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        button {
            padding: 10px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
        .action-buttons button {
            margin-right: 5px;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            font-family: Arial, sans-serif;
        }
        .form-container button {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .form-container button:hover {
            background-color: #556b35;
        }
        #poruka {
            margin-top: 10px;
            text-align: center;
            font-size: 16px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Korisnici</h1>
    <button class="back-button" onclick="window.location.href='aindex.php'">&#8592;</button>

    <!-- Tabela korisnika -->
    <table>
        <thead>
            <tr>
                <th>Ime</th>
                <th>Prezime</th>
                <th>Email</th>
                <th>Telefon</th>
                <th>Tip naloga</th>
                <th>Akcije</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($korisnici as $korisnik): ?>
            <tr>
                <td><?php echo htmlspecialchars($korisnik['ime']); ?></td>
                <td><?php echo htmlspecialchars($korisnik['prezime']); ?></td>
                <td><?php echo htmlspecialchars($korisnik['eMail']); ?></td>
                <td><?php echo htmlspecialchars($korisnik['telefon']); ?></td>
                <td><?php echo htmlspecialchars($korisnik['tipNaloga']); ?></td>
                <td class="action-buttons">
                    <button onclick="window.location.href='urediK.php?id=<?php echo $korisnik['korisnikID']; ?>'">Uredi</button>
                    <button onclick="window.location.href='obrisiK.php?id=<?php echo $korisnik['korisnikID']; ?>'">Obriši</button>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Forma za dodavanje korisnika -->
    <div class="form-container">
        <h2>Dodaj korisnika</h2>
        <form id="dodajKorisnikaForm">
            <div class="form-group">
                <label for="ime">Ime:</label>
                <input type="text" name="ime" id="ime" placeholder="Ime korisnika" required>
            </div>
            <div class="form-group">
                <label for="prezime">Prezime:</label>
                <input type="text" name="prezime" id="prezime" placeholder="Prezime korisnika" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" placeholder="Email korisnika" required>
            </div>
            <div class="form-group">
                <label for="telefon">Telefon:</label>
                <input type="text" name="telefon" id="telefon" placeholder="Telefon korisnika" pattern="[0-9]+" required>
            </div>
            <div class="form-group">
                <label for="tipNaloga">Tip naloga:</label>
                <select name="tipNaloga" id="tipNaloga" required>
                    <option value="korisnik">Korisnik</option>
                    <option value="admin">Administrator</option>
                </select>
            </div>
            <div class="form-group">
                <label for="lozinka">Lozinka:</label>
                <input type="password" name="lozinka" id="lozinka" placeholder="Unesite lozinku" required>
            </div>
            <button type="submit">Dodaj korisnika</button>
        </form>
        <div id="poruka"></div>
    </div>
</div>

<script>
    document.getElementById('dodajKorisnikaForm').addEventListener('submit', function(e) {
        e.preventDefault(); // Sprečava osvežavanje stranice

        let formData = new FormData(this);

        // Slanje AJAX zahteva
        fetch('dodajKorisnika.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json()) // Parsiraj odgovor kao JSON
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('poruka').textContent = data.message;
                document.getElementById('poruka').style.color = 'green';
                document.getElementById('dodajKorisnikaForm').reset(); // Očisti formu nakon dodavanja
                location.reload();
                // Dodati novi red u tabelu
                const tbody = document.querySelector('table tbody');
                const newRow = document.createElement('tr');
                newRow.innerHTML = `
                    <td>${data.korisnik.ime}</td>
                    <td>${data.korisnik.prezime}</td>
                    <td>${data.korisnik.email}</td>
                    <td>${data.korisnik.telefon}</td>
                    <td>${data.korisnik.tipNaloga}</td>
                    <td class="action-buttons">
                        <button onclick="window.location.href='urediK.php?id=${data.korisnik.korisnikID}'">Uredi</button>
                        <button onclick="window.location.href='obrisiK.php?id=${data.korisnik.korisnikID}'">Obriši</button>
                    </td>`;
                tbody.appendChild(newRow);
            } else {
                document.getElementById('poruka').textContent = data.message;
                document.getElementById('poruka').style.color = 'red';
            }
        })
        .catch(error => {
            console.error('Došlo je do greške:', error);
            document.getElementById('poruka').textContent = 'Došlo je do greške pri dodavanju korisnika.';
            document.getElementById('poruka').style.color = 'red';
        });
    });
</script>
</body>
</html>
