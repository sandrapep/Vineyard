<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$id = $_GET['id'];
$db = new Database();
$conn = $db->getConnection();

// Povlačenje podataka o korisniku
$query = "SELECT * FROM korisnici WHERE korisnikID = :id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':id', $id);
$stmt->execute();
$korisnik = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $email = $_POST['email'];
    $telefon = $_POST['telefon'];
    $tipNaloga = $_POST['tipNaloga'];

    $query = "UPDATE korisnici SET ime = :ime, prezime = :prezime, eMail = :email, telefon = :telefon, tipNaloga = :tipNaloga WHERE korisnikID = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':ime', $ime);
    $stmt->bindParam(':prezime', $prezime);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':telefon', $telefon);
    $stmt->bindParam(':tipNaloga', $tipNaloga);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        header("Location: korisnici.php");
        exit();
    } else {
        echo "Greška pri uređivanju korisnika.";
    }
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi korisnika</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 10px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi korisnika</h1>
    <form method="POST" action="urediK.php?id=<?php echo $id; ?>">
        <input type="text" name="ime" value="<?php echo htmlspecialchars($korisnik['ime']); ?>" required>
        <input type="text" name="prezime" value="<?php echo htmlspecialchars($korisnik['prezime']); ?>" required>
        <input type="email" name="email" value="<?php echo htmlspecialchars($korisnik['eMail']); ?>" required>
        <input type="text" name="telefon" value="<?php echo htmlspecialchars($korisnik['telefon']); ?> pattern="[0-9]+"" required>
        <select name="tipNaloga" required>
            <option value="korisnik" <?php echo $korisnik['tipNaloga'] == 'korisnik' ? 'selected' : ''; ?>>Korisnik</option>
            <option value="admin" <?php echo $korisnik['tipNaloga'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
        </select>
        <button type="submit">Sačuvaj izmjene</button>
    </form>
</div>
</body>
</html>
