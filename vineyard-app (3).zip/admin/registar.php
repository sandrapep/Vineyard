<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';
$db = new Database();
$conn = $db->getConnection();

// Fetch initial data for dropdowns - only producers with data in registarfenofaza through parcelesorte
function getDropdownData($conn, $sql) {
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Only fetch producers who have data in the registarfenofaza table through parcelesorteID
$proizvodjaci = getDropdownData($conn, "
    SELECT DISTINCT p.proizvodjacID, p.nazivProizvodjaca
    FROM proizvodjaci p
    JOIN parcele pa ON p.proizvodjacID = pa.proizvodjacID
    JOIN parcelesorte ps ON pa.parcelaID = ps.parcelaID
    JOIN registarfenofaza rf ON ps.parcelaSortaID = rf.parcelaSortaID
");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $response = [];

    if ($action == 'getFaze') {
        $conditions = [];
        $params = [];

        if (!empty($_POST['proizvodjacID'])) {
            $conditions[] = 'pr.proizvodjacID = :proizvodjacID';
            $params[':proizvodjacID'] = $_POST['proizvodjacID'];
        }
        if (!empty($_POST['parcelaID'])) {
            $conditions[] = 'ps.parcelaID = :parcelaID';
            $params[':parcelaID'] = $_POST['parcelaID'];
        }
        if (!empty($_POST['sortaID'])) {
            $conditions[] = 'ps.sortaID = :sortaID';
            $params[':sortaID'] = $_POST['sortaID'];
        }

        $sql = "SELECT pr.nazivProizvodjaca, p.nazivParcele, s.nazivSorte, f.nazivFaze, f.fenoKod, rf.datumVrijeme
                FROM registarfenofaza rf
                JOIN parcelesorte ps ON rf.parcelaSortaID = ps.parcelaSortaID
                JOIN parcele p ON ps.parcelaID = p.parcelaID
                JOIN sorte s ON ps.sortaID = s.sortaID
                JOIN fenoloskefaze f ON rf.fenoloskaFazaID = f.fenoloskaFazaID
                JOIN proizvodjaci pr ON p.proizvodjacID = pr.proizvodjacID";

        if (!empty($conditions)) {
            $sql .= ' WHERE ' . implode(' AND ', $conditions);
        }

        $stmt = $conn->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }

        $stmt->execute();
        $response = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($action == 'getParcele') {
        // Fetch parcels based on the selected producer
        $sql = "SELECT DISTINCT ps.parcelaID, p.nazivParcele 
                FROM parcele p 
                JOIN parcelesorte ps ON p.parcelaID = ps.parcelaID 
                WHERE p.proizvodjacID = :proizvodjacID";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':proizvodjacID', $_POST['proizvodjacID']);
        $stmt->execute();
        $response = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($action == 'getSorte') {
        // Fetch varieties based on the selected parcel
        $sql = "SELECT DISTINCT ps.sortaID, s.nazivSorte 
                FROM sorte s 
                JOIN parcelesorte ps ON s.sortaID = ps.sortaID 
                JOIN registarfenofaza rf ON ps.parcelaSortaID = rf.parcelaSortaID
                WHERE ps.parcelaID = :parcelaID";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':parcelaID', $_POST['parcelaID']);
        $stmt->execute();
        $response = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    echo json_encode($response);
    exit;
}
?>
<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Registar Feno Faza</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 1000px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #143a51;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        button {
            padding: 10px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        button:hover {
            background-color: #556b35;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #333;
        }
        select, input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            font-family: Arial, sans-serif;
            margin-bottom: 10px;
        }
        #poruka {
            margin-top: 10px;
            text-align: center;
            font-size: 18px;
            color: #668846;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        
        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Registar feno faza</h1>
    <button class="back-button" onclick="window.location.href='aindex.php'">&#8592;</button>
    
    <label for="proizvodjac">Izaberite proizvođača:</label>
    <select id="proizvodjac">
        <option value="">Izaberite proizvođača</option>
        <?php foreach ($proizvodjaci as $item): ?>
            <option value="<?= $item['proizvodjacID'] ?>"><?= htmlspecialchars($item['nazivProizvodjaca']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="parcela">Izaberite parcelu:</label>
    <select id="parcela" disabled>
        <option value="">Izaberite parcelu</option>
    </select>

    <label for="sorta">Izaberite sortu:</label>
    <select id="sorta" disabled>
        <option value="">Izaberite sortu</option>
    </select>

    <table id="fenoFazaTable">
        <thead>
            <tr>
                <th>Proizvođač</th>
                <th>Parcela</th>
                <th>Sorta</th>
                <th>Faza</th>
                <th>Feno kod</th>
                <th>Datum i vrijeme</th>
            </tr>
        </thead>
        <tbody id="fenoData"></tbody>
    </table>

    <div id="poruka"></div>
</div>

<script>
$(document).ready(function() {
    function azurirajPoruku(poruka) {
        $('#poruka').text(poruka);
    }

    $('#proizvodjac').on('change', function() {
        const proizvodjacID = $(this).val();
        $('#parcela').prop('disabled', true).html('<option value="">Izaberite parcelu</option>');
        $('#sorta').prop('disabled', true).html('<option value="">Izaberite sortu</option>');
        azurirajPoruku('');

        if (proizvodjacID) {
            $.post('', { action: 'getParcele', proizvodjacID: proizvodjacID }, function(data) {
                const parcele = JSON.parse(data);

                if (parcele.length > 0) {
                    let options = '<option value="">Izaberite parcelu</option>';
                    parcele.forEach(function(parcela) {
                        options += `<option value="${parcela.parcelaID}">${parcela.nazivParcele}</option>`;
                    });
                    $('#parcela').html(options).prop('disabled', false);
                } else {
                    azurirajPoruku('Ovaj proizvođač nema dostupnih parcela.');
                }
            });
        }
    });

    $('#parcela').on('change', function() {
        const parcelaID = $(this).val();
        $('#sorta').prop('disabled', true).html('<option value="">Izaberite sortu</option>');
        azurirajPoruku('');

        if (parcelaID) {
            $.post('', { action: 'getSorte', parcelaID: parcelaID }, function(data) {
                const sorte = JSON.parse(data);

                if (sorte.length > 0) {
                    let options = '<option value="">Izaberite sortu</option>';
                    sorte.forEach(function(sorta) {
                        options += `<option value="${sorta.sortaID}">${sorta.nazivSorte}</option>`;
                    });
                    $('#sorta').html(options).prop('disabled', false);
                } else {
                    azurirajPoruku('Ova parcela nema dostupnih sorti.');
                }
            });
        }
    });

    $('#proizvodjac, #parcela, #sorta').on('change', function() {
        const proizvodjacID = $('#proizvodjac').val();
        const parcelaID = $('#parcela').val();
        const sortaID = $('#sorta').val();

        $.post('', { action: 'getFaze', proizvodjacID: proizvodjacID, parcelaID: parcelaID, sortaID: sortaID }, function(data) {
            const parsedData = JSON.parse(data);
            if (parsedData.length === 0) {
                azurirajPoruku('Nema podataka za odabrane stavke.');
                $('#fenoData').html('');
            } else {
                azurirajPoruku('');
                let rows = '';
                parsedData.forEach(function(faza) {
                    rows += `
                        <tr>
                            <td>${faza.nazivProizvodjaca}</td>
                            <td>${faza.nazivParcele}</td>
                            <td>${faza.nazivSorte}</td>
                            <td>${faza.nazivFaze}</td>
                            <td>${faza.fenoKod}</td>
                            <td>${faza.datumVrijeme}</td>
                        </tr>
                    `;
                });
                $('#fenoData').html(rows);
            }
        });
    });
});
</script>

</body>
</html>
