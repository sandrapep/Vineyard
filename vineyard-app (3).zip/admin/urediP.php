<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

$parcelaID = $_GET['id'];

// Povlačenje podataka o parceli i trenutnom proizvođaču
$query = "SELECT * FROM parcele WHERE parcelaID = :parcelaID";
$stmt = $conn->prepare($query);
$stmt->bindParam(':parcelaID', $parcelaID, PDO::PARAM_INT);
$stmt->execute();
$parcela = $stmt->fetch(PDO::FETCH_ASSOC);

// Povlačenje svih proizvođača za padajuću listu
$queryProizvodjaci = "SELECT proizvodjacID, nazivProizvodjaca FROM proizvodjaci";
$stmtProizvodjaci = $conn->prepare($queryProizvodjaci);
$stmtProizvodjaci->execute();
$proizvodjaci = $stmtProizvodjaci->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivParcele = $_POST['nazivParcele'];
    $karastarskaOpstina = $_POST['karastarskaOpstina'];
    $brojKatastarskeParcele = $_POST['brojKatastarskeParcele'];
    $povrsinaParceleHa = $_POST['povrsinaParceleHa'];
    $proizvodjacID = $_POST['proizvodjacID'];

    // Ažuriranje podataka o parceli
    $query = "UPDATE parcele 
              SET nazivParcele = :nazivParcele, karastarskaOpstina = :karastarskaOpstina, 
                  brojKatastarskeParcele = :brojKatastarskeParcele, povrsinaParceleHa = :povrsinaParceleHa, 
                  proizvodjacID = :proizvodjacID
              WHERE parcelaID = :parcelaID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivParcele', $nazivParcele);
    $stmt->bindParam(':karastarskaOpstina', $karastarskaOpstina);
    $stmt->bindParam(':brojKatastarskeParcele', $brojKatastarskeParcele);
    $stmt->bindParam(':povrsinaParceleHa', $povrsinaParceleHa);
    $stmt->bindParam(':proizvodjacID', $proizvodjacID);
    $stmt->bindParam(':parcelaID', $parcelaID);

    if ($stmt->execute()) {
        header("Location: parcele.php");
        exit();
    } else {
        echo "Došlo je do greške pri ažuriranju parcele.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi Parcelu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 100%;
        }
        h1 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            font-family: Arial, sans-serif;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            max-width: 400px;
        }
        button {
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi Parcelu</h1>
    <form method="post" action="urediP.php?id=<?php echo $parcelaID; ?>">
        <input type="text" name="nazivParcele" value="<?php echo htmlspecialchars($parcela['nazivParcele']); ?>" required>
        <input type="text" name="karastarskaOpstina" value="<?php echo htmlspecialchars($parcela['karastarskaOpstina']); ?>" required>
        <input type="text" name="brojKatastarskeParcele" value="<?php echo htmlspecialchars($parcela['brojKatastarskeParcele']); ?>" required>
        <input type="text" name="povrsinaParceleHa" value="<?php echo htmlspecialchars($parcela['povrsinaParceleHa']); ?>" required>

        <!-- Izbor proizvođača -->
        <label for="proizvodjacID">Izaberi proizvođača:</label>
        <select name="proizvodjacID" id="proizvodjacID" required>
            <?php foreach ($proizvodjaci as $proizvodjac): ?>
                <option value="<?= $proizvodjac['proizvodjacID'] ?>" 
                    <?= ($proizvodjac['proizvodjacID'] == $parcela['proizvodjacID']) ? 'selected' : '' ?>>
                    <?= $proizvodjac['nazivProizvodjaca'] ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Sačuvaj</button>
    </form>
</div>
</body>
</html>
