<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Povlačenje svih prinosa zajedno sa proizvođačima
$query = "SELECT P.prinosID, P.godina, P.iznos, PS.parcelaSortaID, parcele.nazivParcele, sorte.nazivSorte, proizvodjaci.nazivProizvodjaca
          FROM prinosi P
          JOIN parcelesorte PS ON P.parcelaSortaID = PS.parcelaSortaID
          JOIN parcele ON PS.parcelaID = parcele.parcelaID
          JOIN sorte ON PS.sortaID = sorte.sortaID
          JOIN proizvodjaci ON parcele.proizvodjacID = proizvodjaci.proizvodjacID";
$stmt = $conn->prepare($query);
$stmt->execute();
$prinosi = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Brojanje prinosa (Za grafikon)
$queryCount = "SELECT COUNT(*) as brojPrinosa FROM prinosi";
$stmtCount = $conn->prepare($queryCount);
$stmtCount->execute();
$brojPrinosa = $stmtCount->fetch(PDO::FETCH_ASSOC);

// Povlačenje svih proizvođača
$queryProizvodjaci = "SELECT proizvodjacID, nazivProizvodjaca FROM proizvodjaci";
$stmtProizvodjaci = $conn->prepare($queryProizvodjaci);
$stmtProizvodjaci->execute();
$proizvodjaci = $stmtProizvodjaci->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prinosi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 1000px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #143a51;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        button {
            padding: 10px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
        .search-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            align-items: center;
        }
        .search-container input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 80%;
        }
        .chart-container {
            width: 80%;
            margin: 0 auto 20px auto;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        .form-container button {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .form-container button:hover {
            background-color: #556b35;
        }
        #poruka {
            margin-top: 10px;
            text-align: center;
            font-size: 16px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Prinosi</h1>
    
    <!-- Grafikon koji prikazuje ukupan broj prinosa -->
    <div class="chart-container">
        <canvas id="prinosiChart"></canvas>
    </div>

    <!-- Polje za pretragu i dugme za prikaz i sakrivanje prinosa -->
    <div class="search-container">
        <input type="text" id="search" placeholder="Pretraži po nazivu parcele, sorte ili proizvođaču">
        <button id="toggleBtn">Prikaži sve prinose</button>
    </div>

    <table id="prinosiTable">
    <thead>
        <tr>
            <th>Godina</th>
            <th>Naziv Parcele</th>
            <th>Naziv Sorte</th>
            <th>Proizvođač</th>
            <th>Iznos (kg)</th>
            <th>Akcije</th>
        </tr>
    </thead>
    <tbody>
    <?php if (count($prinosi) > 0): ?>
        <?php foreach ($prinosi as $prinos): ?>
            <tr>
                <td><?php echo htmlspecialchars($prinos['godina']); ?></td>
                <td><?php echo htmlspecialchars($prinos['nazivParcele']); ?></td>
                <td><?php echo htmlspecialchars($prinos['nazivSorte']); ?></td>
                <td><?php echo htmlspecialchars($prinos['nazivProizvodjaca']); ?></td>
                <td><?php echo htmlspecialchars($prinos['iznos']); ?></td>
                <td class="action-buttons">
                    <a href="urediPr.php?id=<?php echo $prinos['prinosID']; ?>">Uredi</a> |
                    <a href="#" onclick="deletePrinos(<?php echo $prinos['prinosID']; ?>)">Obriši</a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="6" style="text-align: center;">Nema podataka za prikaz</td>
        </tr>
    <?php endif; ?>
    </tbody>
    </table>

    <div class="form-container">
        <h2>Dodaj novi prinos</h2>
        <form id="dodajPrinosForm">
            <div class="form-group">
                <label for="godina">Godina:</label>
                <input type="number" name="godina" id="godina" placeholder="Godina" required>
            </div>
            <div class="form-group">
                <label for="proizvodjacID">Proizvođač:</label>
                <select name="proizvodjacID" id="proizvodjacID" required>
                    <option value="">Izaberite proizvođača</option>
                    <?php foreach ($proizvodjaci as $proizvodjac): ?>
                        <option value="<?= htmlspecialchars($proizvodjac['proizvodjacID']); ?>">
                            <?= htmlspecialchars($proizvodjac['nazivProizvodjaca']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="parcelaSortaID">Parcela i sorta:</label>
                <select name="parcelaSortaID" id="parcelaSortaID" required>
                    <option value="">Izaberite parcelu i sortu</option>
                </select>
            </div>
            <div class="form-group">
                <label for="iznos">Iznos (kg):</label>
                <input type="number" name="iznos" id="iznos" placeholder="Iznos u kg" required>
            </div>
            <button type="submit">Dodaj</button>
        </form>
        <div id="poruka"></div>
    </div>

    <script>
        // Dinamičko ažuriranje opcija za parcele i sorte na osnovu izabranog proizvođača
        document.getElementById('proizvodjacID').addEventListener('change', function() {
            var proizvodjacID = this.value;

            if (proizvodjacID) {
                fetch('getParceleSorte.php?proizvodjacID=' + proizvodjacID)
                .then(response => response.json())
                .then(data => {
                    var parcelaSortaSelect = document.getElementById('parcelaSortaID');
                    parcelaSortaSelect.innerHTML = '<option value="">Izaberite parcelu i sortu</option>';

                    data.forEach(function(parcelaSorta) {
                        var option = document.createElement('option');
                        option.value = parcelaSorta.parcelaSortaID;
                        option.textContent = parcelaSorta.nazivParcele + ' - ' + parcelaSorta.nazivSorte;
                        parcelaSortaSelect.appendChild(option);
                    });
                });
            }
        });

        // Slanje formulara za dodavanje prinosa
        document.getElementById('dodajPrinosForm').addEventListener('submit', function(e) {
            e.preventDefault();

            let formData = new FormData(this);

            fetch('dodajPrinos.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    document.getElementById('poruka').textContent = data.message;
                    document.getElementById('poruka').style.color = 'green';
                    document.getElementById('dodajPrinosForm').reset();
                    location.reload();
                } else {
                    document.getElementById('poruka').textContent = data.message;
                    document.getElementById('poruka').style.color = 'red';
                }
            })
            .catch(error => {
                console.error('Došlo je do greške:', error);
                document.getElementById('poruka').textContent = 'Došlo je do greške pri dodavanju prinosa.';
                document.getElementById('poruka').style.color = 'red';
            });
        });

        // Funkcija za brisanje prinosa
        function deletePrinos(id) {
            if (confirm('Da li ste sigurni da želite obrisati ovaj prinos?')) {
                fetch('obrisiPr.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ prinosID: id })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Došlo je do greške:', error));
            }
        }

        // Prikazivanje grafikona
        const ctx = document.getElementById('prinosiChart').getContext('2d');
        const prinosiChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Prinosi'],
                datasets: [{
                    label: 'Ukupno Prinosi',
                    data: [<?php echo $brojPrinosa['brojPrinosa']; ?>],
                    backgroundColor: '#668846',
                    borderColor: '#556b35',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Pretraga po nazivu
        $('#search').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $('#prinosiTable tbody tr').filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
            });
        });

        // Prikazivanje/sakrivanje tabele
        $('#toggleBtn').on('click', function() {
            var table = $('#prinosiTable');
            if (table.is(':visible')) {
                table.hide();
                $(this).text('Prikaži sve prinose');
            } else {
                table.show();
                $(this).text('Sakrij sve prinose');
            }
        });
    </script>
</div>
</body>
</html>
