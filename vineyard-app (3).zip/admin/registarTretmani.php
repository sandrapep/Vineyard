<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';
$db = new Database();
$conn = $db->getConnection();

// Fetch distinct treatment types that exist in "tretmani" table and are in "mne" language
$queryTipoviTretmana = "
    SELECT DISTINCT TT.tipTretmanaID, TT.nazivTretmana
    FROM tiptretmana TT
    JOIN tretmani T ON TT.tipTretmanaID = T.tipTretmanaID
    WHERE TT.jezik = 'mne'";
$stmtTipoviTretmana = $conn->prepare($queryTipoviTretmana);
$stmtTipoviTretmana->execute();
$tipoviTretmana = $stmtTipoviTretmana->fetchAll(PDO::FETCH_ASSOC);

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $tipTretmanaID = $_POST['tipTretmanaID'] ?? '';
    $parcelaID = $_POST['parcelaID'] ?? '';
    $sortaID = $_POST['sortaID'] ?? '';

    // Fetch parcels for the selected treatment type
    if ($_POST['action'] === 'getParcele') {
        $sql = "SELECT DISTINCT P.parcelaID, P.nazivParcele 
                FROM tretmani T
                JOIN parcelesorte PS ON T.parcelaSortaID = PS.parcelaSortaID
                JOIN parcele P ON PS.parcelaID = P.parcelaID
                WHERE T.tipTretmanaID = :tipTretmanaID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':tipTretmanaID', $tipTretmanaID);
        $stmt->execute();
        $parcele = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($parcele);
        exit();
    }

    // Fetch varieties for the selected treatment type and parcel
    if ($_POST['action'] === 'getSorte') {
        $sql = "SELECT DISTINCT S.sortaID, S.nazivSorte 
                FROM tretmani T
                JOIN parcelesorte PS ON T.parcelaSortaID = PS.parcelaSortaID
                JOIN sorte S ON PS.sortaID = S.sortaID
                WHERE T.tipTretmanaID = :tipTretmanaID AND PS.parcelaID = :parcelaID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':tipTretmanaID', $tipTretmanaID);
        $stmt->bindParam(':parcelaID', $parcelaID);
        $stmt->execute();
        $sorte = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($sorte);
        exit();
    }

    // Fetch treatments based on the selected filters
    if ($_POST['action'] === 'getTretmani') {
        $sql = "SELECT T.tretmanID, TT.nazivTretmana, T.opis, T.datumVrijeme, P.nazivParcele, S.nazivSorte
                FROM tretmani T
                JOIN tiptretmana TT ON T.tipTretmanaID = TT.tipTretmanaID
                JOIN parcelesorte PS ON T.parcelaSortaID = PS.parcelaSortaID
                JOIN parcele P ON PS.parcelaID = P.parcelaID
                JOIN sorte S ON PS.sortaID = S.sortaID
                WHERE TT.jezik = 'mne'";
        
        if (!empty($tipTretmanaID)) {
            $sql .= " AND T.tipTretmanaID = :tipTretmanaID";
        }
        if (!empty($parcelaID)) {
            $sql .= " AND P.parcelaID = :parcelaID";
        }
        if (!empty($sortaID)) {
            $sql .= " AND S.sortaID = :sortaID";
        }

        $stmt = $conn->prepare($sql);

        if (!empty($tipTretmanaID)) {
            $stmt->bindParam(':tipTretmanaID', $tipTretmanaID);
        }
        if (!empty($parcelaID)) {
            $stmt->bindParam(':parcelaID', $parcelaID);
        }
        if (!empty($sortaID)) {
            $stmt->bindParam(':sortaID', $sortaID);
        }

        $stmt->execute();
        $tretmani = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($tretmani);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registar tretmana</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 1000px;
            margin: 0 auto;
        }
        h1 {
            color: #143a51;
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #143a51;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #333;
        }
        select, input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            font-family: Arial, sans-serif;
            margin-bottom: 10px;
        }
        #poruka {
            margin-top: 10px;
            text-align: center;
            font-size: 18px;
            color: #668846;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px; /* Veća strelica */
            font-weight: bold; /* Deblja strelica */
            background-color: #143a51; /* Dodata boja pozadine */
            border: 2px solid #0f2e41; /* Dodan okvir */
            border-radius: 8px; /* Zaobljeni uglovi */
            color: #ffffff; /* Boja strelice */
            padding: 10px 15px; /* Razmak unutar dugmeta */
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease; /* Efekat prelaza */
            }
        
        .back-button:hover {
            background-color: #668846; /* Tamnija pozadina pri hover-u */
            border-color: #143a51; /* Promena boje okvira pri hover-u */
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="container">
    <h1>Registar tretmana</h1>
<!-- Dugme za povratak na index.php sa strelicom -->
    <button class="back-button" onclick="window.location.href='aindex.php'">&#8592;</button>
    <label for="tretman">Izaberite tip tretmana:</label>
    <select id="tretman">
        <option value="">Izaberite tip tretmana</option>
        <?php foreach ($tipoviTretmana as $tip): ?>
            <option value="<?= htmlspecialchars($tip['tipTretmanaID']); ?>"><?= htmlspecialchars($tip['nazivTretmana']); ?></option>
        <?php endforeach; ?>
    </select>

    <label for="parcela">Izaberite parcelu:</label>
    <select id="parcela" disabled>
        <option value="">Izaberite parcelu</option>
    </select>

    <label for="sorta">Izaberite sortu:</label>
    <select id="sorta" disabled>
        <option value="">Izaberite sortu</option>
    </select>

    <table id="tretmaniTable">
        <thead>
            <tr>
                <th>Tip tretmana</th>
                <th>Opis</th>
                <th>Datum i vrijeme</th>
                <th>Parcela</th>
                <th>Sorta</th>
            </tr>
        </thead>
        <tbody id="tabela-body"></tbody>
    </table>

    <div id="poruka"></div>
</div>

<script>
$(document).ready(function() {
    // Fetch parcels when a treatment type is selected
    $('#tretman').on('change', function() {
        const tipTretmanaID = $(this).val();
        $('#parcela').prop('disabled', tipTretmanaID === '');
        $('#sorta').prop('disabled', true).html('<option value="">Izaberite sortu</option>');
        
        if (tipTretmanaID) {
            $.post('', { action: 'getParcele', tipTretmanaID: tipTretmanaID }, function(data) {
                const parsedData = JSON.parse(data);
                const options = parsedData.map(p => `<option value="${p.parcelaID}">${p.nazivParcele}</option>`).join('');
                $('#parcela').html('<option value="">Izaberite parcelu</option>' + options);
            });
        }
    });

    // Fetch varieties when a parcel is selected
    $('#parcela').on('change', function() {
        const parcelaID = $(this).val();
        const tipTretmanaID = $('#tretman').val();
        $('#sorta').prop('disabled', parcelaID === '');
        
        if (parcelaID) {
            $.post('', { action: 'getSorte', parcelaID: parcelaID, tipTretmanaID: tipTretmanaID }, function(data) {
                const parsedData = JSON.parse(data);
                const options = parsedData.map(s => `<option value="${s.sortaID}">${s.nazivSorte}</option>`).join('');
                $('#sorta').html('<option value="">Izaberite sortu</option>' + options);
            });
        }
    });

    // Fetch data when any filter is selected
    $('#tretman, #parcela, #sorta').on('change', function() {
        const tipTretmanaID = $('#tretman').val();
        const parcelaID = $('#parcela').val();
        const sortaID = $('#sorta').val();

        $.post('', { action: 'getTretmani', tipTretmanaID: tipTretmanaID, parcelaID: parcelaID, sortaID: sortaID }, function(data) {
            const tretmani = JSON.parse(data);
            let rows = '';

            tretmani.forEach(function(tretman) {
                rows += `
                    <tr>
                        <td>${tretman.nazivTretmana}</td>
                        <td>${tretman.opis}</td>
                        <td>${tretman.datumVrijeme}</td>
                        <td>${tretman.nazivParcele}</td>
                        <td>${tretman.nazivSorte}</td>
                    </tr>
                `;
            });

            $('#tabela-body').html(rows);
        });
    });
});
</script>

</body>
</html>
