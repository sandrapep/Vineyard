<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nazivParcele = $_POST['nazivParcele'];
    $karastarskaOpstina = $_POST['karastarskaOpstina'];
    $brojKatastarskeParcele = $_POST['brojKatastarskeParcele'];
    $povrsinaParceleHa = $_POST['povrsinaParceleHa'];
    $proizvodjacID = $_POST['proizvodjacID'];

    // Upit za unos nove parcele
    $query = "INSERT INTO parcele (nazivParcele, karastarskaOpstina, brojKatastarskeParcele, povrsinaParceleHa, proizvodjacID) 
              VALUES (:nazivParcele, :karastarskaOpstina, :brojKatastarskeParcele, :povrsinaParceleHa, :proizvodjacID)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivParcele', $nazivParcele);
    $stmt->bindParam(':karastarskaOpstina', $karastarskaOpstina);
    $stmt->bindParam(':brojKatastarskeParcele', $brojKatastarskeParcele);
    $stmt->bindParam(':povrsinaParceleHa', $povrsinaParceleHa);
    $stmt->bindParam(':proizvodjacID', $proizvodjacID);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Parcela uspješno dodata!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške pri dodavanju parcele.']);
    }
}
?>
