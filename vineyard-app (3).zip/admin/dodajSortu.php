<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Proveri da li je poslat naziv sorte
        if (isset($_POST['nazivSorte']) && !empty($_POST['nazivSorte'])) {
            $nazivSorte = trim($_POST['nazivSorte']);

            // Provera da li sorta već postoji
            $checkQuery = "SELECT COUNT(*) as count FROM sorte WHERE nazivSorte = :nazivSorte";
            $checkStmt = $conn->prepare($checkQuery);
            $checkStmt->bindParam(':nazivSorte', $nazivSorte, PDO::PARAM_STR);
            $checkStmt->execute();
            $row = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if ($row['count'] == 0) {
                // Pripremi SQL upit za unos sorte u bazu
                $query = "INSERT INTO sorte (nazivSorte) VALUES (:nazivSorte)";
                $stmt = $conn->prepare($query);
                $stmt->bindParam(':nazivSorte', $nazivSorte, PDO::PARAM_STR);

                // Provera da li je upit uspešno izvršen
                if ($stmt->execute()) {
                    // Uspeh - vrati JSON sa porukom o uspešnom dodavanju
                    echo json_encode(['status' => 'success', 'message' => 'Sorta uspešno dodata!']);
                } else {
                    // Greška prilikom dodavanja sorte
                    echo json_encode(['status' => 'error', 'message' => 'Greška pri dodavanju sorte.']);
                }
            } else {
                // Sorta sa ovim nazivom već postoji
                echo json_encode(['status' => 'error', 'message' => 'Sorta sa ovim nazivom već postoji.']);
            }
        } else {
            // Ako nije poslat naziv sorte
            echo json_encode(['status' => 'error', 'message' => 'Naziv sorte je obavezan.']);
        }
    }
} catch (Exception $e) {
    // Hvatanje izuzetaka i slanje poruke kao JSON
    echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške: ' . $e->getMessage()]);
    exit();
}
?>
