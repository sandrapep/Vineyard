<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

$parcelasortaID = $_GET['parcelasortaID'];

// Fetch the data for the selected `parcelasortaID`
$query = "SELECT PS.*, S.nazivSorte, P.nazivParcele 
          FROM parcelesorte PS
          JOIN sorte S ON PS.sortaID = S.sortaID
          JOIN parcele P ON PS.parcelaID = P.parcelaID
          WHERE PS.parcelasortaID = :parcelasortaID";

$stmt = $conn->prepare($query);
$stmt->bindParam(':parcelasortaID', $parcelasortaID);
$stmt->execute();
$sorta = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sortaID = $_POST['sortaID'];
    $parcelaID = $_POST['parcelaID'];
    $razmakSadnje = $_POST['razmakSadnje'];
    $razmakRedovi = $_POST['razmakRedovi'];
    $godinaSadnje = $_POST['godinaSadnje'];

    // Update the selected record
    $query = "UPDATE parcelesorte SET sortaID = :sortaID, parcelaID = :parcelaID, razmakSadnje = :razmakSadnje, razmakRedovi = :razmakRedovi, godinaSadnje = :godinaSadnje
              WHERE parcelasortaID = :parcelasortaID";
    
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':sortaID', $sortaID);
    $stmt->bindParam(':parcelaID', $parcelaID);
    $stmt->bindParam(':razmakSadnje', $razmakSadnje);
    $stmt->bindParam(':razmakRedovi', $razmakRedovi);
    $stmt->bindParam(':godinaSadnje', $godinaSadnje);
    $stmt->bindParam(':parcelasortaID', $parcelasortaID);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Sorta uspješno ažurirana."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Došlo je do greške pri ažuriranju sorte."]);
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi parcelu i sortu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 100%;
        }
        h1 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            width: 100%;
            max-width: 400px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: Arial, sans-serif;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
        #poruka {
            margin-top: 10px;
            text-align: center;
            font-size: 16px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Uredi parcelu i sortu</h1>
    <form id="urediParceluSortuForm">
        <label for="sortaID">Naziv sorte:</label>
        <select name="sortaID" id="sortaID" required>
            <?php
            $querySorte = "SELECT sortaID, nazivSorte FROM sorte";
            $stmtSorte = $conn->prepare($querySorte);
            $stmtSorte->execute();
            $sorte = $stmtSorte->fetchAll(PDO::FETCH_ASSOC);
            foreach ($sorte as $sortaOption) {
                $selected = $sortaOption['sortaID'] == $sorta['sortaID'] ? 'selected' : '';
                echo "<option value='{$sortaOption['sortaID']}' $selected>{$sortaOption['nazivSorte']}</option>";
            }
            ?>
        </select>

        <label for="parcelaID">Parcela:</label>
        <select name="parcelaID" id="parcelaID" required>
            <?php
            $queryParcele = "SELECT parcelaID, nazivParcele FROM parcele";
            $stmtParcele = $conn->prepare($queryParcele);
            $stmtParcele->execute();
            $parcele = $stmtParcele->fetchAll(PDO::FETCH_ASSOC);
            foreach ($parcele as $parcela) {
                $selected = $parcela['parcelaID'] == $sorta['parcelaID'] ? 'selected' : '';
                echo "<option value='{$parcela['parcelaID']}' $selected>{$parcela['nazivParcele']}</option>";
            }
            ?>
        </select>

        <label for="razmakSadnje">Razmak sadnje (cm):</label>
        <input type="text" name="razmakSadnje" id="razmakSadnje" value="<?php echo htmlspecialchars($sorta['razmakSadnje']); ?>" required>

        <label for="razmakRedovi">Razmak redova (cm):</label>
        <input type="text" name="razmakRedovi" id="razmakRedovi" value="<?php echo htmlspecialchars($sorta['razmakRedovi']); ?>" required>

        <label for="godinaSadnje">Godina sadnje:</label>
        <input type="text" name="godinaSadnje" id="godinaSadnje" value="<?php echo htmlspecialchars($sorta['godinaSadnje']); ?>" required>

        <button type="submit">Ažuriraj</button>
    </form>
    <div id="poruka"></div>
</div>

<script>
    document.getElementById('urediParceluSortuForm').addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent page refresh

        let formData = new FormData(this);

        fetch('urediPS.php?parcelasortaID=<?php echo $parcelasortaID; ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            document.getElementById('poruka').textContent = data.message;
            document.getElementById('poruka').style.color = data.status === 'success' ? 'green' : 'red';
        })
        .catch(error => {
            console.error('Došlo je do greške:', error);
            document.getElementById('poruka').textContent = 'Došlo je do greške pri ažuriranju sorte.';
            document.getElementById('poruka').style.color = 'red';
        });
    });
</script>

</body>
</html>