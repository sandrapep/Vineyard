<form method="POST" action="">
    <label for="proizvodjacID">Proizvođač:</label>
    <select name="proizvodjacID" id="proizvodjacID">
        <option value="">Svi proizvođači</option>
        <?php
        $proizvodjaci = $conn->query("SELECT proizvodjacID, nazivProizvodjaca FROM proizvodjaci");
        foreach ($proizvodjaci as $proizvodjac) {
            echo "<option value='{$proizvodjac['proizvodjacID']}'>{$proizvodjac['nazivProizvodjaca']}</option>";
        }
        ?>
    </select>

    <label for="godina">Godina:</label>
    <select name="godina" id="godina">
        <option value="">Sve godine</option>
        <?php
        $godine = $conn->query("SELECT DISTINCT YEAR(datumVrijeme) as godina FROM registarfenofaza ORDER BY godina DESC");
        foreach ($godine as $godina) {
            echo "<option value='{$godina['godina']}'>{$godina['godina']}</option>";
        }
        ?>
    </select>

    <label for="fenoloskaFazaID">Fenološka faza:</label>
    <select name="fenoloskaFazaID" id="fenoloskaFazaID">
        <option value="">Sve fenološke faze</option>
        <?php
        $faze = $conn->query("SELECT fenoloskaFazaID, nazivFaze FROM fenoloskefaze");
        foreach ($faze as $faza) {
            echo "<option value='{$faza['fenoloskaFazaID']}'>{$faza['nazivFaze']}</option>";
        }
        ?>
    </select>

    <label for="parcelaID">Parcela:</label>
    <select name="parcelaID" id="parcelaID">
        <option value="">Sve parcele</option>
        <?php
        $parcele = $conn->query("SELECT parcelaID, nazivParcele FROM parcele");
        foreach ($parcele as $parcela) {
            echo "<option value='{$parcela['parcelaID']}'>{$parcela['nazivParcele']}</option>";
        }
        ?>
    </select>

    <label for="sortaID">Sorta:</label>
    <select name="sortaID" id="sortaID">
        <option value="">Sve sorte</option>
        <?php
        $sorte = $conn->query("SELECT sortaID, nazivSorte FROM sorte");
        foreach ($sorte as $sorta) {
            echo "<option value='{$sorta['sortaID']}'>{$sorta['nazivSorte']}</option>";
        }
        ?>
    </select>

    <button type="submit">Filtriraj</button>
</form>
