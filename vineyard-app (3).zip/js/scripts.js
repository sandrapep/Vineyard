document.addEventListener('DOMContentLoaded', () => {
    // Add JavaScript functionality if needed
});
