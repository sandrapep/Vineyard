<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Fetch initial data for dropdowns - selektuj proizvodjače koji imaju podatke u parcelesorte
function getDropdownData($conn, $sql) {
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Selektovanje proizvodjača koji imaju podatke u parcelesorte
$proizvodjaci = getDropdownData($conn, "
    SELECT DISTINCT p.proizvodjacID, p.nazivProizvodjaca 
    FROM proizvodjaci p 
    JOIN parcele pa ON p.proizvodjacID = pa.proizvodjacID 
    JOIN parcelesorte ps ON pa.parcelaID = ps.parcelaID
");

// Handle AJAX request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $response = [];

    if ($action == 'getFaze') {
        $conditions = [];
        $params = [];

        if (!empty($_POST['proizvodjacID'])) {
            $conditions[] = 'pr.proizvodjacID = :proizvodjacID';
            $params[':proizvodjacID'] = $_POST['proizvodjacID'];
        }
        if (!empty($_POST['parcelaID'])) {
            $conditions[] = 'ps.parcelaID = :parcelaID';
            $params[':parcelaID'] = $_POST['parcelaID'];
        }
        if (!empty($_POST['sortaID'])) {
            $conditions[] = 'ps.sortaID = :sortaID';
            $params[':sortaID'] = $_POST['sortaID'];
        }

        $sql = "SELECT pr.nazivProizvodjaca, p.nazivParcele, s.nazivSorte, f.nazivFaze, f.fenoKod, rf.datumVrijeme
                FROM registarfenofaza rf
                JOIN parcelesorte ps ON rf.parcelaSortaID = ps.parcelaSortaID
                JOIN parcele p ON ps.parcelaID = p.parcelaID
                JOIN sorte s ON ps.sortaID = s.sortaID
                JOIN fenoloskefaze f ON rf.fenoloskaFazaID = f.fenoloskaFazaID
                JOIN proizvodjaci pr ON p.proizvodjacID = pr.proizvodjacID";

        if (!empty($conditions)) {
            $sql .= ' WHERE ' . implode(' AND ', $conditions);
        }

        $stmt = $conn->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }

        $stmt->execute();
        $response = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($action == 'getParcele') {
        // Fetch parcels based on the selected producer
        $sql = "SELECT DISTINCT ps.parcelaID, p.nazivParcele 
                FROM parcele p 
                JOIN parcelesorte ps ON p.parcelaID = ps.parcelaID 
                WHERE p.proizvodjacID = :proizvodjacID";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':proizvodjacID', $_POST['proizvodjacID']);
        $stmt->execute();
        $response = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($action == 'getSorte') {
        // Fetch varieties based on the selected parcel
        // SQL za dobijanje sorti koje imaju podatke u registarfenofaza
        $sql = "SELECT DISTINCT ps.sortaID, s.nazivSorte 
                FROM sorte s 
                JOIN parcelesorte ps ON s.sortaID = ps.sortaID 
                JOIN registarfenofaza rf ON ps.parcelaSortaID = rf.parcelaSortaID
                WHERE ps.parcelaID = :parcelaID";

        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':parcelaID', $_POST['parcelaID']);
        $stmt->execute();
        $response = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    echo json_encode($response);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registar feno faza</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ebe3dd;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://static.independent.co.uk/2023/09/15/15/iStock-160179300.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 1000px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #bdccaf;
            color: #333;
        }

        th, td {
            border: 1px solid #fff;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }

        th {
            background-color: #668846;
            color: #fff;
        }

        td {
            background-color: #bdccaf;
        }

        tbody {
            display: block;
            max-height: 400px;
            overflow-y: auto;
        }

        thead, tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }

        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #668846;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #0f2e41;
            border-color: #143a51;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        select {
            padding: 10px;
            width: 100%;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        #poruka {
            color: #668846;
            margin-top: 10px;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="container">
    <h1>Registar feno faza</h1>
    <button class="back-button" onclick="window.location.href='../index.php'">&#8592;</button>

    <label for="proizvodjac">Izaberite proizvođača:</label>
    <select id="proizvodjac">
        <option value="">Izaberite proizvođača</option>
        <?php foreach ($proizvodjaci as $item): ?>
            <option value="<?= $item['proizvodjacID'] ?>"><?= htmlspecialchars($item['nazivProizvodjaca']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="parcela">Izaberite parcelu:</label>
    <select id="parcela" disabled>
        <option value="">Izaberite parcelu</option>
    </select>

    <label for="sorta">Izaberite sortu:</label>
    <select id="sorta" disabled>
        <option value="">Izaberite sortu</option>
    </select>

    <table>
        <thead>
            <tr>
                <th>Proizvođač</th>
                <th>Parcela</th>
                <th>Sorta</th>
                <th>Faza</th>
                <th>Feno kod</th>
                <th>Datum i vrijeme</th>
            </tr>
        </thead>
        <tbody id="fenoData">
            <!-- Dinamički podaci će biti umetnuti ovde -->
        </tbody>
    </table>

    <div id="poruka"></div>
</div>

<script>
$(document).ready(function() {
    function azurirajPoruku(imaPodataka) {
        if (!imaPodataka) {
            $('#poruka').text('Nema podataka za odabrane stavke.');
        } else {
            $('#poruka').text('');
        }
    }

    // Kada se promijeni proizvodjač, povuci parcele
    $('#proizvodjac').on('change', function() {
        const proizvodjacID = $(this).val();
        $('#parcela').prop('disabled', proizvodjacID === '');
        $('#sorta').prop('disabled', true).html('<option value="">Izaberite sortu</option>');
        
        if (proizvodjacID) {
            $.post('', { action: 'getParcele', proizvodjacID: proizvodjacID }, function(data) {
                const parsedData = JSON.parse(data);
                const options = parsedData.map(p => `<option value="${p.parcelaID}">${p.nazivParcele}</option>`).join('');
                $('#parcela').html('<option value="">Izaberite parcelu</option>' + options);
            });
        }
    });

    // Kada se promijeni parcela, povuci sorte
    $('#parcela').on('change', function() {
        const parcelaID = $(this).val();
        $('#sorta').prop('disabled', parcelaID === '');
        
        if (parcelaID) {
            $.post('', { action: 'getSorte', parcelaID: parcelaID }, function(data) {
                const parsedData = JSON.parse(data);
                const options = parsedData.map(s => `<option value="${s.sortaID}">${s.nazivSorte}</option>`).join('');
                $('#sorta').html('<option value="">Izaberite sortu</option>' + options);
            });
        }
    });

    // Kada se promijeni bilo koji filter, povuci podatke
    $('#proizvodjac, #parcela, #sorta').on('change', function() {
        const proizvodjacID = $('#proizvodjac').val();
        const parcelaID = $('#parcela').val();
        const sortaID = $('#sorta').val();

        $.post('', { action: 'getFaze', proizvodjacID: proizvodjacID, parcelaID: parcelaID, sortaID: sortaID }, function(data) {
            const parsedData = JSON.parse(data);
            if (parsedData.length === 0) {
                azurirajPoruku(false);
                $('#fenoData').html('');
            } else {
                azurirajPoruku(true);
                const rows = parsedData.map(f => `
                    <tr>
                        <td>${f.nazivProizvodjaca}</td>
                        <td>${f.nazivParcele}</td>
                        <td>${f.nazivSorte}</td>
                        <td>${f.nazivFaze}</td>
                        <td>${f.fenoKod}</td>
                        <td>${f.datumVrijeme}</td>
                    </tr>
                `).join('');
                $('#fenoData').html(rows);
            }
        });
    });
});
</script>

</body>
</html>
