<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

$tretmanID = $_GET['id'];

// Preuzimanje podataka o tretmanu, uključujući naziv parcele, sorte i tip tretmana
$query = "SELECT T.*, TT.nazivTretmana, P.nazivParcele, S.nazivSorte
          FROM tretmani T
          JOIN tiptretmana TT ON T.tipTretmanaID = TT.tipTretmanaID
          JOIN parcelesorte PS ON T.parcelaSortaID = PS.parcelaSortaID
          JOIN parcele P ON PS.parcelaID = P.parcelaID
          JOIN sorte S ON PS.sortaID = S.sortaID
          WHERE T.tretmanID = :tretmanID";
$stmt = $conn->prepare($query);
$stmt->bindParam(':tretmanID', $tretmanID);
$stmt->execute();
$tretman = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $opis = $_POST['opis'];
    $datumVrijeme = $_POST['datumVrijeme'];

    // Ažuriranje samo opisa i datuma tretmana
    $query = "UPDATE tretmani SET opis = :opis, datumVrijeme = :datumVrijeme WHERE tretmanID = :tretmanID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':opis', $opis);
    $stmt->bindParam(':datumVrijeme', $datumVrijeme);
    $stmt->bindParam(':tretmanID', $tretmanID);
    $stmt->execute();

    header("Location: index_tretmani.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi tretman</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url('https://traynorvineyard.com/cdn/shop/articles/htb_traynor_w-2.jpg?v=1611006329');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85); /* Providna pozadina */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 100%;
        }
        h1 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input, textarea {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            font-family: Arial, sans-serif;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            max-width: 400px;
        }
        .static-info {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            color: #333;
            background-color: #f4f4f4;
            border-radius: 4px;
            width: 100%;
            max-width: 400px;
        }
        button {
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi tretman</h1>
    <form method="post" action="edit_tretman.php?id=<?php echo $tretmanID; ?>">
        <!-- Prikaz statičnih informacija o parceli, sorti i tipu tretmana -->
        <div class="static-info">
            Parcela: <?php echo htmlspecialchars($tretman['nazivParcele']); ?>
        </div>
        <div class="static-info">
            Sorta: <?php echo htmlspecialchars($tretman['nazivSorte']); ?>
        </div>
        <div class="static-info">
            Tip tretmana: <?php echo htmlspecialchars($tretman['nazivTretmana']); ?>
        </div>

        <!-- Polja za uređivanje opisa i datuma -->
        <textarea name="opis" placeholder="Opis tretmana" required><?php echo htmlspecialchars($tretman['opis']); ?></textarea>
        <input type="datetime-local" name="datumVrijeme" value="<?php echo htmlspecialchars($tretman['datumVrijeme']); ?>" required>

        <!-- Dugme za čuvanje -->
        <button type="submit">Sačuvaj</button>
    </form>
</div>
</body>
</html>
