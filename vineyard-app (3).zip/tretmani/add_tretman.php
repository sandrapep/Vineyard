<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivTretmana = $_POST['nazivTretmana'];
    $opisTretmana = $_POST['opisTretmana'];
    $jezik = $_POST['jezik']; // Dodavanje jezika

    $query = "INSERT INTO tiptretmana (nazivTretmana, opisTretmana, jezik) 
              VALUES (:nazivTretmana, :opisTretmana, :jezik)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivTretmana', $nazivTretmana);
    $stmt->bindParam(':opisTretmana', $opisTretmana);
    $stmt->bindParam(':jezik', $jezik); // Povezivanje jezika sa query-jem
    $stmt->execute();

    header("Location: tindex.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj novi tretman</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url('https://traynorvineyard.com/cdn/shop/articles/htb_traynor_w-2.jpg?v=1611006329');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 100%;
        }
        h1 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input, textarea, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            max-width: 400px;
            font-family: Arial, sans-serif;
        }
        button {
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #556b35;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Dodaj novi tretman</h1>
    <!-- Dugme za povratak na prethodnu stranicu sa strelicom -->
    <button class="back-button" onclick="window.location.href='tindex.php'">&#8592;</button>
    <form method="post" action="add_tretman.php">
        <input type="text" name="nazivTretmana" placeholder="Naziv tretmana" required>
        <textarea name="opisTretmana" placeholder="Opis tretmana" required></textarea>
        
        <!-- Dodavanje izbora jezika -->
        <select name="jezik" required>
            <option value="">Izaberi jezik</option>
            <option value="mne">MNE</option>
            <option value="eng">ENG</option>
        </select>
        
        <button type="submit">Dodaj</button>
    </form>
</div>
</body>
</html>
