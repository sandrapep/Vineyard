<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Postavljanje podrazumevanog jezika na 'mne' ako nije izabran
$selectedLanguage = isset($_POST['jezik']) ? $_POST['jezik'] : 'mne';

// Selektovanje tretmana prema izabranom jeziku
$query = "SELECT TT.nazivTretmana, TT.opisTretmana, TT.jezik 
          FROM tiptretmana TT
          WHERE TT.jezik = :jezik";
$stmt = $conn->prepare($query);
$stmt->bindParam(':jezik', $selectedLanguage);
$stmt->execute();
$tretmani = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tretmani</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ebe3dd;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://www.sheridanvineyard.com/wp-content/uploads/2023/09/Slide-hill-with-grapes.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 1000px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background-color: #556b35;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #bdccaf;
            color: #fff;
        }

        th, td {
            border: 1px solid #fff;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }

        th {
            background-color: #668846;
        }

        td {
            background-color: #bdccaf;
            color: #000;
        }

        tbody {
            display: block;
            max-height: 400px;
            overflow-y: auto;
        }

        thead, tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }

        .filter-container {
            margin-bottom: 20px;
        }

        .filter-input {
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: 'Arial', sans-serif;
        }

        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #668846;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #0f2e41;
            border-color: #143a51;
        }

        .language-selection {
            margin: 20px 0;
            display: flex;
            justify-content: center;
            gap: 20px;
            font-family: Arial, sans-serif;
        }

        .language-selection label {
            font-size: 16px;
            cursor: pointer;
            color: #333;
        }

        .language-selection input {
            margin-right: 5px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Tretmani</h1>
    <!-- Dugme za povratak na prethodnu stranicu sa strelicom -->
    <button class="back-button" onclick="window.location.href='../index.php'">&#8592;</button>

    <!-- Filter po nazivu tretmana -->
    <div class="filter-container">
        <input type="text" id="nazivFilter" class="filter-input" placeholder="Pretraži po nazivu tretmana">
        <button id="filterButton">Filtriraj</button>
    </div>

    <button onclick="window.location.href='add_tretman.php'">Dodaj novi tretman</button>

    <!-- Forma za izbor jezika sa radio dugmićima -->
    <form method="POST" class="language-selection">
        <label>
            <input type="radio" name="jezik" value="mne" <?php if ($selectedLanguage == 'mne') echo 'checked'; ?> onchange="this.form.submit();">
            MNE
        </label>
        <label>
            <input type="radio" name="jezik" value="eng" <?php if ($selectedLanguage == 'eng') echo 'checked'; ?> onchange="this.form.submit();">
            ENG
        </label>
    </form>

    <table id="tretmaniTable">
        <thead>
            <tr>
                <th>Naziv tretmana</th>
                <th>Opis tretmana</th>
                <th>Jezik</th> <!-- Kolona za prikaz jezika -->
            </tr>
        </thead>
        <tbody>
        <?php foreach ($tretmani as $tretman): ?>
            <tr>
                <td><?php echo htmlspecialchars($tretman['nazivTretmana']); ?></td>
                <td><?php echo htmlspecialchars($tretman['opisTretmana']); ?></td>
                <td><?php echo htmlspecialchars($tretman['jezik']); ?></td> <!-- Prikaz jezika -->
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
    document.getElementById('filterButton').addEventListener('click', function() {
        filterTable();
    });

    function filterTable() {
        var nazivValue = document.getElementById('nazivFilter').value.toLowerCase();
        var rows = document.querySelectorAll('#tretmaniTable tbody tr');

        rows.forEach(function(row) {
            var naziv = row.cells[0].textContent.toLowerCase();
            var nazivMatch = naziv.includes(nazivValue);

            if (nazivMatch) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
</script>

</body>
</html>
