<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

$query = "SELECT P.nazivParcele, P.karastarskaOpstina, P.brojKatastarskeParcele, P.povrsinaParceleHa, PR.nazivProizvodjaca 
          FROM parcele P
          LEFT JOIN proizvodjaci PR ON P.proizvodjacID = PR.proizvodjacID";
$stmt = $conn->prepare($query);
$stmt->execute();
$parcele = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parcele</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ebe3dd;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://www.sheridanvineyard.com/wp-content/uploads/2023/09/Slide-hill-with-grapes.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 1000px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .filter-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .filter-container input[type="text"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 40%;
        }

        .filter-container button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #668846;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .filter-container button:hover {
            background-color: #556b35;
        }

        button.add-button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        button.add-button:hover {
            background-color: #556b35;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #bdccaf;
            color: #fff;
        }

        th, td {
            border: 1px solid #fff;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }

        th {
            background-color: #668846;
        }

        td {
            background-color: #bdccaf;
            color: #000;
        }

        tbody {
            display: block;
            max-height: 400px;
            overflow-y: auto;
        }

        thead, tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }
        
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px; /* Veća strelica */
            font-weight: bold; /* Deblja strelica */
            background-color: #668846; /* Dodata boja pozadine */
            border: 2px solid #0f2e41; /* Dodan okvir */
            border-radius: 8px; /* Zaobljeni uglovi */
            color: #ffffff; /* Boja strelice */
            padding: 10px 15px; /* Razmak unutar dugmeta */
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease; /* Efekat prelaza */
    }
    
        .back-button:hover {
            background-color: #143a51; /* Tamnija pozadina pri hover-u */
            border-color: #143a51; /* Promena boje okvira pri hover-u */
    }

    </style>
    <script>
        function filterTable() {
            var nazivFilter = document.getElementById("nazivFilter").value.toUpperCase();
            var proizvodjacFilter = document.getElementById("proizvodjacFilter").value.toUpperCase();
            var table = document.getElementById("parceleTable");
            var tr = table.getElementsByTagName("tr");

            for (var i = 1; i < tr.length; i++) {  // Počinje od 1 jer prvi red sadrži zaglavlja
                var nazivTd = tr[i].getElementsByTagName("td")[0];  // Kolona za naziv parcele
                var proizvodjacTd = tr[i].getElementsByTagName("td")[4];  // Kolona za naziv proizvođača
                
                if (nazivTd && proizvodjacTd) {
                    var nazivTxt = nazivTd.textContent || nazivTd.innerText;
                    var proizvodjacTxt = proizvodjacTd.textContent || proizvodjacTd.innerText;

                    if (nazivTxt.toUpperCase().indexOf(nazivFilter) > -1 && 
                        proizvodjacTxt.toUpperCase().indexOf(proizvodjacFilter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</head>
<body>
<div class="container">
    <h1>Parcele</h1>

    <!-- Filter inputs in one row with button -->
    <div class="filter-container">
        <input type="text" id="nazivFilter" placeholder="Pretraži po nazivu parcele">
        <input type="text" id="proizvodjacFilter" placeholder="Pretraži po nazivu proizvođača">
        <button onclick="filterTable()">Filtriraj</button>
    </div>
    <!-- Dugme za povratak na index.php sa strelicom -->
    <button class="back-button" onclick="window.location.href='../index.php'">&#8592;</button>

    <!-- Dugme za dodavanje nove parcele -->
    <button class="add-button" onclick="window.location.href='add_parcele.php'">Dodaj novu parcelu</button>
    
    <table id="parceleTable">
        <thead>
            <tr>
                <th>Naziv parcele</th>
                <th>Katastarska opština</th>
                <th>Broj katastarske parcele</th>
                <th>Površina (ha)</th>
                <th>Proizvođač</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($parcele as $parcela): ?>
            <tr>
                <td><?php echo htmlspecialchars($parcela['nazivParcele']); ?></td>
                <td><?php echo htmlspecialchars($parcela['karastarskaOpstina']); ?></td>
                <td><?php echo htmlspecialchars($parcela['brojKatastarskeParcele']); ?></td>
                <td><?php echo htmlspecialchars($parcela['povrsinaParceleHa']); ?></td>
                <td><?php echo htmlspecialchars($parcela['nazivProizvodjaca']); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
