<?php
include '../db.php';
session_start();

$id = $_GET['id'];

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivParcele = $_POST['nazivParcele'];

    $query = "UPDATE parcele SET nazivParcele = :nazivParcele WHERE parcelaID = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivParcele', $nazivParcele);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        header("Location: pindex.php");
    } else {
        echo "Greška pri uređivanju.";
    }
}

$query = "SELECT * FROM parcele WHERE parcelaID = :id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':id', $id);
$stmt->execute();
$parcela = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi parcelu</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ebe3dd;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://www.phillymag.com/wp-content/uploads/sites/3/2020/10/wayvine-vineyard-9x6-1.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85); /* Providna bela pozadina */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 600px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        input {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            max-width: 400px;
        }

        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #556b35;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi parcelu</h1>
    <form method="post" action="edit_parcele.php?id=<?php echo $id; ?>">
        <input type="text" name="nazivParcele" placeholder="Naziv Parcele" value="<?php echo htmlspecialchars($parcela['nazivParcele']); ?>" required>
        <button type="submit">Sačuvaj</button>
    </form>
</div>
</body>
</html>
