<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Uzimanje svih proizvođača za padajuću listu
$query = "SELECT proizvodjacID, nazivProizvodjaca FROM proizvodjaci";
$stmt = $conn->prepare($query);
$stmt->execute();
$proizvodjaci = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $nazivParcele = $_POST['nazivParcele'];
        $katastarskaOpstina = $_POST['katastarskaOpstina'];
        $brojKatastarskeParcele = $_POST['brojKatastarskeParcele'];
        $povrsinaParceleHa = $_POST['povrsinaParceleHa'];
        $proizvodjacID = $_POST['proizvodjacID'];

        // Upit za unos nove parcele
        $query = "INSERT INTO parcele (nazivParcele, karastarskaOpstina, brojKatastarskeParcele, povrsinaParceleHa, proizvodjacID) 
          VALUES (:nazivParcele, :karastarskaOpstina, :brojKatastarskeParcele, :povrsinaParceleHa, :proizvodjacID)";

        $stmt = $conn->prepare($query);
        $stmt->bindParam(':nazivParcele', $nazivParcele);
        $stmt->bindParam(':karastarskaOpstina', $katastarskaOpstina);
        $stmt->bindParam(':brojKatastarskeParcele', $brojKatastarskeParcele);
        $stmt->bindParam(':povrsinaParceleHa', $povrsinaParceleHa);
        $stmt->bindParam(':proizvodjacID', $proizvodjacID);

        if ($stmt->execute()) {
            // Osiguraj da nema izlaza pre JSON odgovora
            echo json_encode(['status' => 'success', 'message' => 'Parcela uspješno dodata!']);
            exit();
        } else {
            throw new Exception("Greška pri izvršavanju SQL upita.");
        }
    } catch (Exception $e) {
        // Hvatanje grešaka i slanje JSON odgovora
        echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške: ' . $e->getMessage()]);
        exit();
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj novu parcelu</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ebe3dd;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://www.phillymag.com/wp-content/uploads/sites/3/2020/10/wayvine-vineyard-9x6-1.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 90%;
            max-width: 600px;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            max-width: 400px;
        }

        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #556b35;
        }

        .message {
            margin-top: 20px;
            font-size: 18px;
            color: green; /* Zelena boja za uspešnu poruku */
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Dodaj novu parcelu</h1>
    <!-- Dugme za povratak na prethodnu stranicu sa strelicom -->
    <button class="back-button" onclick="window.location.href='pindex.php'">&#8592;</button>
    <form id="dodajParceluForm" method="post" action="add_parcele.php">
        <input type="text" name="nazivParcele" placeholder="Naziv Parcele" required>
        <input type="text" name="katastarskaOpstina" placeholder="Katastarska opština" required>
        <input type="text" name="brojKatastarskeParcele" placeholder="Broj katastarske parcele" pattern="\[\d+(,\s?\d+)*\]" title="Unesite brojeve u formatu: [broj1, broj2, broj3]" required>
        <input type="text" name="povrsinaParceleHa" placeholder="Površina (ha)" pattern="[0-9]+" required>
        
        <!-- Dodavanje proizvođača kao padajuće liste -->
        <select name="proizvodjacID" required>
            <option value="" disabled selected hidden>Izaberi proizvođača</option>
            <?php foreach ($proizvodjaci as $proizvodjac): ?>
                <option value="<?= $proizvodjac['proizvodjacID'] ?>"><?= $proizvodjac['nazivProizvodjaca'] ?></option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Dodaj</button>
    </form>

    <!-- Prostor za prikaz poruke -->
    <div id="poruka" class="message"></div>
</div>

<script>
    document.getElementById('dodajParceluForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let formData = new FormData(this);

    fetch('add_parcele.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json()) // Parsiranje JSON odgovora
    .then(data => {
        let porukaDiv = document.getElementById('poruka');
        if (data.status === 'success') {
            porukaDiv.textContent = 'Uspješno ste dodali parcelu!';
            porukaDiv.style.color = 'green';
            
        } else {
            porukaDiv.textContent = data.message;
            porukaDiv.style.color = 'red';
        }
        // Resetovanje forme ako je dodavanje bilo uspešno
        if (data.status === 'success') {
            document.getElementById('dodajParceluForm').reset();
        }
    })
    .catch(error => {
        console.error('Došlo je do greške:', error);
        let porukaDiv = document.getElementById('poruka');
        porukaDiv.textContent = 'Došlo je do greške pri dodavanju parcele.';
        porukaDiv.style.color = 'red';
    });
});

</script>

</body>
</html>



