<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Provjera da li je zahtjev POST, što znači da korisnik šalje ažurirane podatke
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $prinosID = $_POST['prinosID'];
    $parcelaSortaID = $_POST['parcelaSortaID'];
    $godina = $_POST['godina'];
    $iznos = $_POST['iznos'];

    // Ažuriranje podataka u bazi
    $updateQuery = "UPDATE prinosi SET parcelaSortaID = :parcelaSortaID, godina = :godina, iznos = :iznos WHERE prinosID = :prinosID";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bindParam(':parcelaSortaID', $parcelaSortaID);
    $stmt->bindParam(':godina', $godina);
    $stmt->bindParam(':iznos', $iznos);
    $stmt->bindParam(':prinosID', $prinosID);

    if ($stmt->execute()) {
        header("Location: prindex.php");
        exit();
    } else {
        echo "Greška pri ažuriranju prinosa.";
    }
} else {
    // Preuzimanje trenutnih podataka o prinosu koji se uređuje
    if (isset($_GET['id'])) {
        $prinosID = $_GET['id'];

        $query = "SELECT * FROM prinosi WHERE prinosID = :prinosID";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':prinosID', $prinosID);
        $stmt->execute();

        $prinos = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$prinos) {
            echo "Prinos nije pronađen.";
            exit();
        }

        // Preuzimanje validnih opcija za parcele i sorte
        $validOptionsQuery = "SELECT ps.parcelaSortaID, pa.nazivParcele, s.nazivSorte 
                              FROM parcelesorte ps
                              JOIN parcele pa ON ps.parcelaID = pa.parcelaID
                              JOIN sorte s ON ps.sortaID = s.sortaID";
        $validOptionsStmt = $conn->prepare($validOptionsQuery);
        $validOptionsStmt->execute();
        $parceleSorte = $validOptionsStmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        echo "Neispravan zahtjev.";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi prinos</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://www.amoretraveldesigns.com/wp-content/uploads/2019/02/italy-ga742e60a2_1280-1024x678.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        select, input {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0f2e41;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
            text-align: left;
            width: 100%;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi prinos</h1>
    <form method="post" action="edit_prinos.php">
        <input type="hidden" name="prinosID" value="<?php echo htmlspecialchars($prinos['prinosID']); ?>">
        <label for="parcelaSortaID">Parcela i Sorta:</label>
        <select name="parcelaSortaID" required>
            <?php foreach ($parceleSorte as $parcelaSorta): ?>
                <option value="<?php echo $parcelaSorta['parcelaSortaID']; ?>" 
                    <?php echo ($parcelaSorta['parcelaSortaID'] == $prinos['parcelaSortaID']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($parcelaSorta['nazivParcele'] . " - " . $parcelaSorta['nazivSorte']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <label for="godina">Godina:</label>
        <input type="number" name="godina" value="<?php echo htmlspecialchars($prinos['godina']); ?>" required>
        <label for="iznos">Iznos (kg):</label>
        <input type="number" name="iznos" value="<?php echo htmlspecialchars($prinos['iznos']); ?>" step="0.01" required>
        <button type="submit">Sačuvaj izmjene</button>
    </form>
</div>
</body>
</html>
