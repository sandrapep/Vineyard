<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Dohvatanje svih prinosa sa proizvođačima za prikaz u tabeli
$query = "SELECT p.prinosID, p.iznos, p.godina, pa.nazivParcele, s.nazivSorte, pr.nazivProizvodjaca
          FROM prinosi p
          JOIN parcelesorte ps ON p.parcelaSortaID = ps.parcelaSortaID
          JOIN parcele pa ON ps.parcelaID = pa.parcelaID
          JOIN sorte s ON ps.sortaID = s.sortaID
          JOIN proizvodjaci pr ON pa.proizvodjacID = pr.proizvodjacID";
$stmt = $conn->prepare($query);
$stmt->execute();
$prinosi = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prinosi</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://d11vyokdyewbcr.cloudfront.net/2132801_large_a11b4514.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 1000px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .filter-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .filter-container input[type="text"], .filter-container input[type="number"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 30%;
        }

        .filter-container button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #143a51;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .filter-container button:hover {
            background-color: #0f2e41;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #aec7d6;
            color: #fff;
        }

        th, td {
            border: 1px solid #fff;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }

        th {
            background-color: #143a51;
        }

        td {
            background-color: #aec7d6;
            color: #000;
        }

        tbody {
            display: block;
            max-height: 400px;
            overflow-y: auto;
        }

        thead, tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }
        /* Stilizacija dugmeta za povratak */
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
    <script>
        function filterTable() {
            var proizvodjacFilter = document.getElementById("proizvodjacFilter").value.toUpperCase();
            var godinaFilter = document.getElementById("godinaFilter").value;
            var table = document.getElementById("prinosiTable");
            var tr = table.getElementsByTagName("tr");

            for (var i = 1; i < tr.length; i++) {
                var proizvodjacTd = tr[i].getElementsByTagName("td")[4];
                var godinaTd = tr[i].getElementsByTagName("td")[3];

                if (proizvodjacTd && godinaTd) {
                    var proizvodjacTxt = proizvodjacTd.textContent || proizvodjacTd.innerText;
                    var godinaTxt = godinaTd.textContent || godinaTd.innerText;

                    if (proizvodjacTxt.toUpperCase().indexOf(proizvodjacFilter) > -1 &&
                        (godinaFilter === "" || godinaTxt.indexOf(godinaFilter) > -1)) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</head>
<body>
<div class="container">
    <h1>Prinosi</h1>

<!-- Dugme za povratak na prethodnu stranicu sa strelicom -->
    <button class="back-button" onclick="window.location.href='../index.php'">&#8592;</button>
    <!-- Filter inputs in one row -->
    <div class="filter-container">
        <input type="text" id="proizvodjacFilter" placeholder="Pretraži po proizvođaču">
        <input type="number" id="godinaFilter" placeholder="Pretraži po godini">
        <button onclick="filterTable()">Filtriraj</button>
    </div>
<!-- Dugme za dodavanje novog prinosa -->
    <button style="margin-top: 10px; padding: 10px 20px; font-size: 16px; background-color: #143a51; color: #fff; border: none; border-radius: 4px; cursor: pointer;" onclick="window.location.href='add_prinos.php'">
        Dodaj novi prinos
    </button>
    <table id="prinosiTable">
        <thead>
            <tr>
                <th>Naziv parcele</th>
                <th>Naziv sorte</th>
                <th>Iznos (kg)</th>
                <th>Godina</th>
                <th>Proizvođač</th>
            </tr>
        </thead>
        <tbody>
        <?php if (!empty($prinosi)): ?>
            <?php foreach ($prinosi as $prinos): ?>
                <tr>
                    <td><?php echo htmlspecialchars($prinos['nazivParcele']); ?></td>
                    <td><?php echo htmlspecialchars($prinos['nazivSorte']); ?></td>
                    <td><?php echo htmlspecialchars($prinos['iznos']); ?></td>
                    <td><?php echo htmlspecialchars($prinos['godina']); ?></td>
                    <td><?php echo htmlspecialchars($prinos['nazivProizvodjaca']); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">Nema dostupnih prinosa.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
