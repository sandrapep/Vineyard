<?php
include '../db.php';

$db = new Database();
$conn = $db->getConnection();

if (isset($_GET['proizvodjacID'])) {
    $proizvodjacID = $_GET['proizvodjacID'];

    // Povlačenje parcela i sorti na osnovu odabranog proizvođača
    $query = "SELECT ps.parcelaSortaID, pa.nazivParcele, s.nazivSorte 
              FROM parcelesorte ps
              JOIN parcele pa ON ps.parcelaID = pa.parcelaID
              JOIN sorte s ON ps.sortaID = s.sortaID
              WHERE pa.proizvodjacID = :proizvodjacID";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':proizvodjacID', $proizvodjacID);
    $stmt->execute();
    $parceleSorte = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Vraćamo rezultat kao JSON
    echo json_encode($parceleSorte);
}
?>
