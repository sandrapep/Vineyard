<?php
ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Kada se forma podnese
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $parcelaSortaID = $_POST['parcelaSortaID'];
    $godina = $_POST['godina'];
    $iznos = $_POST['iznos'];

    // Provjera da li parcelaSortaID postoji u tabeli 'parcelesorte'
    $checkQuery = "SELECT parcelaSortaID FROM parcelesorte WHERE parcelaSortaID = :parcelaSortaID";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bindParam(':parcelaSortaID', $parcelaSortaID);
    $checkStmt->execute();

    if ($checkStmt->rowCount() > 0) {
        // Ako postoji, dozvoli unos prinosa
        $insertQuery = "INSERT INTO prinosi (parcelaSortaID, godina, iznos) VALUES (:parcelaSortaID, :godina, :iznos)";
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bindParam(':parcelaSortaID', $parcelaSortaID);
        $insertStmt->bindParam(':godina', $godina);
        $insertStmt->bindParam(':iznos', $iznos);

        if ($insertStmt->execute()) {
            echo "Prinos uspješno dodat!";
            header("Location: prindex.php");
            exit();
        } else {
            echo "Greška pri dodavanju prinosa.";
        }
    } else {
        echo "Greška: Odabrana parcela i sorta ne postoje u tabeli 'parcelesorte'. Prinos nije dodat.";
    }
}

// Dohvatanje svih proizvođača
$proizvodjaciQuery = "SELECT proizvodjacID, nazivProizvodjaca FROM proizvodjaci";
$proizvodjaciStmt = $conn->prepare($proizvodjaciQuery);
$proizvodjaciStmt->execute();
$proizvodjaci = $proizvodjaciStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj prinos</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://www.amoretraveldesigns.com/wp-content/uploads/2019/02/italy-ga742e60a2_1280-1024x678.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        select, input {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
        }

        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0f2e41;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
            text-align: left;
            width: 100%;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Dodaj novi prinos</h1>
    <button class="back-button" onclick="window.location.href='prindex.php'">&#8592;</button>
    <form method="post" action="add_prinos.php">
        <label for="proizvodjacID">Proizvođač:</label>
        <select name="proizvodjacID" id="proizvodjacID" required>
            <option value="">Izaberite proizvođača</option>
            <?php foreach ($proizvodjaci as $proizvodjac): ?>
                <option value="<?php echo $proizvodjac['proizvodjacID']; ?>">
                    <?php echo htmlspecialchars($proizvodjac['nazivProizvodjaca']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="parcelaSortaID">Parcela i sorta:</label>
        <select name="parcelaSortaID" id="parcelaSortaID" required>
            <option value="">Izaberite parcelu i sortu</option>
            <!-- Ovdje će se dinamički prikazivati opcije -->
        </select>

        <label for="godina">Godina:</label>
        <input type="number" name="godina" id="godina" min="1900" max="<?php echo date('Y'); ?>" required>

        <label for="iznos">Iznos (kg):</label>
        <input type="number" name="iznos" id="iznos" min="0.01" step="0.01" required>

        <button type="submit">Dodaj prinos</button>
    </form>
</div>

<script>
    document.getElementById('proizvodjacID').addEventListener('change', function() {
        var proizvodjacID = this.value;

        if (proizvodjacID) {
            // Pozivamo backend da nam vrati parcele i sorte za izabranog proizvođača
            fetch('getParceleSorte.php?proizvodjacID=' + proizvodjacID)
            .then(response => response.json())
            .then(data => {
                var parcelaSortaSelect = document.getElementById('parcelaSortaID');
                parcelaSortaSelect.innerHTML = '<option value="">Izaberite parcelu i sortu</option>';

                // Popunjavamo opcije na osnovu vraćenih podataka
                data.forEach(function(parcelaSorta) {
                    var option = document.createElement('option');
                    option.value = parcelaSorta.parcelaSortaID;
                    option.textContent = parcelaSorta.nazivParcele + ' - ' + parcelaSorta.nazivSorte;
                    parcelaSortaSelect.appendChild(option);
                });
            });
        }
    });
</script>

</body>
</html>
