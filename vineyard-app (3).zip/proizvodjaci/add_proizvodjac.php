<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Uzimanje proizvođača, faza, parcela i sorti za padajuće liste
$queryProizvodjaci = "SELECT proizvodjacID, nazivProizvodjaca FROM proizvodjaci";
$stmtProizvodjaci = $conn->prepare($queryProizvodjaci);
$stmtProizvodjaci->execute();
$proizvodjaci = $stmtProizvodjaci->fetchAll(PDO::FETCH_ASSOC);

$queryFaze = "SELECT fenoloskaFazaID, nazivFaze, fenoKod FROM fenoloskefaze";
$stmtFaze = $conn->prepare($queryFaze);
$stmtFaze->execute();
$faze = $stmtFaze->fetchAll(PDO::FETCH_ASSOC);

$queryParcele = "SELECT parcelaID, nazivParcele FROM parcele";
$stmtParcele = $conn->prepare($queryParcele);
$stmtParcele->execute();
$parcele = $stmtParcele->fetchAll(PDO::FETCH_ASSOC);

$querySorte = "SELECT sortaID, nazivSorte FROM sorte";
$stmtSorte = $conn->prepare($querySorte);
$stmtSorte->execute();
$sorte = $stmtSorte->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $proizvodjacID = $_POST['proizvodjacID'];
        $fenoloskaFazaID = $_POST['fenoloskaFazaID'];
        $parcelaID = $_POST['parcelaID'];
        $sortaID = $_POST['sortaID'];
        $datumVrijeme = $_POST['datumVrijeme'];

        // Upit za unos podataka
        $query = "INSERT INTO registarfenofaza (parcelaSortaID, fenoloskaFazaID, datumVrijeme) 
                  VALUES ((SELECT parcelaSortaID FROM parcelesorte WHERE parcelaID = :parcelaID AND sortaID = :sortaID), 
                          :fenoloskaFazaID, :datumVrijeme)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':parcelaID', $parcelaID);
        $stmt->bindParam(':sortaID', $sortaID);
        $stmt->bindParam(':fenoloskaFazaID', $fenoloskaFazaID);
        $stmt->bindParam(':datumVrijeme', $datumVrijeme);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Unos uspešno dodat!']);
            exit();
        } else {
            throw new Exception("Greška pri izvršavanju SQL upita.");
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Došlo je do greške: ' . $e->getMessage()]);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj proizvođača po kategorijama</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ebe3dd;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://www.estate-living.co.za/wp-content/uploads/2020/06/vineyard-6.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 90%;
            max-width: 600px;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-family: 'Arial', sans-serif;
        }

        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            max-width: 400px;
            font-family: 'Arial', sans-serif;
        }

        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-family: 'Arial', sans-serif;
        }

        button:hover {
            background-color: #556b35;
        }

        .message {
            margin-top: 20px;
            font-size: 18px;
            color: green;
            font-family: 'Arial', sans-serif;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Dodaj proizvođača po kategorijama</h1>
    <form id="dodajUnosForm" method="post" action="add_proizvodjac.php">
        <!-- Izbor proizvođača -->
        <select name="proizvodjacID" required>
            <option value="" disabled selected hidden>Izaberi proizvođača</option>
            <?php foreach ($proizvodjaci as $proizvodjac): ?>
                <option value="<?= $proizvodjac['proizvodjacID'] ?>"><?= $proizvodjac['nazivProizvodjaca'] ?></option>
            <?php endforeach; ?>
        </select>

        <!-- Izbor parcele -->
        <select name="parcelaID" required>
            <option value="" disabled selected hidden>Izaberi parcelu</option>
            <?php foreach ($parcele as $parcela): ?>
                <option value="<?= $parcela['parcelaID'] ?>"><?= $parcela['nazivParcele'] ?></option>
            <?php endforeach; ?>
        </select>

        <!-- Izbor sorte -->
        <select name="sortaID" required>
            <option value="" disabled selected hidden>Izaberi sortu</option>
            <?php foreach ($sorte as $sorta): ?>
                <option value="<?= $sorta['sortaID'] ?>"><?= $sorta['nazivSorte'] ?></option>
            <?php endforeach; ?>
        </select>

        <!-- Izbor fenološke faze -->
        <select name="fenoloskaFazaID" id="fenoloskaFazaID" required>
            <option value="" disabled selected hidden>Izaberi fenološku fazu</option>
            <?php foreach ($faze as $faza): ?>
                <option value="<?= $faza['fenoloskaFazaID'] ?>" data-fenokod="<?= $faza['fenoKod'] ?>"><?= $faza['nazivFaze'] ?></option>
            <?php endforeach; ?>
        </select>

        <!-- Automatski popunjeno feno kod polje -->
        <input type="text" name="fenoKod" id="fenoKod" placeholder="Feno kod" readonly>

        <!-- Datum i vrijeme -->
        <input type="datetime-local" name="datumVrijeme" required>

        <button type="submit">Dodaj</button>
    </form>

    <!-- Prostor za prikaz poruke -->
    <div id="poruka" class="message"></div>
</div>

<script>
    // Automatsko popunjavanje feno koda na osnovu izabrane fenološke faze
    document.getElementById('fenoloskaFazaID').addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const fenoKod = selectedOption.getAttribute('data-fenokod');
        document.getElementById('fenoKod').value = fenoKod;
    });

    document.getElementById('dodajUnosForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let formData = new FormData(this);

    fetch('add_proizvodjac.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        let porukaDiv = document.getElementById('poruka');
        if (data.status === 'success') {
            porukaDiv.textContent = 'Uspješno ste dodali proizvođača po kategorijama!';
            porukaDiv.style.color = 'green';
        } else {
            porukaDiv.textContent = data.message;
            porukaDiv.style.color = 'red';
        }
        if (data.status === 'success') {
            document.getElementById('dodajUnosForm').reset();
        }
    })
    .catch(error => {
        console.error('Došlo je do greške:', error);
        let porukaDiv = document.getElementById('poruka');
        porukaDiv.textContent = 'Došlo je do greške pri dodavanju proizvođača po kategorijama.';
        porukaDiv.style.color = 'red';
    });
});
</script>

</body>
</html>
