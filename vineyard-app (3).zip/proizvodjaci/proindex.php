<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Upit za povlačenje potrebnih podataka
$query = "
    SELECT pr.nazivProizvodjaca, f.nazivFaze, f.fenoKod, p.nazivParcele, s.nazivSorte
    FROM registarfenofaza rf
    JOIN parcelesorte ps ON rf.parcelaSortaID = ps.parcelaSortaID
    JOIN parcele p ON ps.parcelaID = p.parcelaID
    JOIN sorte s ON ps.sortaID = s.sortaID
    JOIN fenoloskefaze f ON rf.fenoloskaFazaID = f.fenoloskaFazaID
    JOIN proizvodjaci pr ON p.proizvodjacID = pr.proizvodjacID
";

$stmt = $conn->prepare($query);
$stmt->execute();
$podaci = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proizvođači</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ebe3dd;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://i0.wp.com/klcjournal.com/wp-content/uploads/2023/11/Wine_Hero.jpg?fit=1200%2C675&ssl=1');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 1000px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .filter-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .filter-container input[type="text"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 20%;
        }

        .filter-container button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #668846;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .filter-container button:hover {
            background-color: #556b35;
        }

        button.add-button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #668846;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        button.add-button:hover {
            background-color: #556b35;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #bdccaf;
            color: #fff;
        }

        th, td {
            border: 1px solid #fff;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }

        th {
            background-color: #668846;
        }

        td {
            background-color: #bdccaf;
            color: #000;
        }

        tbody {
            display: block;
            max-height: 400px;
            overflow-y: auto;
        }

        thead, tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }
        
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px; /* Veća strelica */
            font-weight: bold; /* Deblja strelica */
            background-color: #668846; /* Dodata boja pozadine */
            border: 2px solid #0f2e41; /* Dodan okvir */
            border-radius: 8px; /* Zaobljeni uglovi */
            color: #ffffff; /* Boja strelice */
            padding: 10px 15px; /* Razmak unutar dugmeta */
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease; /* Efekat prelaza */
    }
    
        .back-button:hover {
            background-color: #143a51; /* Tamnija pozadina pri hover-u */
            border-color: #143a51; /* Promena boje okvira pri hover-u */
    }

    </style>
    <script>
        function filterTable() {
            var proizvodjacFilter = document.getElementById("proizvodjacFilter").value.toUpperCase();
            var fazaFilter = document.getElementById("fazaFilter").value.toUpperCase();
            var parcelaFilter = document.getElementById("parcelaFilter").value.toUpperCase();
            var sortaFilter = document.getElementById("sortaFilter").value.toUpperCase();
            var table = document.getElementById("podaciTable");
            var tr = table.getElementsByTagName("tr");

            for (var i = 1; i < tr.length; i++) {  // Počinje od 1 jer prvi red sadrži zaglavlja
                var proizvodjacTd = tr[i].getElementsByTagName("td")[0];
                var fazaTd = tr[i].getElementsByTagName("td")[1];
                var parcelaTd = tr[i].getElementsByTagName("td")[3];
                var sortaTd = tr[i].getElementsByTagName("td")[4];
                
                if (proizvodjacTd && fazaTd && parcelaTd && sortaTd) {
                    var proizvodjacTxt = proizvodjacTd.textContent || proizvodjacTd.innerText;
                    var fazaTxt = fazaTd.textContent || fazaTd.innerText;
                    var parcelaTxt = parcelaTd.textContent || parcelaTd.innerText;
                    var sortaTxt = sortaTd.textContent || sortaTd.innerText;

                    if (proizvodjacTxt.toUpperCase().indexOf(proizvodjacFilter) > -1 &&
                        fazaTxt.toUpperCase().indexOf(fazaFilter) > -1 &&
                        parcelaTxt.toUpperCase().indexOf(parcelaFilter) > -1 &&
                        sortaTxt.toUpperCase().indexOf(sortaFilter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</head>
<body>
<div class="container">
    <h1>Proizvođači</h1>

    <!-- Filter inputs in one row with button -->
    <div class="filter-container">
        <input type="text" id="proizvodjacFilter" placeholder="Pretraži po nazivu proizvođača">
        <input type="text" id="fazaFilter" placeholder="Pretraži po nazivu faze">
        <input type="text" id="parcelaFilter" placeholder="Pretraži po nazivu parcele">
        <input type="text" id="sortaFilter" placeholder="Pretraži po nazivu sorte">
        <button onclick="filterTable()">Filtriraj</button>
    </div>

    <!-- Dugme za povratak na prethodnu stranicu -->
    <button class="back-button" onclick="window.location.href='../index.php'">&#8592;</button>

    <!-- Dugme za dodavanje novog proizvođača -->
    <button class="add-button" onclick="window.location.href='add_proizvodjac.php'">Dodaj proizvođača</button>
    
    <table id="podaciTable">
        <thead>
            <tr>
                <th>Naziv Proizvođača</th>
                <th>Naziv Faze</th>
                <th>Feno Kod</th>
                <th>Naziv Parcele</th>
                <th>Naziv Sorte</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($podaci as $podatak): ?>
            <tr>
                <td><?php echo htmlspecialchars($podatak['nazivProizvodjaca']); ?></td>
                <td><?php echo htmlspecialchars($podatak['nazivFaze']); ?></td>
                <td><?php echo htmlspecialchars($podatak['fenoKod']); ?></td>
                <td><?php echo htmlspecialchars($podatak['nazivParcele']); ?></td>
                <td><?php echo htmlspecialchars($podatak['nazivSorte']); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
