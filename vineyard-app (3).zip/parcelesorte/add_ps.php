<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

$response = ''; // Varijabla za poruku o grešci ili uspjehu

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sortaID = $_POST['sortaID'];
    $parcelaID = $_POST['parcelaID'];
    $razmakSadnje = $_POST['razmakSadnje'];
    $razmakRedovi = $_POST['razmakRedovi'];
    $godinaSadnje = $_POST['godinaSadnje'];

    // Provjera da li kombinacija sorte i parcele već postoji
    $checkQuery = "SELECT * FROM parcelesorte WHERE sortaID = :sortaID AND parcelaID = :parcelaID";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bindParam(':sortaID', $sortaID);
    $checkStmt->bindParam(':parcelaID', $parcelaID);
    $checkStmt->execute();

    if ($checkStmt->rowCount() > 0) {
        // Ako postoji kombinacija, ispiši poruku o grešci
        $response = "Odabrana sorta na ovoj parceli već postoji. Unesite drugu.";
    } else {
        // Ako kombinacija ne postoji, unesi novu
        $query = "INSERT INTO parcelesorte (sortaID, parcelaID, razmakSadnje, razmakRedovi, godinaSadnje) 
                  VALUES (:sortaID, :parcelaID, :razmakSadnje, :razmakRedovi, :godinaSadnje)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':sortaID', $sortaID);
        $stmt->bindParam(':parcelaID', $parcelaID);
        $stmt->bindParam(':razmakSadnje', $razmakSadnje);
        $stmt->bindParam(':razmakRedovi', $razmakRedovi);
        $stmt->bindParam(':godinaSadnje', $godinaSadnje);

        if ($stmt->execute()) {
            // Uspješan unos
            $response = "Sorta je uspješno dodata!";
        } else {
            // Greška pri unosu
            $response = "Greška pri dodavanju.";
        }
    }
}

// Povlačenje podataka o parcelama
$queryParcele = "SELECT * FROM parcele";
$stmtParcele = $conn->prepare($queryParcele);
$stmtParcele->execute();
$parcele = $stmtParcele->fetchAll(PDO::FETCH_ASSOC);

// Povlačenje podataka o sortama
$querySorte = "SELECT * FROM sorte";
$stmtSorte = $conn->prepare($querySorte);
$stmtSorte->execute();
$sorte = $stmtSorte->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj novu parcelu i sortu</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://i0.wp.com/practicalselfreliance.com/wp-content/uploads/2020/12/Foraging-Wild-Grapes-51.jpg?fit=1200%2C800&ssl=1');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85); /* Providna bela pozadina */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 600px;
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51; /* Plava boja dugmeta */
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0f2e41; /* Tamnija plava boja na hover */
        }
        .message {
            margin-top: 15px;
            font-size: 16px;
            color: red;
        }
        .message.success {
            color: green;
        }
         .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Dodaj novu parcelu i sortu</h1>
    <!-- Dugme za povratak na prethodnu stranicu sa strelicom -->
    <button class="back-button" onclick="window.location.href='psindex.php'">&#8592;</button>
    <form method="post" action="add_ps.php">
        <!-- Polje za izbor sorte -->
        <select name="sortaID" required>
            <option value="">Izaberite sortu</option>
            <?php foreach ($sorte as $sorta): ?>
                <option value="<?php echo $sorta['sortaID']; ?>"><?php echo htmlspecialchars($sorta['nazivSorte']); ?></option>
            <?php endforeach; ?>
        </select>

        <!-- Polje za izbor parcele -->
        <select name="parcelaID" required>
            <option value="">Izaberite parcelu</option>
            <?php foreach ($parcele as $parcela): ?>
                <option value="<?php echo $parcela['parcelaID']; ?>"><?php echo htmlspecialchars($parcela['nazivParcele']); ?></option>
            <?php endforeach; ?>
        </select>

        <!-- Polje za unos razmaka sadnje sa validacijom da prima samo brojeve -->
        <input type="text" name="razmakSadnje" placeholder="Razmak sadnje (cm)" pattern="[0-9]+" title="Unesite samo brojeve" required>

        <!-- Polje za unos razmaka redova sa validacijom da prima samo brojeve -->
        <input type="text" name="razmakRedovi" placeholder="Razmak redova (cm)" pattern="[0-9]+" title="Unesite samo brojeve" required>

        <!-- Polje za unos godine sadnje sa validacijom da prima samo brojeve -->
        <input type="text" name="godinaSadnje" placeholder="Godina sadnje" pattern="[0-9]{4}" title="Unesite validnu četvorocifrenu godinu" required>

        <button type="submit">Dodaj</button>
    </form>

    <!-- Ispis poruke o statusu (uspešno ili greška) -->
    <div class="message <?php echo !empty($response) && strpos($response, 'uspješno') !== false ? 'success' : ''; ?>">
        <?php echo $response; ?>
    </div>
</div>
</body>
</html>
