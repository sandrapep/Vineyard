<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Selektovanje parcela i sorti sa povezanim podacima o parceli, razmacima i godini sadnje
$query = "SELECT S.nazivSorte, P.nazivParcele, PS.godinaSadnje, PS.razmakSadnje, PS.razmakRedovi
          FROM sorte S
          INNER JOIN parcelesorte PS ON S.sortaID = PS.sortaID
          INNER JOIN parcele P ON PS.parcelaID = P.parcelaID";

$stmt = $conn->prepare($query);
$stmt->execute();
$parcelesorte = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parcele i sorte</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://d11vyokdyewbcr.cloudfront.net/2132801_large_a11b4514.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 1000px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        .filter-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        .filter-container input[type="text"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 25%;
        }
        .filter-container button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #143a51;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .filter-container button:hover {
            background-color: #0f2e41;
        }
        button.add-button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        button.add-button:hover {
            background-color: #0f2e41;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #aec7d6;
            color: #fff;
        }
        th, td {
            border: 1px solid #fff;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }
        th {
            background-color: #143a51;
        }
        td {
            background-color: #aec7d6;
            color: #000;
        }
        tbody {
            display: block;
            max-height: 400px;
            overflow-y: auto;
        }
        thead, tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }
         /* Stilizacija dugmeta za povratak */
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #668846;
            border-color: #143a51;
        }
    </style>
    <script>
        function filterTable() {
            var nazivSorteFilter = document.getElementById("nazivSorteFilter").value.toUpperCase();
            var parcelaFilter = document.getElementById("parcelaFilter").value.toUpperCase();
            var godinaFilter = document.getElementById("godinaFilter").value;
            var table = document.getElementById("parcelesorteTable");
            var tr = table.getElementsByTagName("tr");

            for (var i = 1; i < tr.length; i++) {
                var nazivSorteTd = tr[i].getElementsByTagName("td")[0];
                var parcelaTd = tr[i].getElementsByTagName("td")[1];
                var godinaTd = tr[i].getElementsByTagName("td")[4];

                if (nazivSorteTd && parcelaTd && godinaTd) {
                    var nazivSorteTxt = nazivSorteTd.textContent || nazivSorteTd.innerText;
                    var parcelaTxt = parcelaTd.textContent || parcelaTd.innerText;
                    var godinaTxt = godinaTd.textContent || godinaTd.innerText;

                    if (nazivSorteTxt.toUpperCase().indexOf(nazivSorteFilter) > -1 &&
                        parcelaTxt.toUpperCase().indexOf(parcelaFilter) > -1 &&
                        (godinaFilter === "" || godinaTxt.indexOf(godinaFilter) > -1)) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</head>
<body>
<div class="container">
    <h1>Parcele i sorte</h1>

    <!-- Dugme za povratak na prethodnu stranicu sa strelicom -->
    <button class="back-button" onclick="window.location.href='../index.php'">&#8592;</button>

    <!-- Filter inputs in one row -->
    <div class="filter-container">
        <input type="text" id="nazivSorteFilter" placeholder="Pretraži po nazivu sorte">
        <input type="text" id="parcelaFilter" placeholder="Pretraži po parceli">
        <input type="text" id="godinaFilter" placeholder="Pretraži po godini sadnje">
        <button onclick="filterTable()">Filtriraj</button>
    </div>

    <button class="add-button" onclick="window.location.href='add_ps.php'">Dodaj novu parcelu i sortu</button>
    
    <table id="parcelesorteTable">
        <thead>
        <tr>
            <th>Naziv sorte</th>
            <th>Naziv parcele</th>
            <th>Razmak sadnje</th>
            <th>Razmak redova</th>
            <th>Godina sadnje</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($parcelesorte as $parcelasorta): ?>
            <tr>
                <td><?php echo htmlspecialchars($parcelasorta['nazivSorte']); ?></td>
                <td><?php echo htmlspecialchars($parcelasorta['nazivParcele']); ?></td>
                <td><?php echo htmlspecialchars($parcelasorta['razmakSadnje']); ?></td>
                <td><?php echo htmlspecialchars($parcelasorta['razmakRedovi']); ?></td>
                <td><?php echo htmlspecialchars($parcelasorta['godinaSadnje']); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
