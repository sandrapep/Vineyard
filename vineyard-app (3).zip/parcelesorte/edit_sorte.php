<?php
include '../db.php';
session_start();

$id = $_GET['id'];

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazivSorte = $_POST['nazivSorte'];
    $parcelaID = $_POST['parcelaID'];

    $query = "UPDATE sorte SET nazivSorte = :nazivSorte, parcelaID = :parcelaID WHERE sortaID = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':nazivSorte', $nazivSorte);
    $stmt->bindParam(':parcelaID', $parcelaID);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        header("Location: sindex.php");
    } else {
        echo "Greška pri uređivanju.";
    }
}

$query = "SELECT * FROM sorte WHERE sortaID = :id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':id', $id);
$stmt->execute();
$sorta = $stmt->fetch(PDO::FETCH_ASSOC);

$query = "SELECT * FROM parcele";
$stmt = $conn->prepare($query);
$stmt->execute();
$parcele = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi sortu</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://i0.wp.com/practicalselfreliance.com/wp-content/uploads/2020/12/Foraging-Wild-Grapes-51.jpg?fit=1200%2C800&ssl=1');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.85); /* Providna bela pozadina */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 600px;
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            max-width: 400px;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51; /* Plava boja dugmeta */
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0f2e41; /* Tamnija plava boja na hover */
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Uredi sortu</h1>
    <form method="post" action="edit_sorte.php?id=<?php echo $id; ?>">
        <input type="text" name="nazivSorte" placeholder="Naziv Sorte" value="<?php echo htmlspecialchars($sorta['nazivSorte']); ?>" required>
        <select name="parcelaID" required>
            <?php foreach ($parcele as $parcela): ?>
                <option value="<?php echo $parcela['parcelaID']; ?>" <?php echo $parcela['parcelaID'] == $sorta['parcelaID'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($parcela['nazivParcele']); ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Sačuvaj</button>
    </form>
</div>
</body>
</html>
