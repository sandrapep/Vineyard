<?php
session_start();
include '../db.php';

$response = ['status' => 'error', 'message' => 'Neispravan zahtjev.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentPassword = $_POST['currentPassword'];
    $newPassword = $_POST['newPassword'];

    $db = new Database();
    $conn = $db->getConnection();

    // Uzimanje korisnika iz sesije
    $userId = $_SESSION['user_id'];

    // Proveri trenutnu lozinku
    $query = "SELECT lozinka FROM korisnici WHERE korisnikID = :userId";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':userId', $userId);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($currentPassword, $user['lozinka'])) {
        // Ažuriranje lozinke
        $query = "UPDATE korisnici SET lozinka = :newPassword WHERE korisnikID = :userId";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':newPassword', password_hash($newPassword, PASSWORD_DEFAULT));
        $stmt->bindParam(':userId', $userId);

        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'Lozinka je uspješno promjenjena.'];
        } else {
            $response = ['status' => 'error', 'message' => 'Greška prilikom promjene lozinke.'];
        }
    } else {
        $response = ['status' => 'error', 'message' => 'Trenutna lozinka je netačna.'];
    }
}

echo json_encode($response);
