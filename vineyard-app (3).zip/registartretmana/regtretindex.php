<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../prijava.php");
    exit();
}

include '../db.php';

$db = new Database();
$conn = $db->getConnection();

// Selektovanje tipova tretmana koji su samo na jeziku "mne" i postoje u tabeli tretmani
$queryTipoviTretmana = "
    SELECT DISTINCT TT.tipTretmanaID, TT.nazivTretmana
    FROM tiptretmana TT
    JOIN tretmani T ON TT.tipTretmanaID = T.tipTretmanaID
    WHERE TT.jezik = 'mne'";
$stmtTipoviTretmana = $conn->prepare($queryTipoviTretmana);
$stmtTipoviTretmana->execute();
$tipoviTretmana = $stmtTipoviTretmana->fetchAll(PDO::FETCH_ASSOC);

// Obrada AJAX zahteva
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $tipTretmanaID = $_POST['tipTretmanaID'] ?? '';
    $parcelaID = $_POST['parcelaID'] ?? '';
    $sortaID = $_POST['sortaID'] ?? '';

    // Povlačenje parcela koje pripadaju odabranom tipu tretmana
    if ($_POST['action'] === 'getParcele') {
        $sql = "SELECT DISTINCT P.parcelaID, P.nazivParcele 
                FROM tretmani T
                JOIN parcelesorte PS ON T.parcelaSortaID = PS.parcelaSortaID
                JOIN parcele P ON PS.parcelaID = P.parcelaID
                WHERE T.tipTretmanaID = :tipTretmanaID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':tipTretmanaID', $tipTretmanaID);
        $stmt->execute();
        $parcele = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($parcele);
        exit();
    }

    // Povlačenje sorti koje odgovaraju izabranom tipu tretmana i parceli
    if ($_POST['action'] === 'getSorte') {
        $sql = "SELECT DISTINCT S.sortaID, S.nazivSorte 
                FROM tretmani T
                JOIN parcelesorte PS ON T.parcelaSortaID = PS.parcelaSortaID
                JOIN sorte S ON PS.sortaID = S.sortaID
                WHERE T.tipTretmanaID = :tipTretmanaID AND PS.parcelaID = :parcelaID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':tipTretmanaID', $tipTretmanaID);
        $stmt->bindParam(':parcelaID', $parcelaID);
        $stmt->execute();
        $sorte = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($sorte);
        exit();
    }

    // Povlačenje tretmana koji odgovaraju izabranim filterima
    if ($_POST['action'] === 'getTretmani') {
        $sql = "SELECT T.tretmanID, TT.nazivTretmana, T.opis, T.datumVrijeme, P.nazivParcele, S.nazivSorte
                FROM tretmani T
                JOIN tiptretmana TT ON T.tipTretmanaID = TT.tipTretmanaID
                JOIN parcelesorte PS ON T.parcelaSortaID = PS.parcelaSortaID
                JOIN parcele P ON PS.parcelaID = P.parcelaID
                JOIN sorte S ON PS.sortaID = S.sortaID
                WHERE TT.jezik = 'mne'";
        
        if (!empty($tipTretmanaID)) {
            $sql .= " AND T.tipTretmanaID = :tipTretmanaID";
        }
        if (!empty($parcelaID)) {
            $sql .= " AND P.parcelaID = :parcelaID";
        }
        if (!empty($sortaID)) {
            $sql .= " AND S.sortaID = :sortaID";
        }

        $stmt = $conn->prepare($sql);

        if (!empty($tipTretmanaID)) {
            $stmt->bindParam(':tipTretmanaID', $tipTretmanaID);
        }
        if (!empty($parcelaID)) {
            $stmt->bindParam(':parcelaID', $parcelaID);
        }
        if (!empty($sortaID)) {
            $stmt->bindParam(':sortaID', $sortaID);
        }

        $stmt->execute();
        $tretmani = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($tretmani);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registar tretmana</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ebe3dd;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://www.tenutalemandorlaie.it/wp-content/uploads/2021/08/239997814_374016124334964_4287002902571872494_n.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 1000px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #aec7d6;
            color: #333;
        }

        th, td {
            border: 1px solid #fff;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }

        th {
            background-color: #143a51 ;
            color: #fff;
        }

        td {
            background-color: #aec7d6;
        }

        tbody {
            display: block;
            max-height: 400px;
            overflow-y: auto;
        }

        thead, tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }

        .filter-container {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .filter-container label {
            text-align: center;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .filter-container select {
            padding: 10px;
            margin-bottom: 10px;
            width: 100%;
            max-width: 400px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: Arial, sans-serif;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 35px;
            font-weight: bold;
            background-color: #143a51 ;
            border: 2px solid #0f2e41;
            border-radius: 8px;
            color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #0f2e41;
            border-color: #668846;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="container">
    <h1>Registar tretmana</h1>
 <button class="back-button" onclick="window.location.href='../index.php'">&#8592;</button>
    <!-- Filter polja -->
    <div class="filter-container">
        <label for="tretman">Izaberite tip tretmana</label>
        <select id="tretman">
            <option value="">Izaberite tip tretmana</option>
            <?php foreach ($tipoviTretmana as $tip): ?>
                <option value="<?php echo htmlspecialchars($tip['tipTretmanaID']); ?>">
                    <?php echo htmlspecialchars($tip['nazivTretmana']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="parcela">Izaberite parcelu</label>
        <select id="parcela" disabled>
            <option value="">Izaberite parcelu</option>
            <!-- Opcije će se dodati dinamički -->
        </select>

        <label for="sorta">Izaberite sortu</label>
        <select id="sorta" disabled>
            <option value="">Izaberite sortu</option>
            <!-- Opcije će se dodati dinamički -->
        </select>
    </div>

    <table>
        <thead>
            <tr>
                <th>Tip tretmana</th>
                <th>Opis</th>
                <th>Datum i vrijeme</th>
                <th>Parcela</th>
                <th>Sorta</th>
            </tr>
        </thead>
        <tbody id="tabela-body">
            <!-- Dinamički podaci će biti ovde -->
        </tbody>
    </table>
</div>

<script>
$(document).ready(function() {
    // Kada se izabere tip tretmana, dohvatamo odgovarajuće parcele i ažuriramo tabelu
    $('#tretman').on('change', function() {
        const tipTretmanaID = $(this).val();

        if (tipTretmanaID) {
            $.post('', {action: 'getParcele', tipTretmanaID: tipTretmanaID}, function(data) {
                const parcele = JSON.parse(data);
                let options = '<option value="">Izaberite parcelu</option>';

                parcele.forEach(function(parcela) {
                    options += `<option value="${parcela.parcelaID}">${parcela.nazivParcele}</option>`;
                });

                $('#parcela').html(options).prop('disabled', false);
                updateTable();
            });
        } else {
            $('#parcela').prop('disabled', true).html('<option value="">Izaberite parcelu</option>');
            $('#sorta').prop('disabled', true).html('<option value="">Izaberite sortu</option>');
            updateTable();
        }
    });

    // Kada se izabere parcela, dohvatamo odgovarajuće sorte i ažuriramo tabelu
    $('#parcela').on('change', function() {
        const parcelaID = $(this).val();
        const tipTretmanaID = $('#tretman').val();

        if (parcelaID) {
            $.post('', {action: 'getSorte', parcelaID: parcelaID, tipTretmanaID: tipTretmanaID}, function(data) {
                const sorte = JSON.parse(data);
                let options = '<option value="">Izaberite sortu</option>';

                sorte.forEach(function(sorta) {
                    options += `<option value="${sorta.sortaID}">${sorta.nazivSorte}</option>`;
                });

                $('#sorta').html(options).prop('disabled', false);
                updateTable();
            });
        } else {
            $('#sorta').prop('disabled', true).html('<option value="">Izaberite sortu</option>');
        }
    });

    // Kada se izabere sorta, ažuriramo tabelu
    $('#sorta').on('change', function() {
        updateTable();
    });

    // Funkcija za ažuriranje tabele na osnovu izabranih filtera
    function updateTable() {
        const tipTretmanaID = $('#tretman').val();
        const parcelaID = $('#parcela').val();
        const sortaID = $('#sorta').val();

        $.post('', {action: 'getTretmani', tipTretmanaID: tipTretmanaID, parcelaID: parcelaID, sortaID: sortaID}, function(data) {
            const tretmani = JSON.parse(data);
            let rows = '';

            tretmani.forEach(function(tretman) {
                rows += `
                    <tr>
                        <td>${tretman.nazivTretmana}</td>
                        <td>${tretman.opis}</td>
                        <td>${tretman.datumVrijeme}</td>
                        <td>${tretman.nazivParcele}</td>
                        <td>${tretman.nazivSorte}</td>
                    </tr>
                `;
            });

            $('#tabela-body').html(rows);
        });
    }
});
</script>
</body>
</html>
