<?php
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tipRegistracije = $_POST['tipRegistracije'];

    // Provera da li je korisnik ili proizvođač
    if ($tipRegistracije == 'korisnik') {
        $ime = $_POST['ime'];
        $prezime = $_POST['prezime'];
        $email = $_POST['email'];
        $telefon = $_POST['telefon'];
        $lozinka = password_hash($_POST['lozinka'], PASSWORD_DEFAULT);
        $slika = $_POST['slika'];
        $linkZaPodatkeNaslovna = $_POST['linkZaPodatkeNaslovna'];

        $db = new Database();
        $conn = $db->getConnection();

        $query = "INSERT INTO korisnici (ime, prezime, eMail, telefon, lozinka, tipNaloga, slika, linkZaPodatkeNaslovna) 
                  VALUES (:ime, :prezime, :email, :telefon, :lozinka, 'korisnik', :slika, :linkZaPodatkeNaslovna)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':ime', $ime);
        $stmt->bindParam(':prezime', $prezime);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':telefon', $telefon);
        $stmt->bindParam(':lozinka', $lozinka);
        $stmt->bindParam(':slika', $slika);
        $stmt->bindParam(':linkZaPodatkeNaslovna', $linkZaPodatkeNaslovna);

        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Uspješna registracija korisnika!";
            header("Location: registracija.php");
            exit(); // Osigurava da se prekine izvršavanje nakon redirekcije
        } else {
            $_SESSION['error_message'] = "Greška pri registraciji korisnika.";
            header("Location: registracija.php");
            exit();
        }
        


    } elseif ($tipRegistracije == 'proizvodjac') {
        $nazivProizvodjaca = $_POST['nazivProizvodjaca'];
        $registarskiBroj = $_POST['registarskiBroj'];
        $adresa = $_POST['adresa'];
        $gradID = $_POST['gradID'];
        $email = $_POST['email'];
        $telefon = $_POST['telefon'];
        $lozinka = password_hash($_POST['lozinka'], PASSWORD_DEFAULT);
        $slika = $_POST['slika'];
        $linkZaPodatkeNaslovna = $_POST['linkZaPodatkeNaslovna'];

        $db = new Database();
        $conn = $db->getConnection();

        $query = "INSERT INTO proizvodjaci (nazivProizvodjaca, registarskiBroj, adresa, gradID, eMail, lozinka, telefon, slika, linkZaPodatkeNaslovna) 
                  VALUES (:nazivProizvodjaca, :registarskiBroj, :adresa, :gradID, :email, :lozinka, :telefon, :slika, :linkZaPodatkeNaslovna)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':nazivProizvodjaca', $nazivProizvodjaca);
        $stmt->bindParam(':registarskiBroj', $registarskiBroj);
        $stmt->bindParam(':adresa', $adresa);
        $stmt->bindParam(':gradID', $gradID);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':telefon', $telefon);
        $stmt->bindParam(':lozinka', $lozinka);
        $stmt->bindParam(':slika', $slika);
        $stmt->bindParam(':linkZaPodatkeNaslovna', $linkZaPodatkeNaslovna);

         // Slično za proizvođača
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Uspješna registracija proizvođača!";
            header("Location: registracija.php");
            exit();
        } else {
            $_SESSION['error_message'] = "Greška pri registraciji proizvođača.";
            header("Location: registracija.php");
            exit();
        }
    }

    // Preusmeravanje nazad na registracionu stranicu
    header("Location: registracija.php");
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registracija</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #668846; /* Zelena dingley kao pozadinska boja */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 400px;
            width: 100%;
        }
        h1 {
            color: #668846; /* Zelena dingley za naslov */
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            transition: border-color 0.3s;
        }
        input:focus, select:focus {
            border-color: #143a51; /* Plava elephant za fokus na input polja */
        }
        input[type="number"] {
            -moz-appearance: textfield; /* Uklanjanje strelica u Firefoxu */
        }
        input::-webkit-outer-spin-button, input::-webkit-inner-spin-button {
            -webkit-appearance: none; /* Uklanjanje strelica u Chrome/Safari */
        }
        button {
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #143a51; /* Plava elephant za dugme */
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0e2a3a; /* Tamnija plava za hover efekat na dugme */
        }
        .links {
            margin-top: 15px;
        }
        .links a {
            color: #143a51; /* Plava elephant za linkove */
            text-decoration: none;
            transition: color 0.3s;
        }
        .links a:hover {
            color: #668846; /* Zelena dingley za hover na linkove */
            text-decoration: underline;
        }
    </style>
    <script>
   function prikaziPolja() {
    var tipRegistracije = document.getElementById('tipRegistracije').value;
    
    // Prikazivanje polja za korisnika i skrivanje polja za proizvođača
    if (tipRegistracije === 'korisnik') {
        document.getElementById('korisnikPolja').style.display = 'block';
        document.getElementById('proizvodjacPolja').style.display = 'none';

        // Dodavanje required atributa za korisnika i uklanjanje sa polja za proizvođača
        document.querySelectorAll('#korisnikPolja input').forEach(input => {
            input.setAttribute('required', 'true');
        });
        document.querySelectorAll('#proizvodjacPolja input, #proizvodjacPolja select').forEach(input => {
            input.removeAttribute('required');
        });

    } else {
        // Prikazivanje polja za proizvođača i skrivanje polja za korisnika
        document.getElementById('korisnikPolja').style.display = 'none';
        document.getElementById('proizvodjacPolja').style.display = 'block';

        // Dodavanje required atributa za proizvođača i uklanjanje sa polja za korisnika
        document.querySelectorAll('#proizvodjacPolja input, #proizvodjacPolja select').forEach(input => {
            input.setAttribute('required', 'true');
        });
        document.querySelectorAll('#korisnikPolja input').forEach(input => {
            input.removeAttribute('required');
        });
    }
}

// Pozivanje funkcije na učitavanje stranice da se odmah postavi pravi prikaz
document.addEventListener('DOMContentLoaded', function () {
    prikaziPolja();
});

</script>
</head>
<body>
<div class="container">
    <h1>Registracija</h1>
     <?php
    if (isset($_SESSION['success_message'])) {
        echo "<div style='color: green; font-weight: bold;'>" . htmlspecialchars($_SESSION['success_message']) . "</div>";
        unset($_SESSION['success_message']); // Ukloni poruku nakon prikaza
    }
    if (isset($_SESSION['error_message'])) {
        echo "<div style='color: red; font-weight: bold;'>" . htmlspecialchars($_SESSION['error_message']) . "</div>";
        unset($_SESSION['error_message']); // Ukloni poruku nakon prikaza
    }
    ?>
    
    <form method="post" action="registracija.php">
        <select id="tipRegistracije" name="tipRegistracije" onchange="prikaziPolja()">
            <option value="korisnik">Korisnik</option>
            <option value="proizvodjac">Proizvođač</option>
        </select>

        <!-- Polja za korisnika -->
        <div id="korisnikPolja">
            <input type="text" name="ime" placeholder="Ime" required>
            <input type="text" name="prezime" placeholder="Prezime" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="telefon" placeholder="Telefon" pattern="[0-9]+" required>
            <input type="password" name="lozinka" placeholder="Lozinka" required>
            <input type="text" name="slika" placeholder="URL slike" optional>
            <input type="text" name="linkZaPodatkeNaslovna" placeholder="Link za podatke naslovna" optional>
        </div>

        <!-- Polja za proizvodjaca -->
        <div id="proizvodjacPolja" style="display:none;">
            <input type="text" name="nazivProizvodjaca" placeholder="Naziv proizvođača" required>
            <input type="text" name="registarskiBroj" placeholder="Registarski broj" required>
            <input type="text" name="adresa" placeholder="Adresa" required>

            <!-- Padajući meni za izbor grada -->
            <select name="gradID" required>
                <option value="" disabled selected>Izaberite grad</option>
                <option value="1">Podgorica</option>
                <option value="2">Nikšić</option>
                <option value="3">Pljevlja</option>
                <option value="4">Bijelo Polje</option>
                <option value="5">Cetinje</option>
                <option value="6">Bar</option>
                <option value="7">Herceg Novi</option>
                <option value="8">Berane</option>
                <option value="9">Budva</option>
                <option value="10">Ulcinj</option>
                <option value="11">Tivat</option>
                <option value="12">Rožaje</option>
                <option value="13">Kotor</option>
                <option value="14">Danilovgrad</option>
                <option value="15">Mojkovac</option>
                <option value="16">Plav</option>
                <option value="17">Kolašin</option>
                <option value="18">Žabljak</option>
                <option value="19">Plužine</option>
                <option value="20">Andrijevica</option>
            </select>

            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="telefon" placeholder="Telefon" pattern="[0-9]+" required>
            <input type="password" name="lozinka" placeholder="Lozinka" required>
            <input type="text" name="slika" placeholder="URL slike" optional>
            <input type="text" name="linkZaPodatkeNaslovna" placeholder="Link za podatke naslovna" optional>
        </div>

        <button type="submit">Registruj se</button>
    </form>
    <div class="links">
        <p>Već imate nalog? <a href="prijava.php">Prijavite se ovdje.</a></p>
    </div>
</div>
</body>
</html>
